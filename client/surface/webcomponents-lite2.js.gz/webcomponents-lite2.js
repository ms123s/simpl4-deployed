var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.getGlobal = function(maybeGlobal) {
  return typeof window != "undefined" && window === maybeGlobal ? maybeGlobal : typeof global != "undefined" && global != null ? global : maybeGlobal;
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.checkEs6ConformanceViaProxy = function() {
  try {
    var proxied = {};
    var proxy = Object.create(new $jscomp.global["Proxy"](proxied, {"get":function(target, key, receiver) {
      return target == proxied && key == "q" && receiver == proxy;
    }}));
    return proxy["q"] === true;
  } catch (err) {
    return false;
  }
};
$jscomp.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS = false;
$jscomp.ES6_CONFORMANCE = $jscomp.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS && $jscomp.checkEs6ConformanceViaProxy();
$jscomp.ASSUME_ES5 = false;
$jscomp.ASSUME_NO_NATIVE_MAP = false;
$jscomp.ASSUME_NO_NATIVE_SET = false;
$jscomp.defineProperty = $jscomp.ASSUME_ES5 || typeof Object.defineProperties == "function" ? Object.defineProperty : function(target, property, descriptor) {
  descriptor = descriptor;
  if (target == Array.prototype || target == Object.prototype) {
    return;
  }
  target[property] = descriptor.value;
};
$jscomp.SYMBOL_PREFIX = "jscomp_symbol_";
$jscomp.initSymbol = function() {
  $jscomp.initSymbol = function() {
  };
  if (!$jscomp.global["Symbol"]) {
    $jscomp.global["Symbol"] = $jscomp.Symbol;
  }
};
$jscomp.Symbol = function() {
  var counter = 0;
  function Symbol(opt_description) {
    return $jscomp.SYMBOL_PREFIX + (opt_description || "") + counter++;
  }
  return Symbol;
}();
$jscomp.initSymbolIterator = function() {
  $jscomp.initSymbol();
  var symbolIterator = $jscomp.global["Symbol"].iterator;
  if (!symbolIterator) {
    symbolIterator = $jscomp.global["Symbol"].iterator = $jscomp.global["Symbol"]("iterator");
  }
  if (typeof Array.prototype[symbolIterator] != "function") {
    $jscomp.defineProperty(Array.prototype, symbolIterator, {configurable:true, writable:true, value:function() {
      return $jscomp.arrayIterator(this);
    }});
  }
  $jscomp.initSymbolIterator = function() {
  };
};
$jscomp.initSymbolAsyncIterator = function() {
  $jscomp.initSymbol();
  var symbolAsyncIterator = $jscomp.global["Symbol"].asyncIterator;
  if (!symbolAsyncIterator) {
    symbolAsyncIterator = $jscomp.global["Symbol"].asyncIterator = $jscomp.global["Symbol"]("asyncIterator");
  }
  $jscomp.initSymbolAsyncIterator = function() {
  };
};
$jscomp.arrayIterator = function(array) {
  var index = 0;
  return $jscomp.iteratorPrototype(function() {
    if (index < array.length) {
      return {done:false, value:array[index++]};
    } else {
      return {done:true};
    }
  });
};
$jscomp.iteratorPrototype = function(next) {
  $jscomp.initSymbolIterator();
  var iterator = {next:next};
  iterator[$jscomp.global["Symbol"].iterator] = function() {
    return this;
  };
  return iterator;
};
$jscomp.makeIterator = function(iterable) {
  $jscomp.initSymbolIterator();
  var iteratorFunction = iterable[Symbol.iterator];
  return iteratorFunction ? iteratorFunction.call(iterable) : $jscomp.arrayIterator(iterable);
};
$jscomp.owns = function(obj, prop) {
  return Object.prototype.hasOwnProperty.call(obj, prop);
};
$jscomp.polyfill = function(target, polyfill, fromLang, toLang) {
  if (!polyfill) {
    return;
  }
  var obj = $jscomp.global;
  var split = target.split(".");
  for (var i = 0; i < split.length - 1; i++) {
    var key = split[i];
    if (!(key in obj)) {
      obj[key] = {};
    }
    obj = obj[key];
  }
  var property = split[split.length - 1];
  var orig = obj[property];
  var impl = polyfill(orig);
  if (impl == orig || impl == null) {
    return;
  }
  $jscomp.defineProperty(obj, property, {configurable:true, writable:true, value:impl});
};
$jscomp.polyfill("WeakMap", function(NativeWeakMap) {
  function isConformant() {
    if (!NativeWeakMap || !Object.seal) {
      return false;
    }
    try {
      var x = Object.seal({});
      var y = Object.seal({});
      var map = new NativeWeakMap([[x, 2], [y, 3]]);
      if (map.get(x) != 2 || map.get(y) != 3) {
        return false;
      }
      map["delete"](x);
      map.set(y, 4);
      return !map.has(x) && map.get(y) == 4;
    } catch (err) {
      return false;
    }
  }
  if ($jscomp.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS) {
    if (NativeWeakMap && $jscomp.ES6_CONFORMANCE) {
      return NativeWeakMap;
    }
  } else {
    if (isConformant()) {
      return NativeWeakMap;
    }
  }
  var prop = "$jscomp_hidden_" + Math.random();
  function insert(target) {
    if (!$jscomp.owns(target, prop)) {
      var obj = {};
      $jscomp.defineProperty(target, prop, {value:obj});
    }
  }
  function patch(name) {
    var prev = Object[name];
    if (prev) {
      Object[name] = function(target) {
        insert(target);
        return prev(target);
      };
    }
  }
  patch("freeze");
  patch("preventExtensions");
  patch("seal");
  var index = 0;
  var PolyfillWeakMap = function(opt_iterable) {
    this.id_ = (index += Math.random() + 1).toString();
    if (opt_iterable) {
      $jscomp.initSymbol();
      $jscomp.initSymbolIterator();
      var iter = $jscomp.makeIterator(opt_iterable);
      var entry;
      while (!(entry = iter.next()).done) {
        var item = entry.value;
        this.set(item[0], item[1]);
      }
    }
  };
  PolyfillWeakMap.prototype.set = function(key, value) {
    insert(key);
    if (!$jscomp.owns(key, prop)) {
      throw new Error("WeakMap key fail: " + key);
    }
    key[prop][this.id_] = value;
    return this;
  };
  PolyfillWeakMap.prototype.get = function(key) {
    return $jscomp.owns(key, prop) ? key[prop][this.id_] : undefined;
  };
  PolyfillWeakMap.prototype.has = function(key) {
    return $jscomp.owns(key, prop) && $jscomp.owns(key[prop], this.id_);
  };
  PolyfillWeakMap.prototype["delete"] = function(key) {
    if (!$jscomp.owns(key, prop) || !$jscomp.owns(key[prop], this.id_)) {
      return false;
    }
    return delete key[prop][this.id_];
  };
  return PolyfillWeakMap;
}, "es6", "es3");
$jscomp.MapEntry = function() {
  this.previous;
  this.next;
  this.head;
  this.key;
  this.value;
};
$jscomp.polyfill("Map", function(NativeMap) {
  function isConformant() {
    if ($jscomp.ASSUME_NO_NATIVE_MAP || !NativeMap || typeof NativeMap != "function" || !NativeMap.prototype.entries || typeof Object.seal != "function") {
      return false;
    }
    try {
      NativeMap = NativeMap;
      var key = Object.seal({x:4});
      var map = new NativeMap($jscomp.makeIterator([[key, "s"]]));
      if (map.get(key) != "s" || map.size != 1 || map.get({x:4}) || map.set({x:4}, "t") != map || map.size != 2) {
        return false;
      }
      var iter = map.entries();
      var item = iter.next();
      if (item.done || item.value[0] != key || item.value[1] != "s") {
        return false;
      }
      item = iter.next();
      if (item.done || item.value[0].x != 4 || item.value[1] != "t" || !iter.next().done) {
        return false;
      }
      return true;
    } catch (err) {
      return false;
    }
  }
  if ($jscomp.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS) {
    if (NativeMap && $jscomp.ES6_CONFORMANCE) {
      return NativeMap;
    }
  } else {
    if (isConformant()) {
      return NativeMap;
    }
  }
  $jscomp.initSymbol();
  $jscomp.initSymbolIterator();
  var idMap = new WeakMap;
  var PolyfillMap = function(opt_iterable) {
    this.data_ = {};
    this.head_ = createHead();
    this.size = 0;
    if (opt_iterable) {
      var iter = $jscomp.makeIterator(opt_iterable);
      var entry;
      while (!(entry = iter.next()).done) {
        var item = entry.value;
        this.set(item[0], item[1]);
      }
    }
  };
  PolyfillMap.prototype.set = function(key, value) {
    key = key === 0 ? 0 : key;
    var r = maybeGetEntry(this, key);
    if (!r.list) {
      r.list = this.data_[r.id] = [];
    }
    if (!r.entry) {
      r.entry = {next:this.head_, previous:this.head_.previous, head:this.head_, key:key, value:value};
      r.list.push(r.entry);
      this.head_.previous.next = r.entry;
      this.head_.previous = r.entry;
      this.size++;
    } else {
      r.entry.value = value;
    }
    return this;
  };
  PolyfillMap.prototype["delete"] = function(key) {
    var r = maybeGetEntry(this, key);
    if (r.entry && r.list) {
      r.list.splice(r.index, 1);
      if (!r.list.length) {
        delete this.data_[r.id];
      }
      r.entry.previous.next = r.entry.next;
      r.entry.next.previous = r.entry.previous;
      r.entry.head = null;
      this.size--;
      return true;
    }
    return false;
  };
  PolyfillMap.prototype.clear = function() {
    this.data_ = {};
    this.head_ = this.head_.previous = createHead();
    this.size = 0;
  };
  PolyfillMap.prototype.has = function(key) {
    return !!maybeGetEntry(this, key).entry;
  };
  PolyfillMap.prototype.get = function(key) {
    var entry = maybeGetEntry(this, key).entry;
    return entry && entry.value;
  };
  PolyfillMap.prototype.entries = function() {
    return makeIterator(this, function(entry) {
      return [entry.key, entry.value];
    });
  };
  PolyfillMap.prototype.keys = function() {
    return makeIterator(this, function(entry) {
      return entry.key;
    });
  };
  PolyfillMap.prototype.values = function() {
    return makeIterator(this, function(entry) {
      return entry.value;
    });
  };
  PolyfillMap.prototype.forEach = function(callback, opt_thisArg) {
    var iter = this.entries();
    var item;
    while (!(item = iter.next()).done) {
      var entry = item.value;
      callback.call(opt_thisArg, entry[1], entry[0], this);
    }
  };
  PolyfillMap.prototype[Symbol.iterator] = PolyfillMap.prototype.entries;
  var maybeGetEntry = function(map, key) {
    var id = getId(key);
    var list = map.data_[id];
    if (list && $jscomp.owns(map.data_, id)) {
      for (var index = 0; index < list.length; index++) {
        var entry = list[index];
        if (key !== key && entry.key !== entry.key || key === entry.key) {
          return {id:id, list:list, index:index, entry:entry};
        }
      }
    }
    return {id:id, list:list, index:-1, entry:undefined};
  };
  var makeIterator = function(map, func) {
    var entry = map.head_;
    return $jscomp.iteratorPrototype(function() {
      if (entry) {
        while (entry.head != map.head_) {
          entry = entry.previous;
        }
        while (entry.next != entry.head) {
          entry = entry.next;
          return {done:false, value:func(entry)};
        }
        entry = null;
      }
      return {done:true, value:void 0};
    });
  };
  var createHead = function() {
    var head = {};
    head.previous = head.next = head.head = head;
    return head;
  };
  var mapIndex = 0;
  var getId = function(obj) {
    var type = obj && typeof obj;
    if (type == "object" || type == "function") {
      obj = obj;
      if (!idMap.has(obj)) {
        var id = "" + ++mapIndex;
        idMap.set(obj, id);
        return id;
      }
      return idMap.get(obj);
    }
    return "p_" + obj;
  };
  return PolyfillMap;
}, "es6", "es3");
$jscomp.polyfill("Set", function(NativeSet) {
  function isConformant() {
    if ($jscomp.ASSUME_NO_NATIVE_SET || !NativeSet || typeof NativeSet != "function" || !NativeSet.prototype.entries || typeof Object.seal != "function") {
      return false;
    }
    try {
      NativeSet = NativeSet;
      var value = Object.seal({x:4});
      var set = new NativeSet($jscomp.makeIterator([value]));
      if (!set.has(value) || set.size != 1 || set.add(value) != set || set.size != 1 || set.add({x:4}) != set || set.size != 2) {
        return false;
      }
      var iter = set.entries();
      var item = iter.next();
      if (item.done || item.value[0] != value || item.value[1] != value) {
        return false;
      }
      item = iter.next();
      if (item.done || item.value[0] == value || item.value[0].x != 4 || item.value[1] != item.value[0]) {
        return false;
      }
      return iter.next().done;
    } catch (err) {
      return false;
    }
  }
  if ($jscomp.USE_PROXY_FOR_ES6_CONFORMANCE_CHECKS) {
    if (NativeSet && $jscomp.ES6_CONFORMANCE) {
      return NativeSet;
    }
  } else {
    if (isConformant()) {
      return NativeSet;
    }
  }
  $jscomp.initSymbol();
  $jscomp.initSymbolIterator();
  var PolyfillSet = function(opt_iterable) {
    this.map_ = new Map;
    if (opt_iterable) {
      var iter = $jscomp.makeIterator(opt_iterable);
      var entry;
      while (!(entry = iter.next()).done) {
        var item = entry.value;
        this.add(item);
      }
    }
    this.size = this.map_.size;
  };
  PolyfillSet.prototype.add = function(value) {
    value = value === 0 ? 0 : value;
    this.map_.set(value, value);
    this.size = this.map_.size;
    return this;
  };
  PolyfillSet.prototype["delete"] = function(value) {
    var result = this.map_["delete"](value);
    this.size = this.map_.size;
    return result;
  };
  PolyfillSet.prototype.clear = function() {
    this.map_.clear();
    this.size = 0;
  };
  PolyfillSet.prototype.has = function(value) {
    return this.map_.has(value);
  };
  PolyfillSet.prototype.entries = function() {
    return this.map_.entries();
  };
  PolyfillSet.prototype.values = function() {
    return this.map_.values();
  };
  PolyfillSet.prototype.keys = PolyfillSet.prototype.values;
  PolyfillSet.prototype[Symbol.iterator] = PolyfillSet.prototype.values;
  PolyfillSet.prototype.forEach = function(callback, opt_thisArg) {
    var set = this;
    this.map_.forEach(function(value) {
      return callback.call(opt_thisArg, value, value, set);
    });
  };
  return PolyfillSet;
}, "es6", "es3");
(function() {
  var Module = function(id, opt_exports) {
    this.id = id;
    this.exports = opt_exports || {};
  };
  Module.prototype.exportAllFrom = function(other) {
    var module = this;
    var define = {};
    for (var key in other) {
      if (key == "default" || key in module.exports || key in define) {
        continue;
      }
      define[key] = {enumerable:true, get:function(key) {
        return function() {
          return other[key];
        };
      }(key)};
    }
    $jscomp.global.Object.defineProperties(module.exports, define);
  };
  var CacheEntry = function(def, module, path) {
    this.def = def;
    this.module = module;
    this.path = path;
    this.blockingDeps = new Set;
  };
  CacheEntry.prototype.load = function() {
    if (this.def) {
      var def = this.def;
      this.def = null;
      callRequireCallback(def, this.module);
    }
    return this.module.exports;
  };
  function callRequireCallback(callback, opt_module) {
    var oldPath = currentModulePath;
    try {
      if (opt_module) {
        currentModulePath = opt_module.id;
        callback.call(opt_module, createRequire(opt_module), opt_module.exports, opt_module);
      } else {
        callback($jscomp.require);
      }
    } finally {
      currentModulePath = oldPath;
    }
  }
  var moduleCache = new Map;
  var currentModulePath = "";
  function normalizePath(path) {
    var components = path.split("/");
    var i = 0;
    while (i < components.length) {
      if (components[i] == ".") {
        components.splice(i, 1);
      } else {
        if (i && components[i] == ".." && components[i - 1] && components[i - 1] != "..") {
          components.splice(--i, 2);
        } else {
          i++;
        }
      }
    }
    return components.join("/");
  }
  $jscomp.getCurrentModulePath = function() {
    return currentModulePath;
  };
  function getCacheEntry(id) {
    var cacheEntry = moduleCache.get(id);
    if (cacheEntry === undefined) {
      throw new Error("Module " + id + " does not exist.");
    }
    return cacheEntry;
  }
  var ensureMap = new Map;
  var CallbackEntry = function(requireSet, callback) {
    this.requireSet = requireSet;
    this.callback = callback;
  };
  function maybeNormalizePath(root, absOrRelativePath) {
    if (absOrRelativePath.startsWith("./") || absOrRelativePath.startsWith("../")) {
      return normalizePath(root + "/../" + absOrRelativePath);
    } else {
      return absOrRelativePath;
    }
  }
  function createRequire(opt_module) {
    function require(absOrRelativePath) {
      var absPath = absOrRelativePath;
      if (opt_module) {
        absPath = maybeNormalizePath(opt_module.id, absPath);
      }
      return getCacheEntry(absPath).load();
    }
    function requireEnsure(requires, callback) {
      if (currentModulePath) {
        for (var i = 0; i < requires.length; i++) {
          requires[i] = maybeNormalizePath(currentModulePath, requires[i]);
        }
      }
      var blockingRequires = [];
      for (var i = 0; i < requires.length; i++) {
        var required = moduleCache.get(requires[i]);
        if (!required || required.blockingDeps.size) {
          blockingRequires.push(requires[i]);
        }
      }
      if (blockingRequires.length) {
        var requireSet = new Set(blockingRequires);
        var callbackEntry = new CallbackEntry(requireSet, callback);
        requireSet.forEach(function(require) {
          var arr = ensureMap.get(require);
          if (!arr) {
            arr = [];
            ensureMap.set(require, arr);
          }
          arr.push(callbackEntry);
        });
      } else {
        callback(require);
      }
    }
    require.ensure = requireEnsure;
    return require;
  }
  $jscomp.require = createRequire();
  $jscomp.hasModule = function(id) {
    return moduleCache.has(id);
  };
  function markAvailable(absModulePath) {
    var ensures = ensureMap.get(absModulePath);
    if (ensures) {
      for (var i = 0; i < ensures.length; i++) {
        var entry = ensures[i];
        entry.requireSet["delete"](absModulePath);
        if (!entry.requireSet.size) {
          ensures.splice(i--, 1);
          callRequireCallback(entry.callback);
        }
      }
      if (!ensures.length) {
        ensureMap["delete"](absModulePath);
      }
    }
  }
  $jscomp.registerModule = function(moduleDef, absModulePath, opt_shallowDeps) {
    if (moduleCache.has(absModulePath)) {
      throw new Error("Module " + absModulePath + " has already been registered.");
    }
    if (currentModulePath) {
      throw new Error("Cannot nest modules.");
    }
    var shallowDeps = opt_shallowDeps || [];
    for (var i = 0; i < shallowDeps.length; i++) {
      shallowDeps[i] = maybeNormalizePath(absModulePath, shallowDeps[i]);
    }
    var blockingDeps = new Set;
    for (var i = 0; i < shallowDeps.length; i++) {
      getTransitiveBlockingDepsOf(shallowDeps[i]).forEach(function(transitive) {
        blockingDeps.add(transitive);
      });
    }
    blockingDeps["delete"](absModulePath);
    var cacheEntry = new CacheEntry(moduleDef, new Module(absModulePath), absModulePath);
    moduleCache.set(absModulePath, cacheEntry);
    blockingDeps.forEach(function(blocker) {
      addAsBlocking(cacheEntry, blocker);
    });
    if (!blockingDeps.size) {
      markAvailable(cacheEntry.module.id);
    }
    removeAsBlocking(cacheEntry);
  };
  function getTransitiveBlockingDepsOf(moduleId) {
    var cacheEntry = moduleCache.get(moduleId);
    var blocking = new Set;
    if (cacheEntry) {
      cacheEntry.blockingDeps.forEach(function(dep) {
        getTransitiveBlockingDepsOf(dep).forEach(function(transitive) {
          blocking.add(transitive);
        });
      });
    } else {
      blocking.add(moduleId);
    }
    return blocking;
  }
  var blockingModulePathToBlockedModules = new Map;
  function addAsBlocking(blocked, blocker) {
    if (blocked.module.id != blocker) {
      var blockedModules = blockingModulePathToBlockedModules.get(blocker);
      if (!blockedModules) {
        blockedModules = new Set;
        blockingModulePathToBlockedModules.set(blocker, blockedModules);
      }
      blockedModules.add(blocked);
      blocked.blockingDeps.add(blocker);
    }
  }
  function removeAsBlocking(cacheEntry) {
    var blocked = blockingModulePathToBlockedModules.get(cacheEntry.module.id);
    if (blocked) {
      blockingModulePathToBlockedModules["delete"](cacheEntry.module.id);
      blocked.forEach(function(blockedCacheEntry) {
        blockedCacheEntry.blockingDeps["delete"](cacheEntry.module.id);
        cacheEntry.blockingDeps.forEach(function(blocker) {
          addAsBlocking(blockedCacheEntry, blocker);
        });
        if (!blockedCacheEntry.blockingDeps.size) {
          removeAsBlocking(blockedCacheEntry);
          markAvailable(blockedCacheEntry.module.id);
        }
      });
    }
  }
  $jscomp.registerAndLoadModule = function(moduleDef, absModulePath, shallowDeps) {
    $jscomp.require.ensure([absModulePath], function(require) {
      require(absModulePath);
    });
    $jscomp.registerModule(moduleDef, absModulePath, shallowDeps);
  };
  $jscomp.registerEs6ModuleExports = function(absModulePath, exports) {
    if (moduleCache.has(absModulePath)) {
      throw new Error("Module at path " + absModulePath + " is already registered.");
    }
    var entry = new CacheEntry(null, new Module(absModulePath, exports), absModulePath);
    moduleCache.set(absModulePath, entry);
    markAvailable(absModulePath);
  };
  $jscomp.clearModules = function() {
    moduleCache.clear();
  };
})();
//node_modules/@webcomponents/webcomponents-platform/webcomponents-platform.js
/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

(function(scope) {

  'use strict';

  // defaultPrevented is broken in IE.
  // https://connect.microsoft.com/IE/feedback/details/790389/event-defaultprevented-returns-false-after-preventdefault-was-called
  var workingDefaultPrevented = (function() {
    var e = document.createEvent('Event');
    e.initEvent('foo', true, true);
    e.preventDefault();
    return e.defaultPrevented;
  })();

  if (!workingDefaultPrevented) {
    var origPreventDefault = Event.prototype.preventDefault;
    Event.prototype.preventDefault = function() {
      if (!this.cancelable) {
        return;
      }

      origPreventDefault.call(this);

      Object.defineProperty(this, 'defaultPrevented', {
        get: function() {
          return true;
        },
        configurable: true
      });
    };
  }

  var isIE = /Trident/.test(navigator.userAgent);

  // CustomEvent constructor shim
  if (!window.CustomEvent || isIE && (typeof window.CustomEvent !== 'function')) {
    window.CustomEvent = function(inType, params) {
      params = params || {};
      var e = document.createEvent('CustomEvent');
      e.initCustomEvent(inType, Boolean(params.bubbles), Boolean(params.cancelable), params.detail);
      return e;
    };
    window.CustomEvent.prototype = window.Event.prototype;
  }

  // Event constructor shim
  if (!window.Event || isIE && (typeof window.Event !== 'function')) {
    var origEvent = window.Event;
    window.Event = function(inType, params) {
      params = params || {};
      var e = document.createEvent('Event');
      e.initEvent(inType, Boolean(params.bubbles), Boolean(params.cancelable));
      return e;
    };
    if (origEvent) {
      for (var i in origEvent) {
        window.Event[i] = origEvent[i];
      }
    }
    window.Event.prototype = origEvent.prototype;
  }

  if (!window.MouseEvent || isIE && (typeof window.MouseEvent !== 'function')) {
    var origMouseEvent = window.MouseEvent;
    window.MouseEvent = function(inType, params) {
      params = params || {};
      var e = document.createEvent('MouseEvent');
      e.initMouseEvent(inType,
        Boolean(params.bubbles), Boolean(params.cancelable),
        params.view || window, params.detail,
        params.screenX, params.screenY, params.clientX, params.clientY,
        params.ctrlKey, params.altKey, params.shiftKey, params.metaKey,
        params.button, params.relatedTarget);
      return e;
    };
    if (origMouseEvent) {
      for (var i in origMouseEvent) {
        window.MouseEvent[i] = origMouseEvent[i];
      }
    }
    window.MouseEvent.prototype = origMouseEvent.prototype;
  }

  // ES6 stuff
  if (!Array.from) {
    Array.from = function (object) {
      return [].slice.call(object);
    };
  }

  if (!Object.assign) {
    var assign = function(target, source) {
      var n$ = Object.getOwnPropertyNames(source);
      for (var i=0, p; i < n$.length; i++) {
        p = n$[i];
        target[p] = source[p];
      }
    }

    Object.assign = function(target, sources) {
      var args = [].slice.call(arguments, 1);
      for (var i=0, s; i < args.length; i++) {
        s = args[i];
        if (s) {
          assign(target, s);
        }
      }
      return target;
    }
  }

})(window.WebComponents);

//node_modules/@webcomponents/template/template.js
/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

// minimal template polyfill
(function() {
  'use strict';

  var needsTemplate = (typeof HTMLTemplateElement === 'undefined');
  var brokenDocFragment = !(document.createDocumentFragment().cloneNode() instanceof DocumentFragment);
  var needsDocFrag = false;

  // NOTE: Replace DocumentFragment to work around IE11 bug that
  // causes children of a document fragment modified while
  // there is a mutation observer to not have a parentNode, or
  // have a broken parentNode (!?!)
  if (/Trident/.test(navigator.userAgent)) {
    (function() {

      needsDocFrag = true;

      var origCloneNode = Node.prototype.cloneNode;
      Node.prototype.cloneNode = function cloneNode(deep) {
        var newDom = origCloneNode.call(this, deep);
        if (this instanceof DocumentFragment) {
          newDom.__proto__ = DocumentFragment.prototype;
        }
        return newDom;
      };

      // IE's DocumentFragment querySelector code doesn't work when
      // called on an element instance
      DocumentFragment.prototype.querySelectorAll = HTMLElement.prototype.querySelectorAll;
      DocumentFragment.prototype.querySelector = HTMLElement.prototype.querySelector;

      Object.defineProperties(DocumentFragment.prototype, {
        'nodeType': {
          get: function () {
            return Node.DOCUMENT_FRAGMENT_NODE;
          },
          configurable: true
        },

        'localName': {
          get: function () {
            return undefined;
          },
          configurable: true
        },

        'nodeName': {
          get: function () {
            return '#document-fragment';
          },
          configurable: true
        }
      });

      var origInsertBefore = Node.prototype.insertBefore;
      function insertBefore(newNode, refNode) {
        if (newNode instanceof DocumentFragment) {
          var child;
          while ((child = newNode.firstChild)) {
            origInsertBefore.call(this, child, refNode);
          }
        } else {
          origInsertBefore.call(this, newNode, refNode);
        }
        return newNode;
      }
      Node.prototype.insertBefore = insertBefore;

      var origAppendChild = Node.prototype.appendChild;
      Node.prototype.appendChild = function appendChild(child) {
        if (child instanceof DocumentFragment) {
          insertBefore.call(this, child, null);
        } else {
          origAppendChild.call(this, child);
        }
        return child;
      };

      var origRemoveChild = Node.prototype.removeChild;
      var origReplaceChild = Node.prototype.replaceChild;
      Node.prototype.replaceChild = function replaceChild(newChild, oldChild) {
        if (newChild instanceof DocumentFragment) {
          insertBefore.call(this, newChild, oldChild);
          origRemoveChild.call(this, oldChild);
        } else {
          origReplaceChild.call(this, newChild, oldChild);
        }
        return oldChild;
      };

      Document.prototype.createDocumentFragment = function createDocumentFragment() {
        var frag = this.createElement('df');
        frag.__proto__ = DocumentFragment.prototype;
        return frag;
      };

      var origImportNode = Document.prototype.importNode;
      Document.prototype.importNode = function importNode(impNode, deep) {
        deep = deep || false;
        var newNode = origImportNode.call(this, impNode, deep);
        if (impNode instanceof DocumentFragment) {
          newNode.__proto__ = DocumentFragment.prototype;
        }
        return newNode;
      };
    })();
  }

  // NOTE: we rely on this cloneNode not causing element upgrade.
  // This means this polyfill must load before the CE polyfill and
  // this would need to be re-worked if a browser supports native CE
  // but not <template>.
  var capturedCloneNode = Node.prototype.cloneNode;
  var capturedCreateElement = Document.prototype.createElement;
  var capturedImportNode = Document.prototype.importNode;
  var capturedRemoveChild = Node.prototype.removeChild;
  var capturedAppendChild = Node.prototype.appendChild;
  var capturedReplaceChild = Node.prototype.replaceChild;
  var capturedParseFromString = DOMParser.prototype.parseFromString;
  var capturedHTMLElementInnerHTML = Object.getOwnPropertyDescriptor(window.HTMLElement.prototype, 'innerHTML') || {
    /**
     * @this {!HTMLElement}
     * @return {string}
     */
    get: function() {
      return this.innerHTML;
    },
    /**
     * @this {!HTMLElement}
     * @param {string}
     */
    set: function(text) {
      this.innerHTML = text;
    }
  };
  var capturedChildNodes = Object.getOwnPropertyDescriptor(window.Node.prototype, 'childNodes') || {
    /**
     * @this {!Node}
     * @return {!NodeList}
     */
    get: function() {
      return this.childNodes;
    }
  };

  var elementQuerySelectorAll = Element.prototype.querySelectorAll;
  var docQuerySelectorAll = Document.prototype.querySelectorAll;
  var fragQuerySelectorAll = DocumentFragment.prototype.querySelectorAll;

  var scriptSelector = 'script:not([type]),script[type="application/javascript"],script[type="text/javascript"]';

  function QSA(node, selector) {
    // IE 11 throws a SyntaxError with `scriptSelector` if the node has no children due to the `:not([type])` syntax
    if (!node.childNodes.length) {
      return [];
    }
    switch (node.nodeType) {
      case Node.DOCUMENT_NODE:
        return docQuerySelectorAll.call(node, selector);
      case Node.DOCUMENT_FRAGMENT_NODE:
        return fragQuerySelectorAll.call(node, selector);
      default:
        return elementQuerySelectorAll.call(node, selector);
    }
  }

  // returns true if nested templates cannot be cloned (they cannot be on
  // some impl's like Safari 8 and Edge)
  // OR if cloning a document fragment does not result in a document fragment
  var needsCloning = (function() {
    if (!needsTemplate) {
      var t = document.createElement('template');
      var t2 = document.createElement('template');
      t2.content.appendChild(document.createElement('div'));
      t.content.appendChild(t2);
      var clone = t.cloneNode(true);
      return (clone.content.childNodes.length === 0 || clone.content.firstChild.content.childNodes.length === 0
        || brokenDocFragment);
    }
  })();

  var TEMPLATE_TAG = 'template';
  var PolyfilledHTMLTemplateElement = function() {};

  if (needsTemplate) {

    var contentDoc = document.implementation.createHTMLDocument('template');
    var canDecorate = true;

    var templateStyle = document.createElement('style');
    templateStyle.textContent = TEMPLATE_TAG + '{display:none;}';

    var head = document.head;
    head.insertBefore(templateStyle, head.firstElementChild);

    /**
      Provides a minimal shim for the <template> element.
    */
    PolyfilledHTMLTemplateElement.prototype = Object.create(HTMLElement.prototype);


    // if elements do not have `innerHTML` on instances, then
    // templates can be patched by swizzling their prototypes.
    var canProtoPatch =
      !(document.createElement('div').hasOwnProperty('innerHTML'));

    /**
      The `decorate` method moves element children to the template's `content`.
      NOTE: there is no support for dynamically adding elements to templates.
    */
    PolyfilledHTMLTemplateElement.decorate = function(template) {
      // if the template is decorated or not in HTML namespace, return fast
      if (template.content ||
          template.namespaceURI !== document.documentElement.namespaceURI) {
        return;
      }
      template.content = contentDoc.createDocumentFragment();
      var child;
      while ((child = template.firstChild)) {
        capturedAppendChild.call(template.content, child);
      }
      // NOTE: prefer prototype patching for performance and
      // because on some browsers (IE11), re-defining `innerHTML`
      // can result in intermittent errors.
      if (canProtoPatch) {
        template.__proto__ = PolyfilledHTMLTemplateElement.prototype;
      } else {
        template.cloneNode = function(deep) {
          return PolyfilledHTMLTemplateElement._cloneNode(this, deep);
        };
        // add innerHTML to template, if possible
        // Note: this throws on Safari 7
        if (canDecorate) {
          try {
            defineInnerHTML(template);
            defineOuterHTML(template);
          } catch (err) {
            canDecorate = false;
          }
        }
      }
      // bootstrap recursively
      PolyfilledHTMLTemplateElement.bootstrap(template.content);
    };

    // Taken from https://github.com/jquery/jquery/blob/73d7e6259c63ac45f42c6593da8c2796c6ce9281/src/manipulation/wrapMap.js
    var topLevelWrappingMap = {
      'option': ['select'],
      'thead': ['table'],
      'col': ['colgroup', 'table'],
      'tr': ['tbody', 'table'],
      'th': ['tr', 'tbody', 'table'],
      'td': ['tr', 'tbody', 'table']
    };

    var getTagName = function(text) {
      // Taken from https://github.com/jquery/jquery/blob/73d7e6259c63ac45f42c6593da8c2796c6ce9281/src/manipulation/var/rtagName.js
      return ( /<([a-z][^/\0>\x20\t\r\n\f]+)/i.exec(text) || ['', ''])[1].toLowerCase();
    };

    var defineInnerHTML = function defineInnerHTML(obj) {
      Object.defineProperty(obj, 'innerHTML', {
        get: function() {
          return getInnerHTML(this);
        },
        set: function(text) {
          // For IE11, wrap the text in the correct (table) context
          var wrap = topLevelWrappingMap[getTagName(text)];
          if (wrap) {
            for (var i = 0; i < wrap.length; i++) {
              text = '<' + wrap[i] + '>' + text + '</' + wrap[i] + '>';
            }
          }
          contentDoc.body.innerHTML = text;
          PolyfilledHTMLTemplateElement.bootstrap(contentDoc);
          while (this.content.firstChild) {
            capturedRemoveChild.call(this.content, this.content.firstChild);
          }
          var body = contentDoc.body;
          // If we had wrapped, get back to the original node
          if (wrap) {
            for (var j = 0; j < wrap.length; j++) {
              body = body.lastChild;
            }
          }
          while (body.firstChild) {
            capturedAppendChild.call(this.content, body.firstChild);
          }
        },
        configurable: true
      });
    };

    var defineOuterHTML = function defineOuterHTML(obj) {
      Object.defineProperty(obj, 'outerHTML', {
        get: function() {
          return '<' + TEMPLATE_TAG + '>' + this.innerHTML + '</' + TEMPLATE_TAG + '>';
        },
        set: function(innerHTML) {
          if (this.parentNode) {
            contentDoc.body.innerHTML = innerHTML;
            var docFrag = this.ownerDocument.createDocumentFragment();
            while (contentDoc.body.firstChild) {
              capturedAppendChild.call(docFrag, contentDoc.body.firstChild);
            }
            capturedReplaceChild.call(this.parentNode, docFrag, this);
          } else {
            throw new Error("Failed to set the 'outerHTML' property on 'Element': This element has no parent node.");
          }
        },
        configurable: true
      });
    };

    defineInnerHTML(PolyfilledHTMLTemplateElement.prototype);
    defineOuterHTML(PolyfilledHTMLTemplateElement.prototype);

    /**
      The `bootstrap` method is called automatically and "fixes" all
      <template> elements in the document referenced by the `doc` argument.
    */
    PolyfilledHTMLTemplateElement.bootstrap = function bootstrap(doc) {
      var templates = QSA(doc, TEMPLATE_TAG);
      for (var i=0, l=templates.length, t; (i<l) && (t=templates[i]); i++) {
        PolyfilledHTMLTemplateElement.decorate(t);
      }
    };

    // auto-bootstrapping for main document
    document.addEventListener('DOMContentLoaded', function() {
      PolyfilledHTMLTemplateElement.bootstrap(document);
    });

    // Patch document.createElement to ensure newly created templates have content
    Document.prototype.createElement = function createElement() {
      var el = capturedCreateElement.apply(this, arguments);
      if (el.localName === 'template') {
        PolyfilledHTMLTemplateElement.decorate(el);
      }
      return el;
    };

    DOMParser.prototype.parseFromString = function() {
      var el = capturedParseFromString.apply(this, arguments);
      PolyfilledHTMLTemplateElement.bootstrap(el);
      return el;
    };

    Object.defineProperty(HTMLElement.prototype, 'innerHTML', {
      get: function() {
        return getInnerHTML(this);
      },
      set: function(text) {
        capturedHTMLElementInnerHTML.set.call(this, text);
        PolyfilledHTMLTemplateElement.bootstrap(this);
      },
      configurable: true,
      enumerable: true
    });

    // http://www.whatwg.org/specs/web-apps/current-work/multipage/the-end.html#escapingString
    var escapeAttrRegExp = /[&\u00A0"]/g;
    var escapeDataRegExp = /[&\u00A0<>]/g;

    var escapeReplace = function(c) {
      switch (c) {
        case '&':
          return '&amp;';
        case '<':
          return '&lt;';
        case '>':
          return '&gt;';
        case '"':
          return '&quot;';
        case '\u00A0':
          return '&nbsp;';
      }
    };

    var escapeAttr = function(s) {
      return s.replace(escapeAttrRegExp, escapeReplace);
    };

    var escapeData = function(s) {
      return s.replace(escapeDataRegExp, escapeReplace);
    };

    var makeSet = function(arr) {
      var set = {};
      for (var i = 0; i < arr.length; i++) {
        set[arr[i]] = true;
      }
      return set;
    };

    // http://www.whatwg.org/specs/web-apps/current-work/#void-elements
    var voidElements = makeSet([
      'area',
      'base',
      'br',
      'col',
      'command',
      'embed',
      'hr',
      'img',
      'input',
      'keygen',
      'link',
      'meta',
      'param',
      'source',
      'track',
      'wbr'
    ]);

    var plaintextParents = makeSet([
      'style',
      'script',
      'xmp',
      'iframe',
      'noembed',
      'noframes',
      'plaintext',
      'noscript'
    ]);

    /**
     * @param {Node} node
     * @param {Node} parentNode
     * @param {Function=} callback
     */
    var getOuterHTML = function(node, parentNode, callback) {
      switch (node.nodeType) {
        case Node.ELEMENT_NODE: {
          var tagName = node.localName;
          var s = '<' + tagName;
          var attrs = node.attributes;
          for (var i = 0, attr; (attr = attrs[i]); i++) {
            s += ' ' + attr.name + '="' + escapeAttr(attr.value) + '"';
          }
          s += '>';
          if (voidElements[tagName]) {
            return s;
          }
          return s + getInnerHTML(node, callback) + '</' + tagName + '>';
        }
        case Node.TEXT_NODE: {
          var data = /** @type {Text} */ (node).data;
          if (parentNode && plaintextParents[parentNode.localName]) {
            return data;
          }
          return escapeData(data);
        }
        case Node.COMMENT_NODE: {
          return '<!--' + /** @type {Comment} */ (node).data + '-->';
        }
        default: {
          window.console.error(node);
          throw new Error('not implemented');
        }
      }
    };

    /**
     * @param {Node} node
     * @param {Function=} callback
     */
    var getInnerHTML = function(node, callback) {
      if (node.localName === 'template') {
        node =  /** @type {HTMLTemplateElement} */ (node).content;
      }
      var s = '';
      var c$ = callback ? callback(node) : capturedChildNodes.get.call(node);
      for (var i=0, l=c$.length, child; (i<l) && (child=c$[i]); i++) {
        s += getOuterHTML(child, node, callback);
      }
      return s;
    };

  }

  // make cloning/importing work!
  if (needsTemplate || needsCloning) {

    PolyfilledHTMLTemplateElement._cloneNode = function _cloneNode(template, deep) {
      var clone = capturedCloneNode.call(template, false);
      // NOTE: decorate doesn't auto-fix children because they are already
      // decorated so they need special clone fixup.
      if (this.decorate) {
        this.decorate(clone);
      }
      if (deep) {
        // NOTE: use native clone node to make sure CE's wrapped
        // cloneNode does not cause elements to upgrade.
        capturedAppendChild.call(clone.content, capturedCloneNode.call(template.content, true));
        // now ensure nested templates are cloned correctly.
        fixClonedDom(clone.content, template.content);
      }
      return clone;
    };

    // Given a source and cloned subtree, find <template>'s in the cloned
    // subtree and replace them with cloned <template>'s from source.
    // We must do this because only the source templates have proper .content.
    var fixClonedDom = function fixClonedDom(clone, source) {
      // do nothing if cloned node is not an element
      if (!source.querySelectorAll) return;
      // these two lists should be coincident
      var s$ = QSA(source, TEMPLATE_TAG);
      if (s$.length === 0) {
        return;
      }
      var t$ = QSA(clone, TEMPLATE_TAG);
      for (var i=0, l=t$.length, t, s; i<l; i++) {
        s = s$[i];
        t = t$[i];
        if (PolyfilledHTMLTemplateElement && PolyfilledHTMLTemplateElement.decorate) {
          PolyfilledHTMLTemplateElement.decorate(s);
        }
        capturedReplaceChild.call(t.parentNode, cloneNode.call(s, true), t);
      }
    };

    // make sure scripts inside of a cloned template are executable
    var fixClonedScripts = function fixClonedScripts(fragment) {
      var scripts = QSA(fragment, scriptSelector);
      for (var ns, s, i = 0; i < scripts.length; i++) {
        s = scripts[i];
        ns = capturedCreateElement.call(document, 'script');
        ns.textContent = s.textContent;
        var attrs = s.attributes;
        for (var ai = 0, a; ai < attrs.length; ai++) {
          a = attrs[ai];
          ns.setAttribute(a.name, a.value);
        }
        capturedReplaceChild.call(s.parentNode, ns, s);
      }
    };

    // override all cloning to fix the cloned subtree to contain properly
    // cloned templates.
    var cloneNode = Node.prototype.cloneNode = function cloneNode(deep) {
      var dom;
      // workaround for Edge bug cloning documentFragments
      // https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/8619646/
      if (!needsDocFrag && brokenDocFragment && this instanceof DocumentFragment) {
        if (!deep) {
          return this.ownerDocument.createDocumentFragment();
        } else {
          dom = importNode.call(this.ownerDocument, this, true);
        }
      } else if (this.nodeType === Node.ELEMENT_NODE &&
                 this.localName === TEMPLATE_TAG &&
                 this.namespaceURI == document.documentElement.namespaceURI) {
        dom = PolyfilledHTMLTemplateElement._cloneNode(this, deep);
      } else {
        dom = capturedCloneNode.call(this, deep);
      }
      // template.content is cloned iff `deep`.
      if (deep) {
        fixClonedDom(dom, this);
      }
      return dom;
    };

    // NOTE: we are cloning instead of importing <template>'s.
    // However, the ownerDocument of the cloned template will be correct!
    // This is because the native import node creates the right document owned
    // subtree and `fixClonedDom` inserts cloned templates into this subtree,
    // thus updating the owner doc.
    var importNode = Document.prototype.importNode = function importNode(element, deep) {
      deep = deep || false;
      if (element.localName === TEMPLATE_TAG) {
        return PolyfilledHTMLTemplateElement._cloneNode(element, deep);
      } else {
        var dom = capturedImportNode.call(this, element, deep);
        if (deep) {
          fixClonedDom(dom, element);
          fixClonedScripts(dom);
        }
        return dom;
      }
    };
  }

  if (needsTemplate) {
    window.HTMLTemplateElement = PolyfilledHTMLTemplateElement;
  }

})();

//node_modules/promise-polyfill/src/finally.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  function finallyConstructor(callback) {
    var constructor = this.constructor;
    return this.then(function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    }, function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    });
  }
  const $$default = finallyConstructor;
}, "node_modules/promise-polyfill/src/finally.js", []);

//node_modules/promise-polyfill/src/index.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$promise_polyfill$src$finally = $$require("node_modules/promise-polyfill/src/finally.js");
  var setTimeoutFunc = setTimeout;
  function noop() {
  }
  function bind(fn, thisArg) {
    return function() {
      fn.apply(thisArg, arguments);
    };
  }
  function Promise(fn) {
    if (!(this instanceof Promise)) {
      throw new TypeError("Promises must be constructed via new");
    }
    if (typeof fn !== "function") {
      throw new TypeError("not a function");
    }
    this._state = 0;
    this._handled = false;
    this._value = undefined;
    this._deferreds = [];
    doResolve(fn, this);
  }
  function handle(self, deferred) {
    while (self._state === 3) {
      self = self._value;
    }
    if (self._state === 0) {
      self._deferreds.push(deferred);
      return;
    }
    self._handled = true;
    Promise._immediateFn(function() {
      var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
      if (cb === null) {
        (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
        return;
      }
      var ret;
      try {
        ret = cb(self._value);
      } catch (e) {
        reject(deferred.promise, e);
        return;
      }
      resolve(deferred.promise, ret);
    });
  }
  function resolve(self, newValue) {
    try {
      if (newValue === self) {
        throw new TypeError("A promise cannot be resolved with itself.");
      }
      if (newValue && (typeof newValue === "object" || typeof newValue === "function")) {
        var then = newValue.then;
        if (newValue instanceof Promise) {
          self._state = 3;
          self._value = newValue;
          finale(self);
          return;
        } else {
          if (typeof then === "function") {
            doResolve(bind(then, newValue), self);
            return;
          }
        }
      }
      self._state = 1;
      self._value = newValue;
      finale(self);
    } catch (e) {
      reject(self, e);
    }
  }
  function reject(self, newValue) {
    self._state = 2;
    self._value = newValue;
    finale(self);
  }
  function finale(self) {
    if (self._state === 2 && self._deferreds.length === 0) {
      Promise._immediateFn(function() {
        if (!self._handled) {
          Promise._unhandledRejectionFn(self._value);
        }
      });
    }
    for (var i = 0, len = self._deferreds.length; i < len; i++) {
      handle(self, self._deferreds[i]);
    }
    self._deferreds = null;
  }
  function Handler(onFulfilled, onRejected, promise) {
    this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
    this.onRejected = typeof onRejected === "function" ? onRejected : null;
    this.promise = promise;
  }
  function doResolve(fn, self) {
    var done = false;
    try {
      fn(function(value) {
        if (done) {
          return;
        }
        done = true;
        resolve(self, value);
      }, function(reason) {
        if (done) {
          return;
        }
        done = true;
        reject(self, reason);
      });
    } catch (ex) {
      if (done) {
        return;
      }
      done = true;
      reject(self, ex);
    }
  }
  Promise.prototype["catch"] = function(onRejected) {
    return this.then(null, onRejected);
  };
  Promise.prototype.then = function(onFulfilled, onRejected) {
    var prom = new this.constructor(noop);
    handle(this, new Handler(onFulfilled, onRejected, prom));
    return prom;
  };
  Promise.prototype["finally"] = module$node_modules$promise_polyfill$src$finally["default"];
  Promise.all = function(arr) {
    return new Promise(function(resolve, reject) {
      if (!arr || typeof arr.length === "undefined") {
        throw new TypeError("Promise.all accepts an array");
      }
      var args = Array.prototype.slice.call(arr);
      if (args.length === 0) {
        return resolve([]);
      }
      var remaining = args.length;
      function res(i, val) {
        try {
          if (val && (typeof val === "object" || typeof val === "function")) {
            var then = val.then;
            if (typeof then === "function") {
              then.call(val, function(val) {
                res(i, val);
              }, reject);
              return;
            }
          }
          args[i] = val;
          if (--remaining === 0) {
            resolve(args);
          }
        } catch (ex) {
          reject(ex);
        }
      }
      for (var i = 0; i < args.length; i++) {
        res(i, args[i]);
      }
    });
  };
  Promise.resolve = function(value) {
    if (value && typeof value === "object" && value.constructor === Promise) {
      return value;
    }
    return new Promise(function(resolve) {
      resolve(value);
    });
  };
  Promise.reject = function(value) {
    return new Promise(function(resolve, reject) {
      reject(value);
    });
  };
  Promise.race = function(values) {
    return new Promise(function(resolve, reject) {
      for (var i = 0, len = values.length; i < len; i++) {
        values[i].then(resolve, reject);
      }
    });
  };
  Promise._immediateFn = typeof setImmediate === "function" && function(fn) {
    setImmediate(fn);
  } || function(fn) {
    setTimeoutFunc(fn, 0);
  };
  Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
    if (typeof console !== "undefined" && console) {
      console.warn("Possible Unhandled Promise Rejection:", err);
    }
  };
  const $$default = Promise;
}, "node_modules/promise-polyfill/src/index.js", ["node_modules/promise-polyfill/src/finally.js"]);

//src/promise.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  var module$node_modules$promise_polyfill$src$index = $$require("node_modules/promise-polyfill/src/index.js");
  if (!window.Promise) {
    window.Promise = module$node_modules$promise_polyfill$src$index["default"];
    module$node_modules$promise_polyfill$src$index["default"].prototype["then"] = module$node_modules$promise_polyfill$src$index["default"].prototype.then;
    module$node_modules$promise_polyfill$src$index["default"]["all"] = module$node_modules$promise_polyfill$src$index["default"].all;
    module$node_modules$promise_polyfill$src$index["default"]["race"] = module$node_modules$promise_polyfill$src$index["default"].race;
    module$node_modules$promise_polyfill$src$index["default"]["resolve"] = module$node_modules$promise_polyfill$src$index["default"].resolve;
    module$node_modules$promise_polyfill$src$index["default"]["reject"] = module$node_modules$promise_polyfill$src$index["default"].reject;
    const node = document.createTextNode("");
    const twiddleNode = function twiddleNode() {
      node.textContent = node.textContent.length > 0 ? "" : "a";
    };
    const callbacks = [];
    (new MutationObserver(() => {
      const len = callbacks.length;
      for (let i = 0; i < len; i++) {
        callbacks[i]();
      }
      callbacks.splice(0, len);
    })).observe(node, {characterData:true});
    module$node_modules$promise_polyfill$src$index["default"]._immediateFn = (fn) => {
      callbacks.push(fn);
      twiddleNode();
    };
  }
}, "src/promise.js", ["node_modules/promise-polyfill/src/index.js"]);

//node_modules/@webcomponents/html-imports/src/html-imports.js
/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */
(scope => {

  /********************* base setup *********************/
  const link = document.createElement('link');
  const useNative = Boolean('import' in link);
  const emptyNodeList = link.querySelectorAll('*');

  // Polyfill `currentScript` for browsers without it.
  let currentScript = null;
  if ('currentScript' in document === false) {
    Object.defineProperty(document, 'currentScript', {
      get() {
        return currentScript ||
          // NOTE: only works when called in synchronously executing code.
          // readyState should check if `loading` but IE10 is
          // interactive when scripts run so we cheat. This is not needed by
          // html-imports polyfill but helps generally polyfill `currentScript`.
          (document.readyState !== 'complete' ?
            document.scripts[document.scripts.length - 1] : null);
      },
      configurable: true
    });
  }

  /**
   * @param {Array|NodeList|NamedNodeMap} list
   * @param {!Function} callback
   * @param {boolean=} inverseOrder
   */
  const forEach = (list, callback, inverseOrder) => {
    const length = list ? list.length : 0;
    const increment = inverseOrder ? -1 : 1;
    let i = inverseOrder ? length - 1 : 0;
    for (; i < length && i >= 0; i = i + increment) {
      callback(list[i], i);
    }
  };

  /**
   * @param {!Node} node
   * @param {!string} selector
   * @return {!NodeList<!Element>}
   */
  const QSA = (node, selector) => {
    // IE 11 throws a SyntaxError if a node with no children is queried with
    // a selector containing the `:not([type])` syntax.
    if (!node.childNodes.length) {
      return emptyNodeList;
    }
    return node.querySelectorAll(selector);
  };

  /**
   * @param {!DocumentFragment} fragment
   */
  const replaceScripts = (fragment) => {
    forEach(QSA(fragment, 'template'), template => {
      forEach(QSA(template.content, scriptsSelector), script => {
        const clone = /** @type {!HTMLScriptElement} */
          (document.createElement('script'));
        forEach(script.attributes, attr => clone.setAttribute(attr.name, attr.value));
        clone.textContent = script.textContent;
        script.parentNode.replaceChild(clone, script);
      });
      replaceScripts(template.content);
    });
  };

  /********************* path fixup *********************/
  const CSS_URL_REGEXP = /(url\()([^)]*)(\))/g;
  const CSS_IMPORT_REGEXP = /(@import[\s]+(?!url\())([^;]*)(;)/g;
  const STYLESHEET_REGEXP = /(<link[^>]*)(rel=['|"]?stylesheet['|"]?[^>]*>)/g;

  // path fixup: style elements in imports must be made relative to the main
  // document. We fixup url's in url() and @import.
  const Path = {

    fixUrls(element, base) {
      if (element.href) {
        element.setAttribute('href',
          Path.resolveUrl(element.getAttribute('href'), base));
      }
      if (element.src) {
        element.setAttribute('src',
          Path.resolveUrl(element.getAttribute('src'), base));
      }
      if (element.localName === 'style') {
        const r = Path.replaceUrls(element.textContent, base, CSS_URL_REGEXP);
        element.textContent = Path.replaceUrls(r, base, CSS_IMPORT_REGEXP);
      }
    },

    replaceUrls(text, linkUrl, regexp) {
      return text.replace(regexp, (m, pre, url, post) => {
        let urlPath = url.replace(/["']/g, '');
        if (linkUrl) {
          urlPath = Path.resolveUrl(urlPath, linkUrl);
        }
        return pre + '\'' + urlPath + '\'' + post;
      });
    },

    resolveUrl(url, base) {
      // Lazy feature detection.
      if (Path.__workingURL === undefined) {
        Path.__workingURL = false;
        try {
          const u = new URL('b', 'http://a');
          u.pathname = 'c%20d';
          Path.__workingURL = (u.href === 'http://a/c%20d');
        } catch (e) {}
      }

      if (Path.__workingURL) {
        return (new URL(url, base)).href;
      }

      // Fallback to creating an anchor into a disconnected document.
      let doc = Path.__tempDoc;
      if (!doc) {
        doc = document.implementation.createHTMLDocument('temp');
        Path.__tempDoc = doc;
        doc.__base = doc.createElement('base');
        doc.head.appendChild(doc.__base);
        doc.__anchor = doc.createElement('a');
      }
      doc.__base.href = base;
      doc.__anchor.href = url;
      return doc.__anchor.href || url;
    }
  };

  /********************* Xhr processor *********************/
  const Xhr = {

    async: true,

    /**
     * @param {!string} url
     * @param {!function(!string, string=)} success
     * @param {!function(!string)} fail
     */
    load(url, success, fail) {
      if (!url) {
        fail('error: href must be specified');
      } else if (url.match(/^data:/)) {
        // Handle Data URI Scheme
        const pieces = url.split(',');
        const header = pieces[0];
        let resource = pieces[1];
        if (header.indexOf(';base64') > -1) {
          resource = atob(resource);
        } else {
          resource = decodeURIComponent(resource);
        }
        success(resource);
      } else {
        const request = new XMLHttpRequest();
        request.open('GET', url, Xhr.async);
        request.onload = () => {
          // Servers redirecting an import can add a Location header to help us
          // polyfill correctly. Handle relative and full paths.
          // Prefer responseURL which already resolves redirects
          // https://xhr.spec.whatwg.org/#the-responseurl-attribute
          let redirectedUrl = request.responseURL || request.getResponseHeader('Location');
          if (redirectedUrl && redirectedUrl.indexOf('/') === 0) {
            // In IE location.origin might not work
            // https://connect.microsoft.com/IE/feedback/details/1763802/location-origin-is-undefined-in-ie-11-on-windows-10-but-works-on-windows-7
            const origin = (location.origin || location.protocol + '//' + location.host);
            redirectedUrl = origin + redirectedUrl;
          }
          const resource = /** @type {string} */ (request.response || request.responseText);
          if (request.status === 304 || request.status === 0 ||
            request.status >= 200 && request.status < 300) {
            success(resource, redirectedUrl);
          } else {
            fail(resource);
          }
        };
        request.send();
      }
    }
  };

  /********************* importer *********************/

  const isIE = /Trident/.test(navigator.userAgent) ||
    /Edge\/\d./i.test(navigator.userAgent);

  const importSelector = 'link[rel=import]';

  // Used to disable loading of resources.
  const importDisableType = 'import-disable';

  const disabledLinkSelector = `link[rel=stylesheet][href][type=${importDisableType}]`;

  const scriptsSelector = `script:not([type]),script[type="application/javascript"],` +
    `script[type="text/javascript"],script[type="module"]`;

  const importDependenciesSelector = `${importSelector},${disabledLinkSelector},` +
    `style:not([type]),link[rel=stylesheet][href]:not([type]),` + scriptsSelector;

  const importDependencyAttr = 'import-dependency';

  const rootImportSelector = `${importSelector}:not([${importDependencyAttr}])`;

  const pendingScriptsSelector = `script[${importDependencyAttr}]`;

  const pendingStylesSelector = `style[${importDependencyAttr}],` +
    `link[rel=stylesheet][${importDependencyAttr}]`;

  /**
   * Importer will:
   * - load any linked import documents (with deduping)
   * - whenever an import is loaded, prompt the parser to try to parse
   * - observe imported documents for new elements (these are handled via the
   *   dynamic importer)
   */
  class Importer {
    constructor() {
      this.documents = {};
      // Used to keep track of pending loads, so that flattening and firing of
      // events can be done when all resources are ready.
      this.inflight = 0;
      this.dynamicImportsMO = new MutationObserver(m => this.handleMutations(m));
      // Observe changes on <head>.
      this.dynamicImportsMO.observe(document.head, {
        childList: true,
        subtree: true
      });
      // 1. Load imports contents
      // 2. Assign them to first import links on the document
      // 3. Wait for import styles & scripts to be done loading/running
      // 4. Fire load/error events
      this.loadImports(document);
    }

    /**
     * @param {!(HTMLDocument|DocumentFragment|Element)} doc
     */
    loadImports(doc) {
      const links = /** @type {!NodeList<!HTMLLinkElement>} */
        (QSA(doc, importSelector));
      forEach(links, link => this.loadImport(link));
    }

    /**
     * @param {!HTMLLinkElement} link
     */
    loadImport(link) {
      const url = link.href;
      // This resource is already being handled by another import.
      if (this.documents[url] !== undefined) {
        // If import is already loaded, we can safely associate it to the link
        // and fire the load/error event.
        const imp = this.documents[url];
        if (imp && imp['__loaded']) {
          link['__import'] = imp;
          this.fireEventIfNeeded(link);
        }
        return;
      }
      this.inflight++;
      // Mark it as pending to notify others this url is being loaded.
      this.documents[url] = 'pending';
      Xhr.load(url, (resource, redirectedUrl) => {
        const doc = this.makeDocument(resource, redirectedUrl || url);
        this.documents[url] = doc;
        this.inflight--;
        // Load subtree.
        this.loadImports(doc);
        this.processImportsIfLoadingDone();
      }, () => {
        // If load fails, handle error.
        this.documents[url] = null;
        this.inflight--;
        this.processImportsIfLoadingDone();
      });
    }

    /**
     * Creates a new document containing resource and normalizes urls accordingly.
     * @param {string=} resource
     * @param {string=} url
     * @return {!DocumentFragment}
     */
    makeDocument(resource, url) {
      if (!resource) {
        return document.createDocumentFragment();
      }

      if (isIE) {
        // <link rel=stylesheet> should be appended to <head>. Not doing so
        // in IE/Edge breaks the cascading order. We disable the loading by
        // setting the type before setting innerHTML to avoid loading
        // resources twice.
        resource = resource.replace(STYLESHEET_REGEXP, (match, p1, p2) => {
          if (match.indexOf('type=') === -1) {
            return `${p1} type=${importDisableType} ${p2}`;
          }
          return match;
        });
      }

      let content;
      const template = /** @type {!HTMLTemplateElement} */
        (document.createElement('template'));
      template.innerHTML = resource;
      if (template.content) {
        content = template.content;
        // Clone scripts inside templates since they won't execute when the
        // hosting template is cloned.
        replaceScripts(content);
      } else {
        // <template> not supported, create fragment and move content into it.
        content = document.createDocumentFragment();
        while (template.firstChild) {
          content.appendChild(template.firstChild);
        }
      }

      // Support <base> in imported docs. Resolve url and remove its href.
      const baseEl = content.querySelector('base');
      if (baseEl) {
        url = Path.resolveUrl(baseEl.getAttribute('href'), url);
        baseEl.removeAttribute('href');
      }

      const n$ = /** @type {!NodeList<!(HTMLLinkElement|HTMLScriptElement|HTMLStyleElement)>} */
        (QSA(content, importDependenciesSelector));
      // For source map hints.
      let inlineScriptIndex = 0;
      forEach(n$, n => {
        // Listen for load/error events, then fix urls.
        whenElementLoaded(n);
        Path.fixUrls(n, url);
        // Mark for easier selectors.
        n.setAttribute(importDependencyAttr, '');
        // Generate source map hints for inline scripts.
        if (n.localName === 'script' && !n.src && n.textContent) {
          if(n.type === 'module') {
            throw new Error('Inline module scripts are not supported in HTML Imports.');
          }
          const num = inlineScriptIndex ? `-${inlineScriptIndex}` : '';
          const content = n.textContent + `\n//# sourceURL=${url}${num}.js\n`;
          // We use the src attribute so it triggers load/error events, and it's
          // easier to capture errors (e.g. parsing) like this.
          n.setAttribute('src', 'data:text/javascript;charset=utf-8,' + encodeURIComponent(content));
          n.textContent = '';
          inlineScriptIndex++;
        }
      });
      return content;
    }

    /**
     * Waits for loaded imports to finish loading scripts and styles, then fires
     * the load/error events.
     */
    processImportsIfLoadingDone() {
      // Wait until all resources are ready, then load import resources.
      if (this.inflight) return;

      // Stop observing, flatten & load resource, then restart observing <head>.
      this.dynamicImportsMO.disconnect();
      this.flatten(document);
      // We wait for styles to load, and at the same time we execute the scripts,
      // then fire the load/error events for imports to have faster whenReady
      // callback execution.
      // NOTE: This is different for native behavior where scripts would be
      // executed after the styles before them are loaded.
      // To achieve that, we could select pending styles and scripts in the
      // document and execute them sequentially in their dom order.
      let scriptsOk = false,
        stylesOk = false;
      const onLoadingDone = () => {
        if (stylesOk && scriptsOk) {
          // Catch any imports that might have been added while we
          // weren't looking, wait for them as well.
          this.loadImports(document);
          if (this.inflight) return;

          // Restart observing.
          this.dynamicImportsMO.observe(document.head, {
            childList: true,
            subtree: true
          });
          this.fireEvents();
        }
      }
      this.waitForStyles(() => {
        stylesOk = true;
        onLoadingDone();
      });
      this.runScripts(() => {
        scriptsOk = true;
        onLoadingDone();
      });
    }

    /**
     * @param {!HTMLDocument} doc
     */
    flatten(doc) {
      const n$ = /** @type {!NodeList<!HTMLLinkElement>} */
        (QSA(doc, importSelector));
      forEach(n$, n => {
        const imp = this.documents[n.href];
        n['__import'] = /** @type {!Document} */ (imp);
        if (imp && imp.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
          // We set the .import to be the link itself, and update its readyState.
          // Other links with the same href will point to this link.
          this.documents[n.href] = n;
          n.readyState = 'loading';
          n['__import'] = n;
          this.flatten(imp);
          n.appendChild(imp);
        }
      });
    }

    /**
     * Replaces all the imported scripts with a clone in order to execute them.
     * Updates the `currentScript`.
     * @param {!function()} callback
     */
    runScripts(callback) {
      const s$ = QSA(document, pendingScriptsSelector);
      const l = s$.length;
      const cloneScript = i => {
        if (i < l) {
          // The pending scripts have been generated through innerHTML and
          // browsers won't execute them for security reasons. We cannot use
          // s.cloneNode(true) either, the only way to run the script is manually
          // creating a new element and copying its attributes.
          const s = s$[i];
          const clone = /** @type {!HTMLScriptElement} */
            (document.createElement('script'));
          // Remove import-dependency attribute to avoid double cloning.
          s.removeAttribute(importDependencyAttr);
          forEach(s.attributes, attr => clone.setAttribute(attr.name, attr.value));
          // Update currentScript and replace original with clone script.
          currentScript = clone;
          s.parentNode.replaceChild(clone, s);
          whenElementLoaded(clone, () => {
            currentScript = null;
            cloneScript(i + 1);
          });
        } else {
          callback();
        }
      };
      cloneScript(0);
    }

    /**
     * Waits for all the imported stylesheets/styles to be loaded.
     * @param {!function()} callback
     */
    waitForStyles(callback) {
      const s$ = /** @type {!NodeList<!(HTMLLinkElement|HTMLStyleElement)>} */
        (QSA(document, pendingStylesSelector));
      let pending = s$.length;
      if (!pending) {
        callback();
        return;
      }
      // <link rel=stylesheet> should be appended to <head>. Not doing so
      // in IE/Edge breaks the cascading order
      // https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/10472273/
      // If there is one <link rel=stylesheet> imported, we must move all imported
      // links and styles to <head>.
      const needsMove = isIE && !!document.querySelector(disabledLinkSelector);
      forEach(s$, s => {
        // Listen for load/error events, remove selector once is done loading.
        whenElementLoaded(s, () => {
          s.removeAttribute(importDependencyAttr);
          if (--pending === 0) {
            callback();
          }
        });
        // Check if was already moved to head, to handle the case where the element
        // has already been moved but it is still loading.
        if (needsMove && s.parentNode !== document.head) {
          // Replace the element we're about to move with a placeholder.
          const placeholder = document.createElement(s.localName);
          // Add reference of the moved element.
          placeholder['__appliedElement'] = s;
          // Disable this from appearing in document.styleSheets.
          placeholder.setAttribute('type', 'import-placeholder');
          // Append placeholder next to the sibling, and move original to <head>.
          s.parentNode.insertBefore(placeholder, s.nextSibling);
          let newSibling = importForElement(s);
          while (newSibling && importForElement(newSibling)) {
            newSibling = importForElement(newSibling);
          }
          if (newSibling.parentNode !== document.head) {
            newSibling = null;
          }
          document.head.insertBefore(s, newSibling);
          // Enable the loading of <link rel=stylesheet>.
          s.removeAttribute('type');
        }
      });
    }

    /**
     * Fires load/error events for imports in the right order .
     */
    fireEvents() {
      const n$ = /** @type {!NodeList<!HTMLLinkElement>} */
        (QSA(document, importSelector));
      // Inverse order to have events firing bottom-up.
      forEach(n$, n => this.fireEventIfNeeded(n), true);
    }

    /**
     * Fires load/error event for the import if this wasn't done already.
     * @param {!HTMLLinkElement} link
     */
    fireEventIfNeeded(link) {
      // Don't fire twice same event.
      if (!link['__loaded']) {
        link['__loaded'] = true;
        // Update link's import readyState.
        link.import && (link.import.readyState = 'complete');
        const eventType = link.import ? 'load' : 'error';
        link.dispatchEvent(newCustomEvent(eventType, {
          bubbles: false,
          cancelable: false,
          detail: undefined
        }));
      }
    }

    /**
     * @param {Array<MutationRecord>} mutations
     */
    handleMutations(mutations) {
      forEach(mutations, m => forEach(m.addedNodes, elem => {
        if (elem && elem.nodeType === Node.ELEMENT_NODE) {
          // NOTE: added scripts are not updating currentScript in IE.
          if (isImportLink(elem)) {
            this.loadImport( /** @type {!HTMLLinkElement} */ (elem));
          } else {
            this.loadImports( /** @type {!Element} */ (elem));
          }
        }
      }));
    }
  }

  /**
   * @param {!Node} node
   * @return {boolean}
   */
  const isImportLink = node => {
    return node.nodeType === Node.ELEMENT_NODE && node.localName === 'link' &&
      ( /** @type {!HTMLLinkElement} */ (node).rel === 'import');
  };

  /**
   * Waits for an element to finish loading. If already done loading, it will
   * mark the element accordingly.
   * @param {!(HTMLLinkElement|HTMLScriptElement|HTMLStyleElement)} element
   * @param {function()=} callback
   */
  const whenElementLoaded = (element, callback) => {
    if (element['__loaded']) {
      callback && callback();
    } else if ((element.localName === 'script' && !element.src) ||
      (element.localName === 'style' && !element.firstChild)) {
      // Inline scripts and empty styles don't trigger load/error events,
      // consider them already loaded.
      element['__loaded'] = true;
      callback && callback();
    } else {
      const onLoadingDone = event => {
        element.removeEventListener(event.type, onLoadingDone);
        element['__loaded'] = true;
        callback && callback();
      };
      element.addEventListener('load', onLoadingDone);
      // NOTE: We listen only for load events in IE/Edge, because in IE/Edge
      // <style> with @import will fire error events for each failing @import,
      // and finally will trigger the load event when all @import are
      // finished (even if all fail).
      if (!isIE || element.localName !== 'style') {
        element.addEventListener('error', onLoadingDone);
      }
    }
  }

  /**
   * Calls the callback when all imports in the document at call time
   * (or at least document ready) have loaded. Callback is called synchronously
   * if imports are already done loading.
   * @param {function()=} callback
   */
  const whenReady = callback => {
    // 1. ensure the document is in a ready state (has dom), then
    // 2. watch for loading of imports and call callback when done
    whenDocumentReady(() => whenImportsReady(() => callback && callback()));
  }

  /**
   * Invokes the callback when document is in ready state. Callback is called
   *  synchronously if document is already done loading.
   * @param {!function()} callback
   */
  const whenDocumentReady = callback => {
    const stateChanged = () => {
      // NOTE: Firefox can hit readystate interactive without document.body existing.
      // This is anti-spec, but we handle it here anyways by waiting for next change.
      if (document.readyState !== 'loading' && !!document.body) {
        document.removeEventListener('readystatechange', stateChanged);
        callback();
      }
    }
    document.addEventListener('readystatechange', stateChanged);
    stateChanged();
  }

  /**
   * Invokes the callback after all imports are loaded. Callback is called
   * synchronously if imports are already done loading.
   * @param {!function()} callback
   */
  const whenImportsReady = callback => {
    let imports = /** @type {!NodeList<!HTMLLinkElement>} */
      (QSA(document, rootImportSelector));
    let pending = imports.length;
    if (!pending) {
      callback();
      return;
    }
    forEach(imports, imp => whenElementLoaded(imp, () => {
      if (--pending === 0) {
        callback();
      }
    }));
  }

  /**
   * Returns the import document containing the element.
   * @param {!Node} element
   * @return {HTMLLinkElement|Document|undefined}
   */
  const importForElement = element => {
    if (useNative) {
      // Return only if not in the main doc!
      return element.ownerDocument !== document ? element.ownerDocument : null;
    }
    let doc = element['__importDoc'];
    if (!doc && element.parentNode) {
      doc = /** @type {!Element} */ (element.parentNode);
      if (typeof doc.closest === 'function') {
        // Element.closest returns the element itself if it matches the selector,
        // so we search the closest import starting from the parent.
        doc = doc.closest(importSelector);
      } else {
        // Walk up the parent tree until we find an import.
        while (!isImportLink(doc) && (doc = doc.parentNode)) {}
      }
      element['__importDoc'] = doc;
    }
    return doc;
  }

  let importer = null;
  /**
   * Ensures imports contained in the element are imported.
   * Use this to handle dynamic imports attached to body.
   * @param {!(HTMLDocument|Element)} doc
   */
  const loadImports = (doc) => {
    if (importer) {
      importer.loadImports(doc);
    }
  };

  const newCustomEvent = (type, params) => {
    if (typeof window.CustomEvent === 'function') {
      return new CustomEvent(type, params);
    }
    const event = /** @type {!CustomEvent} */ (document.createEvent('CustomEvent'));
    event.initCustomEvent(type, Boolean(params.bubbles), Boolean(params.cancelable), params.detail);
    return event;
  };

  if (useNative) {
    // Check for imports that might already be done loading by the time this
    // script is actually executed. Native imports are blocking, so the ones
    // available in the document by this time should already have failed
    // or have .import defined.
    const imps = /** @type {!NodeList<!HTMLLinkElement>} */
      (QSA(document, importSelector));
    forEach(imps, imp => {
      if (!imp.import || imp.import.readyState !== 'loading') {
        imp['__loaded'] = true;
      }
    });
    // Listen for load/error events to capture dynamically added scripts.
    /**
     * @type {!function(!Event)}
     */
    const onLoadingDone = event => {
      const elem = /** @type {!Element} */ (event.target);
      if (isImportLink(elem)) {
        elem['__loaded'] = true;
      }
    };
    document.addEventListener('load', onLoadingDone, true /* useCapture */ );
    document.addEventListener('error', onLoadingDone, true /* useCapture */ );
  } else {
    // Override baseURI so that imported elements' baseURI can be used seemlessly
    // on native or polyfilled html-imports.
    // NOTE: a <link rel=import> will have `link.baseURI === link.href`, as the link
    // itself is used as the `import` document.
    /** @type {Object|undefined} */
    const native_baseURI = Object.getOwnPropertyDescriptor(Node.prototype, 'baseURI');
    // NOTE: if not configurable (e.g. safari9), set it on the Element prototype.
    const klass = !native_baseURI || native_baseURI.configurable ? Node : Element;
    Object.defineProperty(klass.prototype, 'baseURI', {
      get() {
        const ownerDoc = /** @type {HTMLLinkElement} */ (isImportLink(this) ? this : importForElement(this));
        if (ownerDoc) return ownerDoc.href;
        // Use native baseURI if possible.
        if (native_baseURI && native_baseURI.get) return native_baseURI.get.call(this);
        // Polyfill it if not available.
        const base = /** @type {HTMLBaseElement} */ (document.querySelector('base'));
        return (base || window.location).href;
      },
      configurable: true,
      enumerable: true
    });

    // Define 'import' read-only property.
    Object.defineProperty(HTMLLinkElement.prototype, 'import', {
      get() {
        return /** @type {HTMLLinkElement} */ (this)['__import'] || null;
      },
      configurable: true,
      enumerable: true
    });

    whenDocumentReady(() => {
      importer = new Importer()
    });
  }

  /**
    Add support for the `HTMLImportsLoaded` event and the `HTMLImports.whenReady`
    method. This api is necessary because unlike the native implementation,
    script elements do not force imports to resolve. Instead, users should wrap
    code in either an `HTMLImportsLoaded` handler or after load time in an
    `HTMLImports.whenReady(callback)` call.

    NOTE: This module also supports these apis under the native implementation.
    Therefore, if this file is loaded, the same code can be used under both
    the polyfill and native implementation.
   */
  whenReady(() => document.dispatchEvent(newCustomEvent('HTMLImportsLoaded', {
    cancelable: true,
    bubbles: true,
    detail: undefined
  })));

  // exports
  scope.useNative = useNative;
  scope.whenReady = whenReady;
  scope.importForElement = importForElement;
  scope.loadImports = loadImports;

})(window.HTMLImports = (window.HTMLImports || {}));
//src/pre-polyfill.js
/**
 * @license
 * Copyright (c) 2014 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

'use strict';

// Establish scope.
window['WebComponents'] = window['WebComponents'] || {'flags':{}};

// loading script
let file = 'webcomponents-lite.js';
let script = document.querySelector('script[src*="' + file + '"]');
let flagMatcher = /wc-(.+)/;

// Flags. Convert url arguments to flags
let flags = {};
if (!flags['noOpts']) {
  // from url
  location.search.slice(1).split('&').forEach(function(option) {
    let parts = option.split('=');
    let match;
    if (parts[0] && (match = parts[0].match(flagMatcher))) {
      flags[match[1]] = parts[1] || true;
    }
  });
  // from script
  if (script) {
    for (let i=0, a; (a=script.attributes[i]); i++) {
      if (a.name !== 'src') {
        flags[a.name] = a.value || true;
      }
    }
  }
  // log flags
  if (flags['log'] && flags['log']['split']) {
    let parts = flags['log'].split(',');
    flags['log'] = {};
    parts.forEach(function(f) {
      flags['log'][f] = true;
    });
  } else {
    flags['log'] = {};
  }
}

// exports
window['WebComponents']['flags'] = flags;
let forceShady = flags['shadydom'];
if (forceShady) {
  window['ShadyDOM'] = window['ShadyDOM'] || {};
  window['ShadyDOM']['force'] = forceShady;
}

let forceCE = flags['register'] || flags['ce'];
if (forceCE && window['customElements']) {
  window['customElements']['forcePolyfill'] = forceCE;
}
//node_modules/@webcomponents/shadydom/src/shady-data.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {ShadyData:{enumerable:true, get:function() {
    return ShadyData;
  }}, ensureShadyDataForNode:{enumerable:true, get:function() {
    return ensureShadyDataForNode;
  }}, shadyDataForNode:{enumerable:true, get:function() {
    return shadyDataForNode;
  }}});
  class ShadyData {
    constructor() {
      this.root = null;
      this.publicRoot = null;
      this.dirty = false;
      this.observer = null;
      this.assignedNodes = null;
      this.assignedSlot = null;
      this._previouslyAssignedNodes = null;
      this._prevAssignedSlot = null;
      this.flattenedNodes = null;
      this.ownerShadyRoot = undefined;
      this.parentNode = undefined;
      this.firstChild = undefined;
      this.lastChild = undefined;
      this.previousSibling = undefined;
      this.nextSibling = undefined;
      this.childNodes = undefined;
      this.__outsideAccessors = false;
      this.__insideAccessors = false;
      this.__onCallbackListeners = {};
    }
    toJSON() {
      return {};
    }
  }
  function ensureShadyDataForNode(node) {
    if (!node.__shady) {
      node.__shady = new ShadyData;
    }
    return node.__shady;
  }
  function shadyDataForNode(node) {
    return node && node.__shady;
  }
}, "node_modules/@webcomponents/shadydom/src/shady-data.js", []);

//node_modules/@webcomponents/shadydom/src/utils.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {contains:{enumerable:true, get:function() {
    return contains;
  }}, createPolyfilledHTMLCollection:{enumerable:true, get:function() {
    return createPolyfilledHTMLCollection;
  }}, extend:{enumerable:true, get:function() {
    return extend;
  }}, extendAll:{enumerable:true, get:function() {
    return extendAll;
  }}, hasDocumentContains:{enumerable:true, get:function() {
    return hasDocumentContains;
  }}, isShadyRoot:{enumerable:true, get:function() {
    return isShadyRoot;
  }}, isTrackingLogicalChildNodes:{enumerable:true, get:function() {
    return isTrackingLogicalChildNodes;
  }}, matchesSelector:{enumerable:true, get:function() {
    return matchesSelector;
  }}, microtask:{enumerable:true, get:function() {
    return microtask;
  }}, mixin:{enumerable:true, get:function() {
    return mixin;
  }}, ownerShadyRootForNode:{enumerable:true, get:function() {
    return ownerShadyRootForNode;
  }}, patchPrototype:{enumerable:true, get:function() {
    return patchPrototype;
  }}, settings:{enumerable:true, get:function() {
    return settings;
  }}});
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  let settings = window["ShadyDOM"] || {};
  settings.hasNativeShadowDOM = Boolean(Element.prototype.attachShadow && Node.prototype.getRootNode);
  let desc = Object.getOwnPropertyDescriptor(Node.prototype, "firstChild");
  settings.hasDescriptors = Boolean(desc && desc.configurable && desc.get);
  settings.inUse = settings["force"] || !settings.hasNativeShadowDOM;
  const IS_IE = navigator.userAgent.match("Trident");
  const IS_EDGE = navigator.userAgent.match("Edge");
  if (settings.useNativeAccessors === undefined) {
    settings.useNativeAccessors = settings.hasDescriptors && (IS_IE || IS_EDGE);
  }
  function isTrackingLogicalChildNodes(node) {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
    return nodeData && nodeData.firstChild !== undefined;
  }
  function isShadyRoot(obj) {
    return Boolean(obj._localName === "ShadyRoot");
  }
  function ownerShadyRootForNode(node) {
    let root = node.getRootNode();
    if (isShadyRoot(root)) {
      return root;
    }
  }
  let p = Element.prototype;
  let matches = p.matches || p.matchesSelector || p.mozMatchesSelector || p.msMatchesSelector || p.oMatchesSelector || p.webkitMatchesSelector;
  function matchesSelector(element, selector) {
    return matches.call(element, selector);
  }
  function copyOwnProperty(name, source, target) {
    let pd = Object.getOwnPropertyDescriptor(source, name);
    if (pd) {
      Object.defineProperty(target, name, pd);
    }
  }
  function extend(target, source) {
    if (target && source) {
      let n$ = Object.getOwnPropertyNames(source);
      for (let i = 0, n; i < n$.length && (n = n$[i]); i++) {
        copyOwnProperty(n, source, target);
      }
    }
    return target || source;
  }
  function extendAll(target, ...sources) {
    for (let i = 0; i < sources.length; i++) {
      extend(target, sources[i]);
    }
    return target;
  }
  function mixin(target, source) {
    for (var i in source) {
      target[i] = source[i];
    }
    return target;
  }
  function patchPrototype(obj, mixin) {
    let proto = Object.getPrototypeOf(obj);
    if (!proto.hasOwnProperty("__patchProto")) {
      let patchProto = Object.create(proto);
      patchProto.__sourceProto = proto;
      extend(patchProto, mixin);
      proto["__patchProto"] = patchProto;
    }
    obj.__proto__ = proto["__patchProto"];
  }
  let twiddle = document.createTextNode("");
  let content = 0;
  let queue = [];
  (new MutationObserver(() => {
    while (queue.length) {
      try {
        queue.shift()();
      } catch (e) {
        twiddle.textContent = content++;
        throw e;
      }
    }
  })).observe(twiddle, {characterData:true});
  function microtask(callback) {
    queue.push(callback);
    twiddle.textContent = content++;
  }
  const hasDocumentContains = Boolean(document.contains);
  function contains(container, node) {
    while (node) {
      if (node == container) {
        return true;
      }
      node = node.parentNode;
    }
    return false;
  }
  function getNodeHTMLCollectionName(node) {
    return node.getAttribute("id") || node.getAttribute("name");
  }
  function isValidHTMLCollectionName(name) {
    return name !== "length" && isNaN(name);
  }
  function createPolyfilledHTMLCollection(nodes) {
    for (let l = nodes.length - 1; l >= 0; l--) {
      const node = nodes[l];
      const name = getNodeHTMLCollectionName(node);
      if (name && isValidHTMLCollectionName(name)) {
        nodes[name] = node;
      }
    }
    nodes.item = function(index) {
      return nodes[index];
    };
    nodes.namedItem = function(name) {
      if (isValidHTMLCollectionName(name) && nodes[name]) {
        return nodes[name];
      }
      for (const node of nodes) {
        const nodeName = getNodeHTMLCollectionName(node);
        if (nodeName == name) {
          return node;
        }
      }
      return null;
    };
    return nodes;
  }
}, "node_modules/@webcomponents/shadydom/src/utils.js", ["node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/flush.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {enqueue:{enumerable:true, get:function() {
    return enqueue;
  }}, flush:{enumerable:true, get:function() {
    return flush;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  let flushList = [];
  let scheduled;
  function enqueue(callback) {
    if (!scheduled) {
      scheduled = true;
      utils.microtask(flush);
    }
    flushList.push(callback);
  }
  function flush() {
    scheduled = false;
    let didFlush = Boolean(flushList.length);
    while (flushList.length) {
      flushList.shift()();
    }
    return didFlush;
  }
  flush["list"] = flushList;
}, "node_modules/@webcomponents/shadydom/src/flush.js", ["node_modules/@webcomponents/shadydom/src/utils.js"]);

//node_modules/@webcomponents/shadydom/src/observe-changes.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {filterMutations:{enumerable:true, get:function() {
    return filterMutations;
  }}, observeChildren:{enumerable:true, get:function() {
    return observeChildren;
  }}, unobserveChildren:{enumerable:true, get:function() {
    return unobserveChildren;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  class AsyncObserver {
    constructor() {
      this._scheduled = false;
      this.addedNodes = [];
      this.removedNodes = [];
      this.callbacks = new Set;
    }
    schedule() {
      if (!this._scheduled) {
        this._scheduled = true;
        utils.microtask(() => {
          this.flush();
        });
      }
    }
    flush() {
      if (this._scheduled) {
        this._scheduled = false;
        let mutations = this.takeRecords();
        if (mutations.length) {
          this.callbacks.forEach(function(cb) {
            cb(mutations);
          });
        }
      }
    }
    takeRecords() {
      if (this.addedNodes.length || this.removedNodes.length) {
        let mutations = [{addedNodes:this.addedNodes, removedNodes:this.removedNodes}];
        this.addedNodes = [];
        this.removedNodes = [];
        return mutations;
      }
      return [];
    }
  }
  let observeChildren = function(node, callback) {
    const sd = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
    if (!sd.observer) {
      sd.observer = new AsyncObserver;
    }
    sd.observer.callbacks.add(callback);
    let observer = sd.observer;
    return {_callback:callback, _observer:observer, _node:node, takeRecords() {
      return observer.takeRecords();
    }};
  };
  let unobserveChildren = function(handle) {
    let observer = handle && handle._observer;
    if (observer) {
      observer.callbacks["delete"](handle._callback);
      if (!observer.callbacks.size) {
        (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(handle._node).observer = null;
      }
    }
  };
  function filterMutations(mutations, target) {
    const targetRootNode = target.getRootNode();
    return mutations.map(function(mutation) {
      const mutationInScope = targetRootNode === mutation.target.getRootNode();
      if (mutationInScope && mutation.addedNodes) {
        let nodes = Array.from(mutation.addedNodes).filter(function(n) {
          return targetRootNode === n.getRootNode();
        });
        if (nodes.length) {
          mutation = Object.create(mutation);
          Object.defineProperty(mutation, "addedNodes", {value:nodes, configurable:true});
          return mutation;
        }
      } else {
        if (mutationInScope) {
          return mutation;
        }
      }
    }).filter(function(m) {
      return m;
    });
  }
}, "node_modules/@webcomponents/shadydom/src/observe-changes.js", ["node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/native-methods.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {addEventListener:{enumerable:true, get:function() {
    return addEventListener;
  }}, appendChild:{enumerable:true, get:function() {
    return appendChild;
  }}, cloneNode:{enumerable:true, get:function() {
    return cloneNode;
  }}, contains:{enumerable:true, get:function() {
    return contains;
  }}, dispatchEvent:{enumerable:true, get:function() {
    return dispatchEvent;
  }}, documentQuerySelector:{enumerable:true, get:function() {
    return documentQuerySelector;
  }}, documentQuerySelectorAll:{enumerable:true, get:function() {
    return documentQuerySelectorAll;
  }}, elementQuerySelector:{enumerable:true, get:function() {
    return elementQuerySelector;
  }}, elementQuerySelectorAll:{enumerable:true, get:function() {
    return elementQuerySelectorAll;
  }}, fragmentQuerySelector:{enumerable:true, get:function() {
    return fragmentQuerySelector;
  }}, fragmentQuerySelectorAll:{enumerable:true, get:function() {
    return fragmentQuerySelectorAll;
  }}, getElementById:{enumerable:true, get:function() {
    return getElementById;
  }}, importNode:{enumerable:true, get:function() {
    return importNode;
  }}, insertBefore:{enumerable:true, get:function() {
    return insertBefore;
  }}, querySelector:{enumerable:true, get:function() {
    return querySelector;
  }}, querySelectorAll:{enumerable:true, get:function() {
    return querySelectorAll;
  }}, removeAttribute:{enumerable:true, get:function() {
    return removeAttribute;
  }}, removeChild:{enumerable:true, get:function() {
    return removeChild;
  }}, removeEventListener:{enumerable:true, get:function() {
    return removeEventListener;
  }}, replaceChild:{enumerable:true, get:function() {
    return replaceChild;
  }}, setAttribute:{enumerable:true, get:function() {
    return setAttribute;
  }}, windowAddEventListener:{enumerable:true, get:function() {
    return windowAddEventListener;
  }}, windowRemoveEventListener:{enumerable:true, get:function() {
    return windowRemoveEventListener;
  }}});
  let appendChild = Element.prototype.appendChild;
  let insertBefore = Element.prototype.insertBefore;
  let replaceChild = Element.prototype.replaceChild;
  let removeChild = Element.prototype.removeChild;
  let setAttribute = Element.prototype.setAttribute;
  let removeAttribute = Element.prototype.removeAttribute;
  let cloneNode = Element.prototype.cloneNode;
  let importNode = Document.prototype.importNode;
  let addEventListener = Element.prototype.addEventListener;
  let removeEventListener = Element.prototype.removeEventListener;
  let windowAddEventListener = Window.prototype.addEventListener;
  let windowRemoveEventListener = Window.prototype.removeEventListener;
  let dispatchEvent = Element.prototype.dispatchEvent;
  let contains = Node.prototype.contains || HTMLElement.prototype.contains;
  let getElementById = Document.prototype.getElementById;
  let elementQuerySelector = Element.prototype.querySelector;
  let fragmentQuerySelector = DocumentFragment.prototype.querySelector;
  let documentQuerySelector = Document.prototype.querySelector;
  let querySelector = function(selector) {
    switch(this.nodeType) {
      case Node.ELEMENT_NODE:
        return elementQuerySelector.call(this, selector);
      case Node.DOCUMENT_NODE:
        return documentQuerySelector.call(this, selector);
      default:
        return fragmentQuerySelector.call(this, selector);
    }
  };
  let elementQuerySelectorAll = Element.prototype.querySelectorAll;
  let fragmentQuerySelectorAll = DocumentFragment.prototype.querySelectorAll;
  let documentQuerySelectorAll = Document.prototype.querySelectorAll;
  let querySelectorAll = function(selector) {
    switch(this.nodeType) {
      case Node.ELEMENT_NODE:
        return elementQuerySelectorAll.call(this, selector);
      case Node.DOCUMENT_NODE:
        return documentQuerySelectorAll.call(this, selector);
      default:
        return fragmentQuerySelectorAll.call(this, selector);
    }
  };
}, "node_modules/@webcomponents/shadydom/src/native-methods.js", []);

//node_modules/@webcomponents/shadydom/src/innerHTML.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {getInnerHTML:{enumerable:true, get:function() {
    return getInnerHTML;
  }}, getOuterHTML:{enumerable:true, get:function() {
    return getOuterHTML;
  }}});
  let escapeAttrRegExp = /[&\u00A0"]/g;
  let escapeDataRegExp = /[&\u00A0<>]/g;
  function escapeReplace(c) {
    switch(c) {
      case "\x26":
        return "\x26amp;";
      case "\x3c":
        return "\x26lt;";
      case "\x3e":
        return "\x26gt;";
      case '"':
        return "\x26quot;";
      case "\u00a0":
        return "\x26nbsp;";
    }
  }
  function escapeAttr(s) {
    return s.replace(escapeAttrRegExp, escapeReplace);
  }
  function escapeData(s) {
    return s.replace(escapeDataRegExp, escapeReplace);
  }
  function makeSet(arr) {
    let set = {};
    for (let i = 0; i < arr.length; i++) {
      set[arr[i]] = true;
    }
    return set;
  }
  let voidElements = makeSet(["area", "base", "br", "col", "command", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr"]);
  let plaintextParents = makeSet(["style", "script", "xmp", "iframe", "noembed", "noframes", "plaintext", "noscript"]);
  function getOuterHTML(node, parentNode, callback) {
    switch(node.nodeType) {
      case Node.ELEMENT_NODE:
        {
          let tagName = node.localName;
          let s = "\x3c" + tagName;
          let attrs = node.attributes;
          for (let i = 0, attr; attr = attrs[i]; i++) {
            s += " " + attr.name + '\x3d"' + escapeAttr(attr.value) + '"';
          }
          s += "\x3e";
          if (voidElements[tagName]) {
            return s;
          }
          return s + getInnerHTML(node, callback) + "\x3c/" + tagName + "\x3e";
        }
      case Node.TEXT_NODE:
        {
          let data = node.data;
          if (parentNode && plaintextParents[parentNode.localName]) {
            return data;
          }
          return escapeData(data);
        }
      case Node.COMMENT_NODE:
        {
          return "\x3c!--" + node.data + "--\x3e";
        }
      default:
        {
          window.console.error(node);
          throw new Error("not implemented");
        }
    }
  }
  function getInnerHTML(node, callback) {
    if (node.localName === "template") {
      node = node.content;
    }
    let s = "";
    let c$ = callback ? callback(node) : node.childNodes;
    for (let i = 0, l = c$.length, child; i < l && (child = c$[i]); i++) {
      s += getOuterHTML(child, node, callback);
    }
    return s;
  }
}, "node_modules/@webcomponents/shadydom/src/innerHTML.js", []);

//node_modules/@webcomponents/shadydom/src/native-tree-walker.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {childNodes:{enumerable:true, get:function() {
    return childNodes;
  }}, children:{enumerable:true, get:function() {
    return children;
  }}, firstChild:{enumerable:true, get:function() {
    return firstChild;
  }}, firstElementChild:{enumerable:true, get:function() {
    return firstElementChild;
  }}, innerHTML:{enumerable:true, get:function() {
    return innerHTML;
  }}, lastChild:{enumerable:true, get:function() {
    return lastChild;
  }}, lastElementChild:{enumerable:true, get:function() {
    return lastElementChild;
  }}, nextElementSibling:{enumerable:true, get:function() {
    return nextElementSibling;
  }}, nextSibling:{enumerable:true, get:function() {
    return nextSibling;
  }}, parentElement:{enumerable:true, get:function() {
    return parentElement;
  }}, parentNode:{enumerable:true, get:function() {
    return parentNode;
  }}, previousElementSibling:{enumerable:true, get:function() {
    return previousElementSibling;
  }}, previousSibling:{enumerable:true, get:function() {
    return previousSibling;
  }}, textContent:{enumerable:true, get:function() {
    return textContent;
  }}});
  var module$node_modules$$webcomponents$shadydom$src$innerHTML = $$require("node_modules/@webcomponents/shadydom/src/innerHTML.js");
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  let nodeWalker = document.createTreeWalker(document, NodeFilter.SHOW_ALL, null, false);
  let elementWalker = document.createTreeWalker(document, NodeFilter.SHOW_ELEMENT, null, false);
  function parentNode(node) {
    nodeWalker.currentNode = node;
    return nodeWalker.parentNode();
  }
  function firstChild(node) {
    nodeWalker.currentNode = node;
    return nodeWalker.firstChild();
  }
  function lastChild(node) {
    nodeWalker.currentNode = node;
    return nodeWalker.lastChild();
  }
  function previousSibling(node) {
    nodeWalker.currentNode = node;
    return nodeWalker.previousSibling();
  }
  function nextSibling(node) {
    nodeWalker.currentNode = node;
    return nodeWalker.nextSibling();
  }
  function childNodes(node) {
    let nodes = [];
    nodeWalker.currentNode = node;
    let n = nodeWalker.firstChild();
    while (n) {
      nodes.push(n);
      n = nodeWalker.nextSibling();
    }
    return nodes;
  }
  function parentElement(node) {
    elementWalker.currentNode = node;
    return elementWalker.parentNode();
  }
  function firstElementChild(node) {
    elementWalker.currentNode = node;
    return elementWalker.firstChild();
  }
  function lastElementChild(node) {
    elementWalker.currentNode = node;
    return elementWalker.lastChild();
  }
  function previousElementSibling(node) {
    elementWalker.currentNode = node;
    return elementWalker.previousSibling();
  }
  function nextElementSibling(node) {
    elementWalker.currentNode = node;
    return elementWalker.nextSibling();
  }
  function children(node) {
    let nodes = [];
    elementWalker.currentNode = node;
    let n = elementWalker.firstChild();
    while (n) {
      nodes.push(n);
      n = elementWalker.nextSibling();
    }
    return utils.createPolyfilledHTMLCollection(nodes);
  }
  function innerHTML(node) {
    return (0,module$node_modules$$webcomponents$shadydom$src$innerHTML.getInnerHTML)(node, (n) => childNodes(n));
  }
  function textContent(node) {
    switch(node.nodeType) {
      case Node.ELEMENT_NODE:
      case Node.DOCUMENT_FRAGMENT_NODE:
        let textWalker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT, null, false);
        let content = "", n;
        while (n = textWalker.nextNode()) {
          content += n.nodeValue;
        }
        return content;
      default:
        return node.nodeValue;
    }
  }
}, "node_modules/@webcomponents/shadydom/src/native-tree-walker.js", ["node_modules/@webcomponents/shadydom/src/innerHTML.js", "node_modules/@webcomponents/shadydom/src/utils.js"]);

//node_modules/@webcomponents/shadydom/src/native-tree-accessors.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {childNodes:{enumerable:true, get:function() {
    return childNodes;
  }}, children:{enumerable:true, get:function() {
    return children;
  }}, documentAccessors:{enumerable:true, get:function() {
    return documentAccessors;
  }}, firstChild:{enumerable:true, get:function() {
    return firstChild;
  }}, firstElementChild:{enumerable:true, get:function() {
    return firstElementChild;
  }}, fragmentAccessors:{enumerable:true, get:function() {
    return fragmentAccessors;
  }}, innerHTML:{enumerable:true, get:function() {
    return innerHTML;
  }}, lastChild:{enumerable:true, get:function() {
    return lastChild;
  }}, lastElementChild:{enumerable:true, get:function() {
    return lastElementChild;
  }}, nextElementSibling:{enumerable:true, get:function() {
    return nextElementSibling;
  }}, nextSibling:{enumerable:true, get:function() {
    return nextSibling;
  }}, nodeAccessors:{enumerable:true, get:function() {
    return nodeAccessors;
  }}, parentElement:{enumerable:true, get:function() {
    return parentElement;
  }}, parentNode:{enumerable:true, get:function() {
    return parentNode;
  }}, previousElementSibling:{enumerable:true, get:function() {
    return previousElementSibling;
  }}, previousSibling:{enumerable:true, get:function() {
    return previousSibling;
  }}, textContent:{enumerable:true, get:function() {
    return textContent;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  const hasDescriptors = utils.settings.hasDescriptors;
  const nativeProtos = [Node.prototype, Element.prototype, HTMLElement.prototype];
  function findNativeProtoWithDescriptor(name) {
    for (let i = 0; i < nativeProtos.length; i++) {
      const proto = nativeProtos[i];
      if (proto.hasOwnProperty(name)) {
        return proto;
      }
    }
  }
  function findNodeDescriptor(name) {
    const proto = findNativeProtoWithDescriptor(name);
    if (!proto) {
      throw Error(`Could not find descriptor for ${name}`);
    }
    return Object.getOwnPropertyDescriptor(proto, name);
  }
  const nodeAccessors = hasDescriptors ? {parentNode:findNodeDescriptor("parentNode"), firstChild:findNodeDescriptor("firstChild"), lastChild:findNodeDescriptor("lastChild"), previousSibling:findNodeDescriptor("previousSibling"), nextSibling:findNodeDescriptor("nextSibling"), childNodes:findNodeDescriptor("childNodes"), parentElement:findNodeDescriptor("parentElement"), previousElementSibling:findNodeDescriptor("previousElementSibling"), nextElementSibling:findNodeDescriptor("nextElementSibling"), 
  innerHTML:findNodeDescriptor("innerHTML"), textContent:findNodeDescriptor("textContent"), firstElementChild:findNodeDescriptor("firstElementChild"), lastElementChild:findNodeDescriptor("lastElementChild"), children:findNodeDescriptor("children")} : {};
  const fragmentAccessors = hasDescriptors ? {firstElementChild:Object.getOwnPropertyDescriptor(DocumentFragment.prototype, "firstElementChild"), lastElementChild:Object.getOwnPropertyDescriptor(DocumentFragment.prototype, "lastElementChild"), children:Object.getOwnPropertyDescriptor(DocumentFragment.prototype, "children")} : {};
  const documentAccessors = hasDescriptors ? {firstElementChild:Object.getOwnPropertyDescriptor(Document.prototype, "firstElementChild"), lastElementChild:Object.getOwnPropertyDescriptor(Document.prototype, "lastElementChild"), children:Object.getOwnPropertyDescriptor(Document.prototype, "children")} : {};
  function parentNode(node) {
    return nodeAccessors.parentNode.get.call(node);
  }
  function firstChild(node) {
    return nodeAccessors.firstChild.get.call(node);
  }
  function lastChild(node) {
    return nodeAccessors.lastChild.get.call(node);
  }
  function previousSibling(node) {
    return nodeAccessors.previousSibling.get.call(node);
  }
  function nextSibling(node) {
    return nodeAccessors.nextSibling.get.call(node);
  }
  function childNodes(node) {
    return Array.prototype.slice.call(nodeAccessors.childNodes.get.call(node));
  }
  function parentElement(node) {
    return nodeAccessors.parentElement.get.call(node);
  }
  function previousElementSibling(node) {
    return nodeAccessors.previousElementSibling.get.call(node);
  }
  function nextElementSibling(node) {
    return nodeAccessors.nextElementSibling.get.call(node);
  }
  function innerHTML(node) {
    return nodeAccessors.innerHTML.get.call(node);
  }
  function textContent(node) {
    return nodeAccessors.textContent.get.call(node);
  }
  function children(node) {
    switch(node.nodeType) {
      case Node.DOCUMENT_FRAGMENT_NODE:
        return fragmentAccessors.children.get.call(node);
      case Node.DOCUMENT_NODE:
        return documentAccessors.children.get.call(node);
      default:
        return nodeAccessors.children.get.call(node);
    }
  }
  function firstElementChild(node) {
    switch(node.nodeType) {
      case Node.DOCUMENT_FRAGMENT_NODE:
        return fragmentAccessors.firstElementChild.get.call(node);
      case Node.DOCUMENT_NODE:
        return documentAccessors.firstElementChild.get.call(node);
      default:
        return nodeAccessors.firstElementChild.get.call(node);
    }
  }
  function lastElementChild(node) {
    switch(node.nodeType) {
      case Node.DOCUMENT_FRAGMENT_NODE:
        return fragmentAccessors.lastElementChild.get.call(node);
      case Node.DOCUMENT_NODE:
        return documentAccessors.lastElementChild.get.call(node);
      default:
        return nodeAccessors.lastElementChild.get.call(node);
    }
  }
}, "node_modules/@webcomponents/shadydom/src/native-tree-accessors.js", ["node_modules/@webcomponents/shadydom/src/utils.js"]);

//node_modules/@webcomponents/shadydom/src/native-tree.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {accessors:{enumerable:true, get:function() {
    return accessors;
  }}});
  var nativeTreeWalker = $$require("node_modules/@webcomponents/shadydom/src/native-tree-walker.js");
  var nativeTreeAccessors = $$require("node_modules/@webcomponents/shadydom/src/native-tree-accessors.js");
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  const accessors = utils.settings.useNativeAccessors ? nativeTreeAccessors : nativeTreeWalker;
}, "node_modules/@webcomponents/shadydom/src/native-tree.js", ["node_modules/@webcomponents/shadydom/src/native-tree-walker.js", "node_modules/@webcomponents/shadydom/src/native-tree-accessors.js", "node_modules/@webcomponents/shadydom/src/utils.js"]);

//node_modules/@webcomponents/shadydom/src/patch-accessors.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {ActiveElementAccessor:{enumerable:true, get:function() {
    return ActiveElementAccessor;
  }}, ClassNameAccessor:{enumerable:true, get:function() {
    return ClassNameAccessor;
  }}, IsConnectedAccessor:{enumerable:true, get:function() {
    return IsConnectedAccessor;
  }}, ShadowRootAccessor:{enumerable:true, get:function() {
    return ShadowRootAccessor;
  }}, patchAccessors:{enumerable:true, get:function() {
    return patchAccessors;
  }}, patchInsideElementAccessors:{enumerable:true, get:function() {
    return patchInsideElementAccessors;
  }}, patchOutsideElementAccessors:{enumerable:true, get:function() {
    return patchOutsideElementAccessors;
  }}, patchShadowRootAccessors:{enumerable:true, get:function() {
    return patchShadowRootAccessors;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var module$node_modules$$webcomponents$shadydom$src$innerHTML = $$require("node_modules/@webcomponents/shadydom/src/innerHTML.js");
  var module$node_modules$$webcomponents$shadydom$src$native_tree = $$require("node_modules/@webcomponents/shadydom/src/native-tree.js");
  var module$node_modules$$webcomponents$shadydom$src$native_tree_accessors = $$require("node_modules/@webcomponents/shadydom/src/native-tree-accessors.js");
  var module$node_modules$$webcomponents$shadydom$src$native_methods = $$require("node_modules/@webcomponents/shadydom/src/native-methods.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  function clearNode(node) {
    while (node.firstChild) {
      node.removeChild(node.firstChild);
    }
  }
  const hasDescriptors = utils.settings.hasDescriptors;
  const inertDoc = document.implementation.createHTMLDocument("inert");
  const nativeIsConnectedAccessors = Object.getOwnPropertyDescriptor(Node.prototype, "isConnected");
  const nativeIsConnected = nativeIsConnectedAccessors && nativeIsConnectedAccessors.get;
  const nativeActiveElementDescriptor = Object.getOwnPropertyDescriptor(Document.prototype, "activeElement");
  function getDocumentActiveElement() {
    if (nativeActiveElementDescriptor && nativeActiveElementDescriptor.get) {
      return nativeActiveElementDescriptor.get.call(document);
    } else {
      if (!utils.settings.hasDescriptors) {
        return document.activeElement;
      }
    }
  }
  function activeElementForNode(node) {
    let active = getDocumentActiveElement();
    if (!active || !active.nodeType) {
      return null;
    }
    let isShadyRoot = !!utils.isShadyRoot(node);
    if (node !== document) {
      if (!isShadyRoot) {
        return null;
      }
      if (node.host === active || !module$node_modules$$webcomponents$shadydom$src$native_methods.contains.call(node.host, active)) {
        return null;
      }
    }
    let activeRoot = utils.ownerShadyRootForNode(active);
    while (activeRoot && activeRoot !== node) {
      active = activeRoot.host;
      activeRoot = utils.ownerShadyRootForNode(active);
    }
    if (node === document) {
      return activeRoot ? null : active;
    } else {
      return activeRoot === node ? active : null;
    }
  }
  let OutsideAccessors = {parentElement:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    let l = nodeData && nodeData.parentNode;
    if (l && l.nodeType !== Node.ELEMENT_NODE) {
      l = null;
    }
    return l !== undefined ? l : module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.parentElement(this);
  }, configurable:true}, parentNode:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    const l = nodeData && nodeData.parentNode;
    return l !== undefined ? l : module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.parentNode(this);
  }, configurable:true}, nextSibling:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    const l = nodeData && nodeData.nextSibling;
    return l !== undefined ? l : module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.nextSibling(this);
  }, configurable:true}, previousSibling:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    const l = nodeData && nodeData.previousSibling;
    return l !== undefined ? l : module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.previousSibling(this);
  }, configurable:true}, nextElementSibling:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    if (nodeData && nodeData.nextSibling !== undefined) {
      let n = this.nextSibling;
      while (n && n.nodeType !== Node.ELEMENT_NODE) {
        n = n.nextSibling;
      }
      return n;
    } else {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.nextElementSibling(this);
    }
  }, configurable:true}, previousElementSibling:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    if (nodeData && nodeData.previousSibling !== undefined) {
      let n = this.previousSibling;
      while (n && n.nodeType !== Node.ELEMENT_NODE) {
        n = n.previousSibling;
      }
      return n;
    } else {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.previousElementSibling(this);
    }
  }, configurable:true}};
  const ClassNameAccessor = {className:{get() {
    return this.getAttribute("class") || "";
  }, set(value) {
    this.setAttribute("class", value);
  }, configurable:true}};
  const IsConnectedAccessor = {isConnected:{get() {
    if (nativeIsConnected && nativeIsConnected.call(this)) {
      return true;
    }
    if (this.nodeType == Node.DOCUMENT_FRAGMENT_NODE) {
      return false;
    }
    const ownerDocument = this.ownerDocument;
    if (utils.hasDocumentContains) {
      if (module$node_modules$$webcomponents$shadydom$src$native_methods.contains.call(ownerDocument, this)) {
        return true;
      }
    } else {
      if (ownerDocument.documentElement && module$node_modules$$webcomponents$shadydom$src$native_methods.contains.call(ownerDocument.documentElement, this)) {
        return true;
      }
    }
    let node = this;
    while (node && !(node instanceof Document)) {
      node = node.parentNode || (utils.isShadyRoot(node) ? node.host : undefined);
    }
    return !!(node && node instanceof Document);
  }, configurable:true}};
  let InsideAccessors = {childNodes:{get() {
    let childNodes;
    if (utils.isTrackingLogicalChildNodes(this)) {
      const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
      if (!nodeData.childNodes) {
        nodeData.childNodes = [];
        for (let n = this.firstChild; n; n = n.nextSibling) {
          nodeData.childNodes.push(n);
        }
      }
      childNodes = nodeData.childNodes;
    } else {
      childNodes = module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.childNodes(this);
    }
    childNodes.item = function(index) {
      return childNodes[index];
    };
    return childNodes;
  }, configurable:true}, childElementCount:{get() {
    return this.children.length;
  }, configurable:true}, firstChild:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    const l = nodeData && nodeData.firstChild;
    return l !== undefined ? l : module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.firstChild(this);
  }, configurable:true}, lastChild:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    const l = nodeData && nodeData.lastChild;
    return l !== undefined ? l : module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.lastChild(this);
  }, configurable:true}, textContent:{get() {
    if (utils.isTrackingLogicalChildNodes(this)) {
      let tc = [];
      for (let i = 0, cn = this.childNodes, c; c = cn[i]; i++) {
        if (c.nodeType !== Node.COMMENT_NODE) {
          tc.push(c.textContent);
        }
      }
      return tc.join("");
    } else {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.textContent(this);
    }
  }, set(text) {
    if (typeof text === "undefined" || text === null) {
      text = "";
    }
    switch(this.nodeType) {
      case Node.ELEMENT_NODE:
      case Node.DOCUMENT_FRAGMENT_NODE:
        if (!utils.isTrackingLogicalChildNodes(this) && hasDescriptors) {
          const firstChild = this.firstChild;
          if (firstChild != this.lastChild || firstChild && firstChild.nodeType != Node.TEXT_NODE) {
            clearNode(this);
          }
          module$node_modules$$webcomponents$shadydom$src$native_tree_accessors.nodeAccessors.textContent.set.call(this, text);
        } else {
          clearNode(this);
          if (text.length > 0 || this.nodeType === Node.ELEMENT_NODE) {
            this.appendChild(document.createTextNode(text));
          }
        }
        break;
      default:
        this.nodeValue = text;
        break;
    }
  }, configurable:true}, firstElementChild:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    if (nodeData && nodeData.firstChild !== undefined) {
      let n = this.firstChild;
      while (n && n.nodeType !== Node.ELEMENT_NODE) {
        n = n.nextSibling;
      }
      return n;
    } else {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.firstElementChild(this);
    }
  }, configurable:true}, lastElementChild:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    if (nodeData && nodeData.lastChild !== undefined) {
      let n = this.lastChild;
      while (n && n.nodeType !== Node.ELEMENT_NODE) {
        n = n.previousSibling;
      }
      return n;
    } else {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.lastElementChild(this);
    }
  }, configurable:true}, children:{get() {
    if (!utils.isTrackingLogicalChildNodes(this)) {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.children(this);
    }
    return utils.createPolyfilledHTMLCollection(Array.prototype.filter.call(this.childNodes, function(n) {
      return n.nodeType === Node.ELEMENT_NODE;
    }));
  }, configurable:true}, innerHTML:{get() {
    if (utils.isTrackingLogicalChildNodes(this)) {
      const content = this.localName === "template" ? this.content : this;
      return (0,module$node_modules$$webcomponents$shadydom$src$innerHTML.getInnerHTML)(content);
    } else {
      return module$node_modules$$webcomponents$shadydom$src$native_tree.accessors.innerHTML(this);
    }
  }, set(text) {
    const content = this.localName === "template" ? this.content : this;
    clearNode(content);
    const containerName = this.localName || "div";
    let htmlContainer;
    if (!this.namespaceURI || this.namespaceURI === inertDoc.namespaceURI) {
      htmlContainer = inertDoc.createElement(containerName);
    } else {
      htmlContainer = inertDoc.createElementNS(this.namespaceURI, containerName);
    }
    if (hasDescriptors) {
      module$node_modules$$webcomponents$shadydom$src$native_tree_accessors.nodeAccessors.innerHTML.set.call(htmlContainer, text);
    } else {
      htmlContainer.innerHTML = text;
    }
    const newContent = this.localName === "template" ? htmlContainer.content : htmlContainer;
    while (newContent.firstChild) {
      content.appendChild(newContent.firstChild);
    }
  }, configurable:true}};
  let ShadowRootAccessor = {shadowRoot:{get() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    return nodeData && nodeData.publicRoot || null;
  }, configurable:true}};
  let ActiveElementAccessor = {activeElement:{get() {
    return activeElementForNode(this);
  }, set() {
  }, configurable:true}};
  function patchAccessorGroup(obj, descriptors, force) {
    for (let p in descriptors) {
      let objDesc = Object.getOwnPropertyDescriptor(obj, p);
      if (objDesc && objDesc.configurable || !objDesc && force) {
        Object.defineProperty(obj, p, descriptors[p]);
      } else {
        if (force) {
          console.warn("Could not define", p, "on", obj);
        }
      }
    }
  }
  function patchAccessors(proto) {
    patchAccessorGroup(proto, OutsideAccessors);
    patchAccessorGroup(proto, ClassNameAccessor);
    patchAccessorGroup(proto, InsideAccessors);
    patchAccessorGroup(proto, ActiveElementAccessor);
  }
  function patchShadowRootAccessors(proto) {
    proto.__proto__ = DocumentFragment.prototype;
    patchAccessorGroup(proto, OutsideAccessors, true);
    patchAccessorGroup(proto, InsideAccessors, true);
    patchAccessorGroup(proto, ActiveElementAccessor, true);
    Object.defineProperties(proto, {nodeType:{value:Node.DOCUMENT_FRAGMENT_NODE, configurable:true}, nodeName:{value:"#document-fragment", configurable:true}, nodeValue:{value:null, configurable:true}});
    ["localName", "namespaceURI", "prefix"].forEach((prop) => {
      Object.defineProperty(proto, prop, {value:undefined, configurable:true});
    });
    ["ownerDocument", "baseURI", "isConnected"].forEach((prop) => {
      Object.defineProperty(proto, prop, {get() {
        return this.host[prop];
      }, configurable:true});
    });
  }
  let patchOutsideElementAccessors = utils.settings.hasDescriptors ? function() {
  } : function(element) {
    const sd = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(element);
    if (!sd.__outsideAccessors) {
      sd.__outsideAccessors = true;
      patchAccessorGroup(element, OutsideAccessors, true);
      patchAccessorGroup(element, ClassNameAccessor, true);
    }
  };
  let patchInsideElementAccessors = utils.settings.hasDescriptors ? function() {
  } : function(element) {
    const sd = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(element);
    if (!sd.__insideAccessors) {
      patchAccessorGroup(element, InsideAccessors, true);
      patchAccessorGroup(element, ShadowRootAccessor, true);
    }
  };
}, "node_modules/@webcomponents/shadydom/src/patch-accessors.js", ["node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/innerHTML.js", "node_modules/@webcomponents/shadydom/src/native-tree.js", "node_modules/@webcomponents/shadydom/src/native-tree-accessors.js", "node_modules/@webcomponents/shadydom/src/native-methods.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/logical-tree.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {recordChildNodes:{enumerable:true, get:function() {
    return recordChildNodes;
  }}, recordInsertBefore:{enumerable:true, get:function() {
    return recordInsertBefore;
  }}, recordRemoveChild:{enumerable:true, get:function() {
    return recordRemoveChild;
  }}});
  var module$node_modules$$webcomponents$shadydom$src$patch_accessors = $$require("node_modules/@webcomponents/shadydom/src/patch-accessors.js");
  var module$node_modules$$webcomponents$shadydom$src$native_tree = $$require("node_modules/@webcomponents/shadydom/src/native-tree.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  const {childNodes} = module$node_modules$$webcomponents$shadydom$src$native_tree.accessors;
  function recordInsertBefore(node, container, ref_node) {
    (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchInsideElementAccessors)(container);
    const containerData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(container);
    if (containerData.firstChild !== undefined) {
      containerData.childNodes = null;
    }
    if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
      let c$ = node.childNodes;
      for (let i = 0; i < c$.length; i++) {
        linkNode(c$[i], container, ref_node);
      }
      const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
      let resetTo = nodeData.firstChild !== undefined ? null : undefined;
      nodeData.firstChild = nodeData.lastChild = resetTo;
      nodeData.childNodes = resetTo;
    } else {
      linkNode(node, container, ref_node);
    }
  }
  function linkNode(node, container, ref_node) {
    (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchOutsideElementAccessors)(node);
    ref_node = ref_node || null;
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
    const containerData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(container);
    const ref_nodeData = ref_node ? (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(ref_node) : null;
    nodeData.previousSibling = ref_node ? ref_nodeData.previousSibling : container.lastChild;
    let psd = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(nodeData.previousSibling);
    if (psd) {
      psd.nextSibling = node;
    }
    let nsd = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(nodeData.nextSibling = ref_node);
    if (nsd) {
      nsd.previousSibling = node;
    }
    nodeData.parentNode = container;
    if (ref_node) {
      if (ref_node === containerData.firstChild) {
        containerData.firstChild = node;
      }
    } else {
      containerData.lastChild = node;
      if (!containerData.firstChild) {
        containerData.firstChild = node;
      }
    }
    containerData.childNodes = null;
  }
  function recordRemoveChild(node, container) {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
    const containerData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(container);
    if (node === containerData.firstChild) {
      containerData.firstChild = nodeData.nextSibling;
    }
    if (node === containerData.lastChild) {
      containerData.lastChild = nodeData.previousSibling;
    }
    let p = nodeData.previousSibling;
    let n = nodeData.nextSibling;
    if (p) {
      (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(p).nextSibling = n;
    }
    if (n) {
      (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(n).previousSibling = p;
    }
    nodeData.parentNode = nodeData.previousSibling = nodeData.nextSibling = undefined;
    if (containerData.childNodes !== undefined) {
      containerData.childNodes = null;
    }
  }
  function recordChildNodes(node, nodes) {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
    if (nodeData.firstChild === undefined) {
      nodeData.childNodes = null;
      const c$ = nodes || childNodes(node);
      nodeData.firstChild = c$[0] || null;
      nodeData.lastChild = c$[c$.length - 1] || null;
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchInsideElementAccessors)(node);
      for (let i = 0; i < c$.length; i++) {
        const n = c$[i];
        const sd = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(n);
        sd.parentNode = node;
        sd.nextSibling = c$[i + 1] || null;
        sd.previousSibling = c$[i - 1] || null;
        (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchOutsideElementAccessors)(n);
      }
    }
  }
}, "node_modules/@webcomponents/shadydom/src/logical-tree.js", ["node_modules/@webcomponents/shadydom/src/patch-accessors.js", "node_modules/@webcomponents/shadydom/src/native-tree.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/logical-mutation.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {cloneNode:{enumerable:true, get:function() {
    return cloneNode;
  }}, getRootNode:{enumerable:true, get:function() {
    return getRootNode;
  }}, importNode:{enumerable:true, get:function() {
    return importNode;
  }}, insertBefore:{enumerable:true, get:function() {
    return insertBefore;
  }}, query:{enumerable:true, get:function() {
    return query;
  }}, removeAttribute:{enumerable:true, get:function() {
    return removeAttribute;
  }}, removeChild:{enumerable:true, get:function() {
    return removeChild;
  }}, renderRootNode:{enumerable:true, get:function() {
    return renderRootNode;
  }}, setAttribute:{enumerable:true, get:function() {
    return setAttribute;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var logicalTree = $$require("node_modules/@webcomponents/shadydom/src/logical-tree.js");
  var nativeMethods = $$require("node_modules/@webcomponents/shadydom/src/native-methods.js");
  var module$node_modules$$webcomponents$shadydom$src$native_tree = $$require("node_modules/@webcomponents/shadydom/src/native-tree.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  const {parentNode} = module$node_modules$$webcomponents$shadydom$src$native_tree.accessors;
  function insertBefore(parent, node, ref_node) {
    if (node === parent) {
      throw Error(`Failed to execute 'appendChild' on 'Node': The new child element contains the parent.`);
    }
    if (ref_node) {
      const refData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(ref_node);
      const p = refData && refData.parentNode;
      if (p !== undefined && p !== parent || p === undefined && parentNode(ref_node) !== parent) {
        throw Error(`Failed to execute 'insertBefore' on 'Node': The node ` + `before which the new node is to be inserted is not a child of this node.`);
      }
    }
    if (ref_node === node) {
      return node;
    }
    let slotsAdded = [];
    let scopingFn = addShadyScoping;
    let ownerRoot = utils.ownerShadyRootForNode(parent);
    const newScopeName = ownerRoot ? ownerRoot.host.localName : "";
    if (node.parentNode) {
      const oldScopeName = currentScopeForNode(node);
      removeChild(node.parentNode, node, Boolean(ownerRoot) || !(node.getRootNode() instanceof ShadowRoot));
      scopingFn = (node, newScopeName) => {
        replaceShadyScoping(node, newScopeName, oldScopeName);
      };
    }
    let allowNativeInsert = true;
    const needsScoping = !currentScopeIsCorrect(node, newScopeName);
    if (ownerRoot && (!node["__noInsertionPoint"] || needsScoping)) {
      treeVisitor(node, (node) => {
        if (node.localName === "slot") {
          slotsAdded.push(node);
        }
        if (needsScoping) {
          scopingFn(node, newScopeName);
        }
      });
    }
    if (slotsAdded.length) {
      ownerRoot._addSlots(slotsAdded);
    }
    if (parent.localName === "slot" || slotsAdded.length) {
      if (ownerRoot) {
        ownerRoot._asyncRender();
      }
    }
    if (utils.isTrackingLogicalChildNodes(parent)) {
      logicalTree.recordInsertBefore(node, parent, ref_node);
      const parentData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(parent);
      if (hasShadowRootWithSlot(parent)) {
        parentData.root._asyncRender();
        allowNativeInsert = false;
      } else {
        if (parentData.root) {
          allowNativeInsert = false;
        }
      }
    }
    if (allowNativeInsert) {
      let container = utils.isShadyRoot(parent) ? parent.host : parent;
      if (ref_node) {
        ref_node = firstComposedNode(ref_node);
        nativeMethods.insertBefore.call(container, node, ref_node);
      } else {
        nativeMethods.appendChild.call(container, node);
      }
    } else {
      if (node.ownerDocument !== parent.ownerDocument) {
        parent.ownerDocument.adoptNode(node);
      }
    }
    scheduleObserver(parent, node);
    return node;
  }
  function removeChild(parent, node, skipUnscoping = false) {
    if (node.parentNode !== parent) {
      throw Error("The node to be removed is not a child of this node: " + node);
    }
    let preventNativeRemove;
    let ownerRoot = utils.ownerShadyRootForNode(node);
    let removingInsertionPoint;
    const parentData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(parent);
    if (utils.isTrackingLogicalChildNodes(parent)) {
      logicalTree.recordRemoveChild(node, parent);
      if (hasShadowRootWithSlot(parent)) {
        parentData.root._asyncRender();
        preventNativeRemove = true;
      }
    }
    if (getScopingShim() && !skipUnscoping && ownerRoot) {
      const oldScopeName = currentScopeForNode(node);
      treeVisitor(node, (node) => {
        removeShadyScoping(node, oldScopeName);
      });
    }
    removeOwnerShadyRoot(node);
    if (ownerRoot) {
      let changeSlotContent = parent && parent.localName === "slot";
      if (changeSlotContent) {
        preventNativeRemove = true;
      }
      removingInsertionPoint = ownerRoot._removeContainedSlots(node);
      if (removingInsertionPoint || changeSlotContent) {
        ownerRoot._asyncRender();
      }
    }
    if (!preventNativeRemove) {
      let container = utils.isShadyRoot(parent) ? parent.host : parent;
      if (!(parentData.root || node.localName === "slot") || container === parentNode(node)) {
        nativeMethods.removeChild.call(container, node);
      }
    }
    scheduleObserver(parent, null, node);
    return node;
  }
  function removeOwnerShadyRoot(node) {
    if (hasCachedOwnerRoot(node)) {
      let c$ = node.childNodes;
      for (let i = 0, l = c$.length, n; i < l && (n = c$[i]); i++) {
        removeOwnerShadyRoot(n);
      }
    }
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
    if (nodeData) {
      nodeData.ownerShadyRoot = undefined;
    }
  }
  function hasCachedOwnerRoot(node) {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
    return Boolean(nodeData && nodeData.ownerShadyRoot !== undefined);
  }
  function firstComposedNode(node) {
    let composed = node;
    if (node && node.localName === "slot") {
      const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
      const flattened = nodeData && nodeData.flattenedNodes;
      composed = flattened && flattened.length ? flattened[0] : firstComposedNode(node.nextSibling);
    }
    return composed;
  }
  function hasShadowRootWithSlot(node) {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
    let root = nodeData && nodeData.root;
    return root && root._hasInsertionPoint();
  }
  function distributeAttributeChange(node, name) {
    if (name === "slot") {
      const parent = node.parentNode;
      if (hasShadowRootWithSlot(parent)) {
        (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(parent).root._asyncRender();
      }
    } else {
      if (node.localName === "slot" && name === "name") {
        let root = utils.ownerShadyRootForNode(node);
        if (root) {
          root._updateSlotName(node);
          root._asyncRender();
        }
      }
    }
  }
  function scheduleObserver(node, addedNode, removedNode) {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
    const observer = nodeData && nodeData.observer;
    if (observer) {
      if (addedNode) {
        observer.addedNodes.push(addedNode);
      }
      if (removedNode) {
        observer.removedNodes.push(removedNode);
      }
      observer.schedule();
    }
  }
  function getRootNode(node, options) {
    if (!node || !node.nodeType) {
      return;
    }
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
    let root = nodeData.ownerShadyRoot;
    if (root === undefined) {
      if (utils.isShadyRoot(node)) {
        root = node;
        nodeData.ownerShadyRoot = root;
      } else {
        let parent = node.parentNode;
        root = parent ? getRootNode(parent) : node;
        if (nativeMethods.contains.call(document.documentElement, node)) {
          nodeData.ownerShadyRoot = root;
        }
      }
    }
    return root;
  }
  function query(node, matcher, halter) {
    let list = [];
    queryElements(node.childNodes, matcher, halter, list);
    return list;
  }
  function queryElements(elements, matcher, halter, list) {
    for (let i = 0, l = elements.length, c; i < l && (c = elements[i]); i++) {
      if (c.nodeType === Node.ELEMENT_NODE && queryElement(c, matcher, halter, list)) {
        return true;
      }
    }
  }
  function queryElement(node, matcher, halter, list) {
    let result = matcher(node);
    if (result) {
      list.push(node);
    }
    if (halter && halter(result)) {
      return result;
    }
    queryElements(node.childNodes, matcher, halter, list);
  }
  function renderRootNode(element) {
    var root = element.getRootNode();
    if (utils.isShadyRoot(root)) {
      root._render();
    }
  }
  let scopingShim = null;
  function getScopingShim() {
    if (!scopingShim) {
      scopingShim = window["ShadyCSS"] && window["ShadyCSS"]["ScopingShim"];
    }
    return scopingShim || null;
  }
  function setAttribute(node, attr, value) {
    const scopingShim = getScopingShim();
    if (scopingShim && attr === "class") {
      scopingShim["setElementClass"](node, value);
    } else {
      nativeMethods.setAttribute.call(node, attr, value);
      distributeAttributeChange(node, attr);
    }
  }
  function removeAttribute(node, attr) {
    nativeMethods.removeAttribute.call(node, attr);
    distributeAttributeChange(node, attr);
  }
  function cloneNode(node, deep) {
    if (node.localName == "template") {
      return nativeMethods.cloneNode.call(node, deep);
    } else {
      let n = nativeMethods.cloneNode.call(node, false);
      if (deep && n.nodeType !== Node.ATTRIBUTE_NODE) {
        let c$ = node.childNodes;
        for (let i = 0, nc; i < c$.length; i++) {
          nc = c$[i].cloneNode(true);
          n.appendChild(nc);
        }
      }
      return n;
    }
  }
  function importNode(node, deep) {
    if (node.ownerDocument !== document || node.localName === "template") {
      return nativeMethods.importNode.call(document, node, deep);
    }
    let n = nativeMethods.importNode.call(document, node, false);
    if (deep) {
      let c$ = node.childNodes;
      for (let i = 0, nc; i < c$.length; i++) {
        nc = importNode(c$[i], true);
        n.appendChild(nc);
      }
    }
    return n;
  }
  function addShadyScoping(node, newScopeName) {
    const scopingShim = getScopingShim();
    if (!scopingShim) {
      return;
    }
    scopingShim["scopeNode"](node, newScopeName);
  }
  function removeShadyScoping(node, currentScopeName) {
    const scopingShim = getScopingShim();
    if (!scopingShim) {
      return;
    }
    scopingShim["unscopeNode"](node, currentScopeName);
  }
  function replaceShadyScoping(node, newScopeName, oldScopeName) {
    const scopingShim = getScopingShim();
    if (!scopingShim) {
      return;
    }
    removeShadyScoping(node, oldScopeName);
    addShadyScoping(node, newScopeName);
  }
  function currentScopeIsCorrect(node, newScopeName) {
    const scopingShim = getScopingShim();
    if (!scopingShim) {
      return true;
    }
    if (node.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
      let correctScope = true;
      for (let idx = 0; correctScope && idx < node.childNodes.length; idx++) {
        correctScope = correctScope && currentScopeIsCorrect(node.childNodes[idx], newScopeName);
      }
      return correctScope;
    }
    if (node.nodeType !== Node.ELEMENT_NODE) {
      return true;
    }
    const currentScope = scopingShim["currentScopeForNode"](node);
    return currentScope === newScopeName;
  }
  function currentScopeForNode(node) {
    if (node.nodeType !== Node.ELEMENT_NODE) {
      return "";
    }
    const scopingShim = getScopingShim();
    if (!scopingShim) {
      return "";
    }
    return scopingShim["currentScopeForNode"](node);
  }
  function treeVisitor(node, visitorFn) {
    if (!node) {
      return;
    }
    if (node.nodeType === Node.ELEMENT_NODE) {
      visitorFn(node);
    }
    for (let idx = 0, n; idx < node.childNodes.length; idx++) {
      n = node.childNodes[idx];
      if (n.nodeType === Node.ELEMENT_NODE) {
        treeVisitor(n, visitorFn);
      }
    }
  }
}, "node_modules/@webcomponents/shadydom/src/logical-mutation.js", ["node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/logical-tree.js", "node_modules/@webcomponents/shadydom/src/native-methods.js", "node_modules/@webcomponents/shadydom/src/native-tree.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/patch-events.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {addEventListener:{enumerable:true, get:function() {
    return addEventListener;
  }}, findListener:{enumerable:true, get:function() {
    return findListener;
  }}, patchEvents:{enumerable:true, get:function() {
    return patchEvents;
  }}, removeEventListener:{enumerable:true, get:function() {
    return removeEventListener;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var nativeMethods = $$require("node_modules/@webcomponents/shadydom/src/native-methods.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  const eventWrappersName = `__eventWrappers${Date.now()}`;
  const composedGetter = (() => {
    const composedProp = Object.getOwnPropertyDescriptor(Event.prototype, "composed");
    return composedProp ? (ev) => composedProp.get.call(ev) : null;
  })();
  const alwaysComposed = {"blur":true, "focus":true, "focusin":true, "focusout":true, "click":true, "dblclick":true, "mousedown":true, "mouseenter":true, "mouseleave":true, "mousemove":true, "mouseout":true, "mouseover":true, "mouseup":true, "wheel":true, "beforeinput":true, "input":true, "keydown":true, "keyup":true, "compositionstart":true, "compositionupdate":true, "compositionend":true, "touchstart":true, "touchend":true, "touchmove":true, "touchcancel":true, "pointerover":true, "pointerenter":true, 
  "pointerdown":true, "pointermove":true, "pointerup":true, "pointercancel":true, "pointerout":true, "pointerleave":true, "gotpointercapture":true, "lostpointercapture":true, "dragstart":true, "drag":true, "dragenter":true, "dragleave":true, "dragover":true, "drop":true, "dragend":true, "DOMActivate":true, "DOMFocusIn":true, "DOMFocusOut":true, "keypress":true};
  const unpatchedEvents = {"DOMAttrModified":true, "DOMAttributeNameChanged":true, "DOMCharacterDataModified":true, "DOMElementNameChanged":true, "DOMNodeInserted":true, "DOMNodeInsertedIntoDocument":true, "DOMNodeRemoved":true, "DOMNodeRemovedFromDocument":true, "DOMSubtreeModified":true};
  function pathComposer(startNode, composed) {
    let composedPath = [];
    let current = startNode;
    let startRoot = startNode === window ? window : startNode.getRootNode();
    while (current) {
      composedPath.push(current);
      if (current.assignedSlot) {
        current = current.assignedSlot;
      } else {
        if (current.nodeType === Node.DOCUMENT_FRAGMENT_NODE && current.host && (composed || current !== startRoot)) {
          current = current.host;
        } else {
          current = current.parentNode;
        }
      }
    }
    if (composedPath[composedPath.length - 1] === document) {
      composedPath.push(window);
    }
    return composedPath;
  }
  function retarget(refNode, path) {
    if (!utils.isShadyRoot) {
      return refNode;
    }
    let refNodePath = pathComposer(refNode, true);
    let p$ = path;
    for (let i = 0, ancestor, lastRoot, root, rootIdx; i < p$.length; i++) {
      ancestor = p$[i];
      root = ancestor === window ? window : ancestor.getRootNode();
      if (root !== lastRoot) {
        rootIdx = refNodePath.indexOf(root);
        lastRoot = root;
      }
      if (!utils.isShadyRoot(root) || rootIdx > -1) {
        return ancestor;
      }
    }
  }
  let eventMixin = {get composed() {
    if (this.__composed === undefined) {
      if (composedGetter) {
        this.__composed = this.type === "focusin" || this.type === "focusout" || composedGetter(this);
      } else {
        if (this.isTrusted !== false) {
          this.__composed = alwaysComposed[this.type];
        }
      }
    }
    return this.__composed || false;
  }, composedPath() {
    if (!this.__composedPath) {
      this.__composedPath = pathComposer(this["__target"], this.composed);
    }
    return this.__composedPath;
  }, get target() {
    return retarget(this.currentTarget || this["__previousCurrentTarget"], this.composedPath());
  }, get relatedTarget() {
    if (!this.__relatedTarget) {
      return null;
    }
    if (!this.__relatedTargetComposedPath) {
      this.__relatedTargetComposedPath = pathComposer(this.__relatedTarget, true);
    }
    return retarget(this.currentTarget || this["__previousCurrentTarget"], this.__relatedTargetComposedPath);
  }, stopPropagation() {
    Event.prototype.stopPropagation.call(this);
    this.__propagationStopped = true;
  }, stopImmediatePropagation() {
    Event.prototype.stopImmediatePropagation.call(this);
    this.__immediatePropagationStopped = true;
    this.__propagationStopped = true;
  }};
  function mixinComposedFlag(Base) {
    let klazz = function(type, options) {
      let event = new Base(type, options);
      event.__composed = options && Boolean(options["composed"]);
      return event;
    };
    utils.mixin(klazz, Base);
    klazz.prototype = Base.prototype;
    return klazz;
  }
  let nonBubblingEventsToRetarget = {"focus":true, "blur":true};
  function hasRetargeted(event) {
    return event["__target"] !== event.target || event.__relatedTarget !== event.relatedTarget;
  }
  function fireHandlers(event, node, phase) {
    let hs = node.__handlers && node.__handlers[event.type] && node.__handlers[event.type][phase];
    if (hs) {
      for (let i = 0, fn; fn = hs[i]; i++) {
        if (hasRetargeted(event) && event.target === event.relatedTarget) {
          return;
        }
        fn.call(node, event);
        if (event.__immediatePropagationStopped) {
          return;
        }
      }
    }
  }
  function retargetNonBubblingEvent(e) {
    let path = e.composedPath();
    let node;
    Object.defineProperty(e, "currentTarget", {get:function() {
      return node;
    }, configurable:true});
    for (let i = path.length - 1; i >= 0; i--) {
      node = path[i];
      fireHandlers(e, node, "capture");
      if (e.__propagationStopped) {
        return;
      }
    }
    Object.defineProperty(e, "eventPhase", {get() {
      return Event.AT_TARGET;
    }});
    let lastFiredRoot;
    for (let i = 0; i < path.length; i++) {
      node = path[i];
      const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
      const root = nodeData && nodeData.root;
      if (i === 0 || root && root === lastFiredRoot) {
        fireHandlers(e, node, "bubble");
        if (node !== window) {
          lastFiredRoot = node.getRootNode();
        }
        if (e.__propagationStopped) {
          return;
        }
      }
    }
  }
  function listenerSettingsEqual(savedListener, node, type, capture, once, passive) {
    let {node:savedNode, type:savedType, capture:savedCapture, once:savedOnce, passive:savedPassive} = savedListener;
    return node === savedNode && type === savedType && capture === savedCapture && once === savedOnce && passive === savedPassive;
  }
  function findListener(wrappers, node, type, capture, once, passive) {
    for (let i = 0; i < wrappers.length; i++) {
      if (listenerSettingsEqual(wrappers[i], node, type, capture, once, passive)) {
        return i;
      }
    }
    return -1;
  }
  function getEventWrappers(eventLike) {
    let wrappers = null;
    try {
      wrappers = eventLike[eventWrappersName];
    } catch (e) {
    }
    return wrappers;
  }
  function addEventListener(type, fnOrObj, optionsOrCapture) {
    if (!fnOrObj) {
      return;
    }
    const handlerType = typeof fnOrObj;
    if (handlerType !== "function" && handlerType !== "object") {
      return;
    }
    if (handlerType === "object" && (!fnOrObj.handleEvent || typeof fnOrObj.handleEvent !== "function")) {
      return;
    }
    const ael = this instanceof Window ? nativeMethods.windowAddEventListener : nativeMethods.addEventListener;
    if (unpatchedEvents[type]) {
      return ael.call(this, type, fnOrObj, optionsOrCapture);
    }
    let capture, once, passive;
    if (optionsOrCapture && typeof optionsOrCapture === "object") {
      capture = Boolean(optionsOrCapture.capture);
      once = Boolean(optionsOrCapture.once);
      passive = Boolean(optionsOrCapture.passive);
    } else {
      capture = Boolean(optionsOrCapture);
      once = false;
      passive = false;
    }
    let target = optionsOrCapture && optionsOrCapture.__shadyTarget || this;
    let wrappers = fnOrObj[eventWrappersName];
    if (wrappers) {
      if (findListener(wrappers, target, type, capture, once, passive) > -1) {
        return;
      }
    } else {
      fnOrObj[eventWrappersName] = [];
    }
    const wrapperFn = function(e) {
      if (once) {
        this.removeEventListener(type, fnOrObj, optionsOrCapture);
      }
      if (!e["__target"]) {
        patchEvent(e);
      }
      let lastCurrentTargetDesc;
      if (target !== this) {
        lastCurrentTargetDesc = Object.getOwnPropertyDescriptor(e, "currentTarget");
        Object.defineProperty(e, "currentTarget", {get() {
          return target;
        }, configurable:true});
      }
      e["__previousCurrentTarget"] = e["currentTarget"];
      if (utils.isShadyRoot(target) && e.composedPath().indexOf(target) == -1) {
        return;
      }
      if (e.composed || e.composedPath().indexOf(target) > -1) {
        if (hasRetargeted(e) && e.target === e.relatedTarget) {
          if (e.eventPhase === Event.BUBBLING_PHASE) {
            e.stopImmediatePropagation();
          }
          return;
        }
        if (e.eventPhase !== Event.CAPTURING_PHASE && !e.bubbles && e.target !== target && !(target instanceof Window)) {
          return;
        }
        let ret = handlerType === "function" ? fnOrObj.call(target, e) : fnOrObj.handleEvent && fnOrObj.handleEvent(e);
        if (target !== this) {
          if (lastCurrentTargetDesc) {
            Object.defineProperty(e, "currentTarget", lastCurrentTargetDesc);
            lastCurrentTargetDesc = null;
          } else {
            delete e["currentTarget"];
          }
        }
        return ret;
      }
    };
    fnOrObj[eventWrappersName].push({node:target, type:type, capture:capture, once:once, passive:passive, wrapperFn:wrapperFn});
    if (nonBubblingEventsToRetarget[type]) {
      this.__handlers = this.__handlers || {};
      this.__handlers[type] = this.__handlers[type] || {"capture":[], "bubble":[]};
      this.__handlers[type][capture ? "capture" : "bubble"].push(wrapperFn);
    } else {
      ael.call(this, type, wrapperFn, optionsOrCapture);
    }
  }
  function removeEventListener(type, fnOrObj, optionsOrCapture) {
    if (!fnOrObj) {
      return;
    }
    const rel = this instanceof Window ? nativeMethods.windowRemoveEventListener : nativeMethods.removeEventListener;
    if (unpatchedEvents[type]) {
      return rel.call(this, type, fnOrObj, optionsOrCapture);
    }
    let capture, once, passive;
    if (optionsOrCapture && typeof optionsOrCapture === "object") {
      capture = Boolean(optionsOrCapture.capture);
      once = Boolean(optionsOrCapture.once);
      passive = Boolean(optionsOrCapture.passive);
    } else {
      capture = Boolean(optionsOrCapture);
      once = false;
      passive = false;
    }
    let target = optionsOrCapture && optionsOrCapture.__shadyTarget || this;
    let wrapperFn = undefined;
    let wrappers = getEventWrappers(fnOrObj);
    if (wrappers) {
      let idx = findListener(wrappers, target, type, capture, once, passive);
      if (idx > -1) {
        wrapperFn = wrappers.splice(idx, 1)[0].wrapperFn;
        if (!wrappers.length) {
          fnOrObj[eventWrappersName] = undefined;
        }
      }
    }
    rel.call(this, type, wrapperFn || fnOrObj, optionsOrCapture);
    if (wrapperFn && nonBubblingEventsToRetarget[type] && this.__handlers && this.__handlers[type]) {
      const arr = this.__handlers[type][capture ? "capture" : "bubble"];
      const idx = arr.indexOf(wrapperFn);
      if (idx > -1) {
        arr.splice(idx, 1);
      }
    }
  }
  function activateFocusEventOverrides() {
    for (let ev in nonBubblingEventsToRetarget) {
      window.addEventListener(ev, function(e) {
        if (!e["__target"]) {
          patchEvent(e);
          retargetNonBubblingEvent(e);
        }
      }, true);
    }
  }
  function patchEvent(event) {
    event["__target"] = event.target;
    event.__relatedTarget = event.relatedTarget;
    if (utils.settings.hasDescriptors) {
      utils.patchPrototype(event, eventMixin);
    } else {
      utils.extend(event, eventMixin);
    }
  }
  let PatchedEvent = mixinComposedFlag(window.Event);
  let PatchedCustomEvent = mixinComposedFlag(window.CustomEvent);
  let PatchedMouseEvent = mixinComposedFlag(window.MouseEvent);
  function patchEvents() {
    window.Event = PatchedEvent;
    window.CustomEvent = PatchedCustomEvent;
    window.MouseEvent = PatchedMouseEvent;
    activateFocusEventOverrides();
    if (!composedGetter && Object.getOwnPropertyDescriptor(Event.prototype, "isTrusted")) {
      const composedClickFn = function() {
        const ev = new MouseEvent("click", {bubbles:true, cancelable:true, composed:true});
        this.dispatchEvent(ev);
      };
      if (Element.prototype.click) {
        Element.prototype.click = composedClickFn;
      } else {
        if (HTMLElement.prototype.click) {
          HTMLElement.prototype.click = composedClickFn;
        }
      }
    }
  }
}, "node_modules/@webcomponents/shadydom/src/patch-events.js", ["node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/native-methods.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/array-splice.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {calculateSplices:{enumerable:true, get:function() {
    return calculateSplices;
  }}});
  function newSplice(index, removed, addedCount) {
    return {index:index, removed:removed, addedCount:addedCount};
  }
  const EDIT_LEAVE = 0;
  const EDIT_UPDATE = 1;
  const EDIT_ADD = 2;
  const EDIT_DELETE = 3;
  function calcEditDistances(current, currentStart, currentEnd, old, oldStart, oldEnd) {
    let rowCount = oldEnd - oldStart + 1;
    let columnCount = currentEnd - currentStart + 1;
    let distances = new Array(rowCount);
    for (let i = 0; i < rowCount; i++) {
      distances[i] = new Array(columnCount);
      distances[i][0] = i;
    }
    for (let j = 0; j < columnCount; j++) {
      distances[0][j] = j;
    }
    for (let i = 1; i < rowCount; i++) {
      for (let j = 1; j < columnCount; j++) {
        if (equals(current[currentStart + j - 1], old[oldStart + i - 1])) {
          distances[i][j] = distances[i - 1][j - 1];
        } else {
          let north = distances[i - 1][j] + 1;
          let west = distances[i][j - 1] + 1;
          distances[i][j] = north < west ? north : west;
        }
      }
    }
    return distances;
  }
  function spliceOperationsFromEditDistances(distances) {
    let i = distances.length - 1;
    let j = distances[0].length - 1;
    let current = distances[i][j];
    let edits = [];
    while (i > 0 || j > 0) {
      if (i == 0) {
        edits.push(EDIT_ADD);
        j--;
        continue;
      }
      if (j == 0) {
        edits.push(EDIT_DELETE);
        i--;
        continue;
      }
      let northWest = distances[i - 1][j - 1];
      let west = distances[i - 1][j];
      let north = distances[i][j - 1];
      let min;
      if (west < north) {
        min = west < northWest ? west : northWest;
      } else {
        min = north < northWest ? north : northWest;
      }
      if (min == northWest) {
        if (northWest == current) {
          edits.push(EDIT_LEAVE);
        } else {
          edits.push(EDIT_UPDATE);
          current = northWest;
        }
        i--;
        j--;
      } else {
        if (min == west) {
          edits.push(EDIT_DELETE);
          i--;
          current = west;
        } else {
          edits.push(EDIT_ADD);
          j--;
          current = north;
        }
      }
    }
    edits.reverse();
    return edits;
  }
  function calcSplices(current, currentStart, currentEnd, old, oldStart, oldEnd) {
    let prefixCount = 0;
    let suffixCount = 0;
    let splice;
    let minLength = Math.min(currentEnd - currentStart, oldEnd - oldStart);
    if (currentStart == 0 && oldStart == 0) {
      prefixCount = sharedPrefix(current, old, minLength);
    }
    if (currentEnd == current.length && oldEnd == old.length) {
      suffixCount = sharedSuffix(current, old, minLength - prefixCount);
    }
    currentStart += prefixCount;
    oldStart += prefixCount;
    currentEnd -= suffixCount;
    oldEnd -= suffixCount;
    if (currentEnd - currentStart == 0 && oldEnd - oldStart == 0) {
      return [];
    }
    if (currentStart == currentEnd) {
      splice = newSplice(currentStart, [], 0);
      while (oldStart < oldEnd) {
        splice.removed.push(old[oldStart++]);
      }
      return [splice];
    } else {
      if (oldStart == oldEnd) {
        return [newSplice(currentStart, [], currentEnd - currentStart)];
      }
    }
    let ops = spliceOperationsFromEditDistances(calcEditDistances(current, currentStart, currentEnd, old, oldStart, oldEnd));
    splice = undefined;
    let splices = [];
    let index = currentStart;
    let oldIndex = oldStart;
    for (let i = 0; i < ops.length; i++) {
      switch(ops[i]) {
        case EDIT_LEAVE:
          if (splice) {
            splices.push(splice);
            splice = undefined;
          }
          index++;
          oldIndex++;
          break;
        case EDIT_UPDATE:
          if (!splice) {
            splice = newSplice(index, [], 0);
          }
          splice.addedCount++;
          index++;
          splice.removed.push(old[oldIndex]);
          oldIndex++;
          break;
        case EDIT_ADD:
          if (!splice) {
            splice = newSplice(index, [], 0);
          }
          splice.addedCount++;
          index++;
          break;
        case EDIT_DELETE:
          if (!splice) {
            splice = newSplice(index, [], 0);
          }
          splice.removed.push(old[oldIndex]);
          oldIndex++;
          break;
      }
    }
    if (splice) {
      splices.push(splice);
    }
    return splices;
  }
  function sharedPrefix(current, old, searchLength) {
    for (let i = 0; i < searchLength; i++) {
      if (!equals(current[i], old[i])) {
        return i;
      }
    }
    return searchLength;
  }
  function sharedSuffix(current, old, searchLength) {
    let index1 = current.length;
    let index2 = old.length;
    let count = 0;
    while (count < searchLength && equals(current[--index1], old[--index2])) {
      count++;
    }
    return count;
  }
  function equals(currentValue, previousValue) {
    return currentValue === previousValue;
  }
  function calculateSplices(current, previous) {
    return calcSplices(current, 0, current.length, previous, 0, previous.length);
  }
}, "node_modules/@webcomponents/shadydom/src/array-splice.js", []);

//node_modules/@webcomponents/shadydom/src/attach-shadow.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {ShadyRoot:{enumerable:true, get:function() {
    return ShadyRoot;
  }}, attachShadow:{enumerable:true, get:function() {
    return attachShadow;
  }}});
  var module$node_modules$$webcomponents$shadydom$src$array_splice = $$require("node_modules/@webcomponents/shadydom/src/array-splice.js");
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var module$node_modules$$webcomponents$shadydom$src$flush = $$require("node_modules/@webcomponents/shadydom/src/flush.js");
  var module$node_modules$$webcomponents$shadydom$src$logical_tree = $$require("node_modules/@webcomponents/shadydom/src/logical-tree.js");
  var module$node_modules$$webcomponents$shadydom$src$native_methods = $$require("node_modules/@webcomponents/shadydom/src/native-methods.js");
  var module$node_modules$$webcomponents$shadydom$src$native_tree = $$require("node_modules/@webcomponents/shadydom/src/native-tree.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  const {parentNode, childNodes} = module$node_modules$$webcomponents$shadydom$src$native_tree.accessors;
  const ShadyRootConstructionToken = {};
  const CATCHALL_NAME = "__catchall";
  const SHADYROOT_NAME = "ShadyRoot";
  const MODE_CLOSED = "closed";
  let isRendering = utils.settings["deferConnectionCallbacks"] && document.readyState === "loading";
  let rootRendered;
  function ancestorList(node) {
    let ancestors = [];
    do {
      ancestors.unshift(node);
    } while (node = node.parentNode);
    return ancestors;
  }
  class ShadyRoot {
    constructor(token, host, options) {
      if (token !== ShadyRootConstructionToken) {
        throw new TypeError("Illegal constructor");
      }
      this._localName = SHADYROOT_NAME;
      this.host = host;
      this._mode = options && options.mode;
      (0,module$node_modules$$webcomponents$shadydom$src$logical_tree.recordChildNodes)(host);
      const hostData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(host);
      hostData.root = this;
      hostData.publicRoot = this._mode !== MODE_CLOSED ? this : null;
      const rootData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(this);
      rootData.firstChild = rootData.lastChild = rootData.parentNode = rootData.nextSibling = rootData.previousSibling = null;
      rootData.childNodes = [];
      this._renderPending = false;
      this._hasRendered = false;
      this._slotList = null;
      this._slotMap = null;
      this._pendingSlots = null;
      this._initialChildren = null;
      this._asyncRender();
    }
    _asyncRender() {
      if (!this._renderPending) {
        this._renderPending = true;
        (0,module$node_modules$$webcomponents$shadydom$src$flush.enqueue)(() => this._render());
      }
    }
    _getRenderRoot() {
      let renderRoot;
      let root = this;
      while (root) {
        if (root._renderPending) {
          renderRoot = root;
        }
        root = root._rendererForHost();
      }
      return renderRoot;
    }
    _rendererForHost() {
      let root = this.host.getRootNode();
      if (utils.isShadyRoot(root)) {
        let c$ = this.host.childNodes;
        for (let i = 0, c; i < c$.length; i++) {
          c = c$[i];
          if (this._isInsertionPoint(c)) {
            return root;
          }
        }
      }
    }
    _render() {
      const root = this._getRenderRoot();
      if (root) {
        root["_renderRoot"]();
      }
    }
    ["_renderRoot"]() {
      const wasRendering = isRendering;
      isRendering = true;
      this._renderPending = false;
      if (this._slotList) {
        this._distribute();
        this._compose();
      }
      if (!this._hasRendered) {
        const c$ = this.host.childNodes;
        for (let i = 0, l = c$.length; i < l; i++) {
          const child = c$[i];
          const data = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(child);
          if (parentNode(child) === this.host && (child.localName === "slot" || !data.assignedSlot)) {
            module$node_modules$$webcomponents$shadydom$src$native_methods.removeChild.call(this.host, child);
          }
        }
      }
      this._hasRendered = true;
      isRendering = wasRendering;
      if (rootRendered) {
        rootRendered();
      }
    }
    _distribute() {
      this._validateSlots();
      for (let i = 0, slot; i < this._slotList.length; i++) {
        slot = this._slotList[i];
        this._clearSlotAssignedNodes(slot);
      }
      for (let n = this.host.firstChild; n; n = n.nextSibling) {
        this._distributeNodeToSlot(n);
      }
      for (let i = 0; i < this._slotList.length; i++) {
        const slot = this._slotList[i];
        const slotData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(slot);
        if (!slotData.assignedNodes.length) {
          for (let n = slot.firstChild; n; n = n.nextSibling) {
            this._distributeNodeToSlot(n, slot);
          }
        }
        const slotParentData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(slot.parentNode);
        const slotParentRoot = slotParentData && slotParentData.root;
        if (slotParentRoot && slotParentRoot._hasInsertionPoint()) {
          slotParentRoot["_renderRoot"]();
        }
        this._addAssignedToFlattenedNodes(slotData.flattenedNodes, slotData.assignedNodes);
        let prevAssignedNodes = slotData._previouslyAssignedNodes;
        if (prevAssignedNodes) {
          for (let i = 0; i < prevAssignedNodes.length; i++) {
            (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(prevAssignedNodes[i])._prevAssignedSlot = null;
          }
          slotData._previouslyAssignedNodes = null;
          if (prevAssignedNodes.length > slotData.assignedNodes.length) {
            slotData.dirty = true;
          }
        }
        if (slotData.dirty) {
          slotData.dirty = false;
          this._fireSlotChange(slot);
        }
      }
    }
    _distributeNodeToSlot(node, forcedSlot) {
      const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(node);
      let oldSlot = nodeData._prevAssignedSlot;
      nodeData._prevAssignedSlot = null;
      let slot = forcedSlot;
      if (!slot) {
        let name = node.slot || CATCHALL_NAME;
        const list = this._slotMap[name];
        slot = list && list[0];
      }
      if (slot) {
        const slotData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(slot);
        slotData.assignedNodes.push(node);
        nodeData.assignedSlot = slot;
      } else {
        nodeData.assignedSlot = undefined;
      }
      if (oldSlot !== nodeData.assignedSlot) {
        if (nodeData.assignedSlot) {
          (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(nodeData.assignedSlot).dirty = true;
        }
      }
    }
    _clearSlotAssignedNodes(slot) {
      const slotData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(slot);
      let n$ = slotData.assignedNodes;
      slotData.assignedNodes = [];
      slotData.flattenedNodes = [];
      slotData._previouslyAssignedNodes = n$;
      if (n$) {
        for (let i = 0; i < n$.length; i++) {
          let n = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(n$[i]);
          n._prevAssignedSlot = n.assignedSlot;
          if (n.assignedSlot === slot) {
            n.assignedSlot = null;
          }
        }
      }
    }
    _addAssignedToFlattenedNodes(flattened, assigned) {
      for (let i = 0, n; i < assigned.length && (n = assigned[i]); i++) {
        if (n.localName == "slot") {
          const nestedAssigned = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(n).assignedNodes;
          if (nestedAssigned && nestedAssigned.length) {
            this._addAssignedToFlattenedNodes(flattened, nestedAssigned);
          }
        } else {
          flattened.push(assigned[i]);
        }
      }
    }
    _fireSlotChange(slot) {
      module$node_modules$$webcomponents$shadydom$src$native_methods.dispatchEvent.call(slot, new Event("slotchange"));
      const slotData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(slot);
      if (slotData.assignedSlot) {
        this._fireSlotChange(slotData.assignedSlot);
      }
    }
    _compose() {
      const slots = this._slotList;
      let composeList = [];
      for (let i = 0; i < slots.length; i++) {
        const parent = slots[i].parentNode;
        const parentData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(parent);
        if (!(parentData && parentData.root) && composeList.indexOf(parent) < 0) {
          composeList.push(parent);
        }
      }
      for (let i = 0; i < composeList.length; i++) {
        const node = composeList[i];
        const targetNode = node === this ? this.host : node;
        this._updateChildNodes(targetNode, this._composeNode(node));
      }
    }
    _composeNode(node) {
      let children = [];
      let c$ = node.childNodes;
      for (let i = 0; i < c$.length; i++) {
        let child = c$[i];
        if (this._isInsertionPoint(child)) {
          let flattenedNodes = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(child).flattenedNodes;
          for (let j = 0; j < flattenedNodes.length; j++) {
            let distributedNode = flattenedNodes[j];
            children.push(distributedNode);
          }
        } else {
          children.push(child);
        }
      }
      return children;
    }
    _isInsertionPoint(node) {
      return node.localName == "slot";
    }
    _updateChildNodes(container, children) {
      let composed = childNodes(container);
      let splices = (0,module$node_modules$$webcomponents$shadydom$src$array_splice.calculateSplices)(children, composed);
      for (let i = 0, d = 0, s; i < splices.length && (s = splices[i]); i++) {
        for (let j = 0, n; j < s.removed.length && (n = s.removed[j]); j++) {
          if (parentNode(n) === container) {
            module$node_modules$$webcomponents$shadydom$src$native_methods.removeChild.call(container, n);
          }
          composed.splice(s.index + d, 1);
        }
        d -= s.addedCount;
      }
      for (let i = 0, s, next; i < splices.length && (s = splices[i]); i++) {
        next = composed[s.index];
        for (let j = s.index, n; j < s.index + s.addedCount; j++) {
          n = children[j];
          module$node_modules$$webcomponents$shadydom$src$native_methods.insertBefore.call(container, n, next);
          composed.splice(j, 0, n);
        }
      }
    }
    _ensureSlotData() {
      this._pendingSlots = this._pendingSlots || [];
      this._slotList = this._slotList || [];
      this._slotMap = this._slotMap || {};
    }
    _addSlots(slots) {
      this._ensureSlotData();
      this._pendingSlots.push(...slots);
    }
    _validateSlots() {
      if (this._pendingSlots && this._pendingSlots.length) {
        this._mapSlots(this._pendingSlots);
        this._pendingSlots = [];
      }
    }
    _mapSlots(slots) {
      let slotNamesToSort;
      for (let i = 0; i < slots.length; i++) {
        let slot = slots[i];
        (0,module$node_modules$$webcomponents$shadydom$src$logical_tree.recordChildNodes)(slot);
        (0,module$node_modules$$webcomponents$shadydom$src$logical_tree.recordChildNodes)(slot.parentNode);
        let name = this._nameForSlot(slot);
        if (this._slotMap[name]) {
          slotNamesToSort = slotNamesToSort || {};
          slotNamesToSort[name] = true;
          this._slotMap[name].push(slot);
        } else {
          this._slotMap[name] = [slot];
        }
        this._slotList.push(slot);
      }
      if (slotNamesToSort) {
        for (let n in slotNamesToSort) {
          this._slotMap[n] = this._sortSlots(this._slotMap[n]);
        }
      }
    }
    _nameForSlot(slot) {
      const name = slot["name"] || slot.getAttribute("name") || CATCHALL_NAME;
      slot.__slotName = name;
      return name;
    }
    _sortSlots(slots) {
      return slots.sort((a, b) => {
        let listA = ancestorList(a);
        let listB = ancestorList(b);
        for (var i = 0; i < listA.length; i++) {
          let nA = listA[i];
          let nB = listB[i];
          if (nA !== nB) {
            let c$ = Array.from(nA.parentNode.childNodes);
            return c$.indexOf(nA) - c$.indexOf(nB);
          }
        }
      });
    }
    _removeContainedSlots(container) {
      if (!this._slotList) {
        return;
      }
      this._validateSlots();
      let didRemove;
      const map = this._slotMap;
      for (let n in map) {
        let slots = map[n];
        for (let i = 0; i < slots.length; i++) {
          let slot = slots[i];
          if (utils.contains(container, slot)) {
            slots.splice(i, 1);
            const x = this._slotList.indexOf(slot);
            if (x >= 0) {
              this._slotList.splice(x, 1);
            }
            i--;
            this._removeFlattenedNodes(slot);
            didRemove = true;
          }
        }
      }
      return didRemove;
    }
    _updateSlotName(slot) {
      if (!this._slotList) {
        return;
      }
      this._validateSlots();
      const oldName = slot.__slotName;
      const name = this._nameForSlot(slot);
      if (name === oldName) {
        return;
      }
      let slots = this._slotMap[oldName];
      const i = slots.indexOf(slot);
      if (i >= 0) {
        slots.splice(i, 1);
      }
      let list = this._slotMap[name] || (this._slotMap[name] = []);
      list.push(slot);
      if (list.length > 1) {
        this._slotMap[name] = this._sortSlots(list);
      }
    }
    _removeFlattenedNodes(slot) {
      const data = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(slot);
      let n$ = data.flattenedNodes;
      if (n$) {
        for (let i = 0; i < n$.length; i++) {
          let node = n$[i];
          let parent = parentNode(node);
          if (parent) {
            module$node_modules$$webcomponents$shadydom$src$native_methods.removeChild.call(parent, node);
          }
        }
      }
      data.flattenedNodes = [];
      data.assignedNodes = [];
    }
    _hasInsertionPoint() {
      this._validateSlots();
      return Boolean(this._slotList && this._slotList.length);
    }
  }
  function attachShadow(host, options) {
    if (!host) {
      throw "Must provide a host.";
    }
    if (!options) {
      throw "Not enough arguments.";
    }
    return new ShadyRoot(ShadyRootConstructionToken, host, options);
  }
  if (window["customElements"] && utils.settings.inUse) {
    let connectMap = new Map;
    rootRendered = function() {
      const map = Array.from(connectMap);
      connectMap.clear();
      for (const [e, value] of map) {
        if (value) {
          e.__shadydom_connectedCallback();
        } else {
          e.__shadydom_disconnectedCallback();
        }
      }
    };
    if (isRendering) {
      document.addEventListener("readystatechange", () => {
        isRendering = false;
        rootRendered();
      }, {once:true});
    }
    const ManageConnect = (base, connected, disconnected) => {
      let counter = 0;
      const connectFlag = `__isConnected${counter++}`;
      if (connected || disconnected) {
        base.prototype.connectedCallback = base.prototype.__shadydom_connectedCallback = function() {
          if (isRendering) {
            connectMap.set(this, true);
          } else {
            if (!this[connectFlag]) {
              this[connectFlag] = true;
              if (connected) {
                connected.call(this);
              }
            }
          }
        };
        base.prototype.disconnectedCallback = base.prototype.__shadydom_disconnectedCallback = function() {
          if (isRendering) {
            if (!this.isConnected) {
              connectMap.set(this, false);
            }
          } else {
            if (this[connectFlag]) {
              this[connectFlag] = false;
              if (disconnected) {
                disconnected.call(this);
              }
            }
          }
        };
      }
      return base;
    };
    const define = window["customElements"]["define"];
    Object.defineProperty(window["CustomElementRegistry"].prototype, "define", {value:function(name, constructor) {
      const connected = constructor.prototype.connectedCallback;
      const disconnected = constructor.prototype.disconnectedCallback;
      define.call(window["customElements"], name, ManageConnect(constructor, connected, disconnected));
      constructor.prototype.connectedCallback = connected;
      constructor.prototype.disconnectedCallback = disconnected;
    }});
  }
}, "node_modules/@webcomponents/shadydom/src/attach-shadow.js", ["node_modules/@webcomponents/shadydom/src/array-splice.js", "node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/flush.js", "node_modules/@webcomponents/shadydom/src/logical-tree.js", "node_modules/@webcomponents/shadydom/src/native-methods.js", "node_modules/@webcomponents/shadydom/src/native-tree.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/patch-builtins.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {patchBuiltins:{enumerable:true, get:function() {
    return patchBuiltins;
  }}});
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var module$node_modules$$webcomponents$shadydom$src$flush = $$require("node_modules/@webcomponents/shadydom/src/flush.js");
  var module$node_modules$$webcomponents$shadydom$src$native_methods = $$require("node_modules/@webcomponents/shadydom/src/native-methods.js");
  var mutation = $$require("node_modules/@webcomponents/shadydom/src/logical-mutation.js");
  var module$node_modules$$webcomponents$shadydom$src$patch_accessors = $$require("node_modules/@webcomponents/shadydom/src/patch-accessors.js");
  var module$node_modules$$webcomponents$shadydom$src$patch_events = $$require("node_modules/@webcomponents/shadydom/src/patch-events.js");
  var module$node_modules$$webcomponents$shadydom$src$attach_shadow = $$require("node_modules/@webcomponents/shadydom/src/attach-shadow.js");
  var module$node_modules$$webcomponents$shadydom$src$shady_data = $$require("node_modules/@webcomponents/shadydom/src/shady-data.js");
  function getAssignedSlot(node) {
    mutation.renderRootNode(node);
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(node);
    return nodeData && nodeData.assignedSlot || null;
  }
  let windowMixin = {addEventListener:module$node_modules$$webcomponents$shadydom$src$patch_events.addEventListener.bind(window), removeEventListener:module$node_modules$$webcomponents$shadydom$src$patch_events.removeEventListener.bind(window)};
  let nodeMixin = {addEventListener:module$node_modules$$webcomponents$shadydom$src$patch_events.addEventListener, removeEventListener:module$node_modules$$webcomponents$shadydom$src$patch_events.removeEventListener, appendChild(node) {
    return mutation.insertBefore(this, node);
  }, insertBefore(node, ref_node) {
    return mutation.insertBefore(this, node, ref_node);
  }, removeChild(node) {
    return mutation.removeChild(this, node);
  }, replaceChild(node, ref_node) {
    mutation.insertBefore(this, node, ref_node);
    mutation.removeChild(this, ref_node);
    return node;
  }, cloneNode(deep) {
    return mutation.cloneNode(this, deep);
  }, getRootNode(options) {
    return mutation.getRootNode(this, options);
  }, contains(node) {
    return utils.contains(this, node);
  }, dispatchEvent(event) {
    (0,module$node_modules$$webcomponents$shadydom$src$flush.flush)();
    return module$node_modules$$webcomponents$shadydom$src$native_methods.dispatchEvent.call(this, event);
  }};
  Object.defineProperties(nodeMixin, module$node_modules$$webcomponents$shadydom$src$patch_accessors.IsConnectedAccessor);
  let textMixin = {get assignedSlot() {
    return getAssignedSlot(this);
  }};
  let fragmentMixin = {querySelector(selector) {
    let result = mutation.query(this, function(n) {
      return utils.matchesSelector(n, selector);
    }, function(n) {
      return Boolean(n);
    })[0];
    return result || null;
  }, querySelectorAll(selector, useNative) {
    if (useNative) {
      const o = Array.prototype.slice.call(module$node_modules$$webcomponents$shadydom$src$native_methods.querySelectorAll.call(this, selector));
      const root = this.getRootNode();
      return o.filter((e) => e.getRootNode() == root);
    }
    return mutation.query(this, function(n) {
      return utils.matchesSelector(n, selector);
    });
  }};
  let slotMixin = {assignedNodes(options) {
    if (this.localName === "slot") {
      mutation.renderRootNode(this);
      const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
      return nodeData ? (options && options.flatten ? nodeData.flattenedNodes : nodeData.assignedNodes) || [] : [];
    }
  }};
  let elementMixin = utils.extendAll({setAttribute(name, value) {
    mutation.setAttribute(this, name, value);
  }, removeAttribute(name) {
    mutation.removeAttribute(this, name);
  }, attachShadow(options) {
    return (0,module$node_modules$$webcomponents$shadydom$src$attach_shadow.attachShadow)(this, options);
  }, get slot() {
    return this.getAttribute("slot");
  }, set slot(value) {
    mutation.setAttribute(this, "slot", value);
  }, get assignedSlot() {
    return getAssignedSlot(this);
  }}, fragmentMixin, slotMixin);
  Object.defineProperties(elementMixin, module$node_modules$$webcomponents$shadydom$src$patch_accessors.ShadowRootAccessor);
  let documentMixin = utils.extendAll({importNode(node, deep) {
    return mutation.importNode(node, deep);
  }, getElementById(id) {
    let result = mutation.query(this, function(n) {
      return n.id == id;
    }, function(n) {
      return Boolean(n);
    })[0];
    return result || null;
  }}, fragmentMixin);
  Object.defineProperties(documentMixin, {"_activeElement":module$node_modules$$webcomponents$shadydom$src$patch_accessors.ActiveElementAccessor.activeElement});
  let nativeBlur = HTMLElement.prototype.blur;
  let htmlElementMixin = {blur() {
    const nodeData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
    let root = nodeData && nodeData.root;
    let shadowActive = root && root.activeElement;
    if (shadowActive) {
      shadowActive.blur();
    } else {
      nativeBlur.call(this);
    }
  }};
  for (const property of Object.getOwnPropertyNames(Document.prototype)) {
    if (property.substring(0, 2) === "on") {
      Object.defineProperty(htmlElementMixin, property, {set:function(fn) {
        const shadyData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.ensureShadyDataForNode)(this);
        const eventName = property.substring(2);
        shadyData.__onCallbackListeners[property] && this.removeEventListener(eventName, shadyData.__onCallbackListeners[property]);
        this.addEventListener(eventName, fn, {});
        shadyData.__onCallbackListeners[property] = fn;
      }, get() {
        const shadyData = (0,module$node_modules$$webcomponents$shadydom$src$shady_data.shadyDataForNode)(this);
        return shadyData && shadyData.__onCallbackListeners[property];
      }, configurable:true});
    }
  }
  const shadowRootMixin = {addEventListener(type, fn, optionsOrCapture) {
    if (typeof optionsOrCapture !== "object") {
      optionsOrCapture = {capture:Boolean(optionsOrCapture)};
    }
    optionsOrCapture.__shadyTarget = this;
    this.host.addEventListener(type, fn, optionsOrCapture);
  }, removeEventListener(type, fn, optionsOrCapture) {
    if (typeof optionsOrCapture !== "object") {
      optionsOrCapture = {capture:Boolean(optionsOrCapture)};
    }
    optionsOrCapture.__shadyTarget = this;
    this.host.removeEventListener(type, fn, optionsOrCapture);
  }, getElementById(id) {
    let result = mutation.query(this, function(n) {
      return n.id == id;
    }, function(n) {
      return Boolean(n);
    })[0];
    return result || null;
  }};
  function patchBuiltin(proto, obj) {
    let n$ = Object.getOwnPropertyNames(obj);
    for (let i = 0; i < n$.length; i++) {
      let n = n$[i];
      let d = Object.getOwnPropertyDescriptor(obj, n);
      if (d.value) {
        proto[n] = d.value;
      } else {
        Object.defineProperty(proto, n, d);
      }
    }
  }
  function patchBuiltins() {
    let nativeHTMLElement = window["customElements"] && window["customElements"]["nativeHTMLElement"] || HTMLElement;
    patchBuiltin(module$node_modules$$webcomponents$shadydom$src$attach_shadow.ShadyRoot.prototype, shadowRootMixin);
    patchBuiltin(window.Node.prototype, nodeMixin);
    patchBuiltin(window.Window.prototype, windowMixin);
    patchBuiltin(window.Text.prototype, textMixin);
    patchBuiltin(window.DocumentFragment.prototype, fragmentMixin);
    patchBuiltin(window.Element.prototype, elementMixin);
    patchBuiltin(window.Document.prototype, documentMixin);
    if (window.HTMLSlotElement) {
      patchBuiltin(window.HTMLSlotElement.prototype, slotMixin);
    }
    patchBuiltin(nativeHTMLElement.prototype, htmlElementMixin);
    if (utils.settings.hasDescriptors) {
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(window.Node.prototype);
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(window.Text.prototype);
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(window.DocumentFragment.prototype);
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(window.Element.prototype);
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(nativeHTMLElement.prototype);
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(window.Document.prototype);
      if (window.HTMLSlotElement) {
        (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchAccessors)(window.HTMLSlotElement.prototype);
      }
    }
    (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchShadowRootAccessors)(module$node_modules$$webcomponents$shadydom$src$attach_shadow.ShadyRoot.prototype);
  }
}, "node_modules/@webcomponents/shadydom/src/patch-builtins.js", ["node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/flush.js", "node_modules/@webcomponents/shadydom/src/native-methods.js", "node_modules/@webcomponents/shadydom/src/logical-mutation.js", "node_modules/@webcomponents/shadydom/src/patch-accessors.js", "node_modules/@webcomponents/shadydom/src/patch-events.js", "node_modules/@webcomponents/shadydom/src/attach-shadow.js", "node_modules/@webcomponents/shadydom/src/shady-data.js"]);

//node_modules/@webcomponents/shadydom/src/shadydom.js
/*

Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  var utils = $$require("node_modules/@webcomponents/shadydom/src/utils.js");
  var module$node_modules$$webcomponents$shadydom$src$flush = $$require("node_modules/@webcomponents/shadydom/src/flush.js");
  var module$node_modules$$webcomponents$shadydom$src$observe_changes = $$require("node_modules/@webcomponents/shadydom/src/observe-changes.js");
  var nativeMethods = $$require("node_modules/@webcomponents/shadydom/src/native-methods.js");
  var module$node_modules$$webcomponents$shadydom$src$native_tree = $$require("node_modules/@webcomponents/shadydom/src/native-tree.js");
  var module$node_modules$$webcomponents$shadydom$src$patch_builtins = $$require("node_modules/@webcomponents/shadydom/src/patch-builtins.js");
  var module$node_modules$$webcomponents$shadydom$src$patch_accessors = $$require("node_modules/@webcomponents/shadydom/src/patch-accessors.js");
  var module$node_modules$$webcomponents$shadydom$src$patch_events = $$require("node_modules/@webcomponents/shadydom/src/patch-events.js");
  var module$node_modules$$webcomponents$shadydom$src$attach_shadow = $$require("node_modules/@webcomponents/shadydom/src/attach-shadow.js");
  if (utils.settings.inUse) {
    let ShadyDOM = {"inUse":utils.settings.inUse, "patch":(node) => {
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchInsideElementAccessors)(node);
      (0,module$node_modules$$webcomponents$shadydom$src$patch_accessors.patchOutsideElementAccessors)(node);
      return node;
    }, "isShadyRoot":utils.isShadyRoot, "enqueue":module$node_modules$$webcomponents$shadydom$src$flush.enqueue, "flush":module$node_modules$$webcomponents$shadydom$src$flush.flush, "settings":utils.settings, "filterMutations":module$node_modules$$webcomponents$shadydom$src$observe_changes.filterMutations, "observeChildren":module$node_modules$$webcomponents$shadydom$src$observe_changes.observeChildren, "unobserveChildren":module$node_modules$$webcomponents$shadydom$src$observe_changes.unobserveChildren, 
    "nativeMethods":nativeMethods, "nativeTree":module$node_modules$$webcomponents$shadydom$src$native_tree.accessors, "deferConnectionCallbacks":utils.settings["deferConnectionCallbacks"], "handlesDynamicScoping":true};
    window["ShadyDOM"] = ShadyDOM;
    (0,module$node_modules$$webcomponents$shadydom$src$patch_events.patchEvents)();
    (0,module$node_modules$$webcomponents$shadydom$src$patch_builtins.patchBuiltins)();
    window.ShadowRoot = module$node_modules$$webcomponents$shadydom$src$attach_shadow.ShadyRoot;
  }
}, "node_modules/@webcomponents/shadydom/src/shadydom.js", ["node_modules/@webcomponents/shadydom/src/utils.js", "node_modules/@webcomponents/shadydom/src/flush.js", "node_modules/@webcomponents/shadydom/src/observe-changes.js", "node_modules/@webcomponents/shadydom/src/native-methods.js", "node_modules/@webcomponents/shadydom/src/native-tree.js", "node_modules/@webcomponents/shadydom/src/patch-builtins.js", "node_modules/@webcomponents/shadydom/src/patch-accessors.js", "node_modules/@webcomponents/shadydom/src/patch-events.js", 
"node_modules/@webcomponents/shadydom/src/attach-shadow.js"]);

//node_modules/@webcomponents/custom-elements/src/Utilities.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {isConnected:{enumerable:true, get:function() {
    return isConnected;
  }}, isValidCustomElementName:{enumerable:true, get:function() {
    return isValidCustomElementName;
  }}, setPropertyUnchecked:{enumerable:true, get:function() {
    return setPropertyUnchecked;
  }}, walkDeepDescendantElements:{enumerable:true, get:function() {
    return walkDeepDescendantElements;
  }}});
  const reservedTagList = new Set(["annotation-xml", "color-profile", "font-face", "font-face-src", "font-face-uri", "font-face-format", "font-face-name", "missing-glyph"]);
  function isValidCustomElementName(localName) {
    const reserved = reservedTagList.has(localName);
    const validForm = /^[a-z][.0-9_a-z]*-[\-.0-9_a-z]*$/.test(localName);
    return !reserved && validForm;
  }
  function isConnected(node) {
    const nativeValue = node.isConnected;
    if (nativeValue !== undefined) {
      return nativeValue;
    }
    let current = node;
    while (current && !(current.__CE_isImportDocument || current instanceof Document)) {
      current = current.parentNode || (window.ShadowRoot && current instanceof ShadowRoot ? current.host : undefined);
    }
    return !!(current && (current.__CE_isImportDocument || current instanceof Document));
  }
  function nextSiblingOrAncestorSibling(root, start) {
    let node = start;
    while (node && node !== root && !node.nextSibling) {
      node = node.parentNode;
    }
    return !node || node === root ? null : node.nextSibling;
  }
  function nextNode(root, start) {
    return start.firstChild ? start.firstChild : nextSiblingOrAncestorSibling(root, start);
  }
  function walkDeepDescendantElements(root, callback, visitedImports = new Set) {
    let node = root;
    while (node) {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const element = node;
        callback(element);
        const localName = element.localName;
        if (localName === "link" && element.getAttribute("rel") === "import") {
          const importNode = element["import"];
          if (importNode instanceof Node && !visitedImports.has(importNode)) {
            visitedImports.add(importNode);
            for (let child = importNode.firstChild; child; child = child.nextSibling) {
              walkDeepDescendantElements(child, callback, visitedImports);
            }
          }
          node = nextSiblingOrAncestorSibling(root, element);
          continue;
        } else {
          if (localName === "template") {
            node = nextSiblingOrAncestorSibling(root, element);
            continue;
          }
        }
        const shadowRoot = element.__CE_shadowRoot;
        if (shadowRoot) {
          for (let child = shadowRoot.firstChild; child; child = child.nextSibling) {
            walkDeepDescendantElements(child, callback, visitedImports);
          }
        }
      }
      node = nextNode(root, node);
    }
  }
  function setPropertyUnchecked(destination, name, value) {
    destination[name] = value;
  }
}, "node_modules/@webcomponents/custom-elements/src/Utilities.js", []);

//node_modules/@webcomponents/custom-elements/src/CustomElementState.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  const CustomElementState = {custom:1, failed:2};
  const $$default = CustomElementState;
}, "node_modules/@webcomponents/custom-elements/src/CustomElementState.js", []);

//node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return CustomElementInternals;
  }}});
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementState = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementState.js");
  class CustomElementInternals {
    constructor() {
      this._localNameToDefinition = new Map;
      this._constructorToDefinition = new Map;
      this._patches = [];
      this._hasPatches = false;
    }
    setDefinition(localName, definition) {
      this._localNameToDefinition.set(localName, definition);
      this._constructorToDefinition.set(definition.constructor, definition);
    }
    localNameToDefinition(localName) {
      return this._localNameToDefinition.get(localName);
    }
    constructorToDefinition(constructor) {
      return this._constructorToDefinition.get(constructor);
    }
    addPatch(listener) {
      this._hasPatches = true;
      this._patches.push(listener);
    }
    patchTree(node) {
      if (!this._hasPatches) {
        return;
      }
      Utilities.walkDeepDescendantElements(node, (element) => this.patch(element));
    }
    patch(node) {
      if (!this._hasPatches) {
        return;
      }
      if (node.__CE_patched) {
        return;
      }
      node.__CE_patched = true;
      for (let i = 0; i < this._patches.length; i++) {
        this._patches[i](node);
      }
    }
    connectTree(root) {
      const elements = [];
      Utilities.walkDeepDescendantElements(root, (element) => elements.push(element));
      for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        if (element.__CE_state === module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
          this.connectedCallback(element);
        } else {
          this.upgradeElement(element);
        }
      }
    }
    disconnectTree(root) {
      const elements = [];
      Utilities.walkDeepDescendantElements(root, (element) => elements.push(element));
      for (let i = 0; i < elements.length; i++) {
        const element = elements[i];
        if (element.__CE_state === module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
          this.disconnectedCallback(element);
        }
      }
    }
    patchAndUpgradeTree(root, options = {}) {
      const visitedImports = options.visitedImports || new Set;
      const upgrade = options.upgrade || ((element) => this.upgradeElement(element));
      const elements = [];
      const gatherElements = (element) => {
        if (element.localName === "link" && element.getAttribute("rel") === "import") {
          const importNode = element["import"];
          if (importNode instanceof Node) {
            importNode.__CE_isImportDocument = true;
            importNode.__CE_hasRegistry = true;
          }
          if (importNode && importNode.readyState === "complete") {
            importNode.__CE_documentLoadHandled = true;
          } else {
            element.addEventListener("load", () => {
              const importNode = element["import"];
              if (importNode.__CE_documentLoadHandled) {
                return;
              }
              importNode.__CE_documentLoadHandled = true;
              const clonedVisitedImports = new Set(visitedImports);
              clonedVisitedImports["delete"](importNode);
              this.patchAndUpgradeTree(importNode, {visitedImports:clonedVisitedImports, upgrade});
            });
          }
        } else {
          elements.push(element);
        }
      };
      Utilities.walkDeepDescendantElements(root, gatherElements, visitedImports);
      if (this._hasPatches) {
        for (let i = 0; i < elements.length; i++) {
          this.patch(elements[i]);
        }
      }
      for (let i = 0; i < elements.length; i++) {
        upgrade(elements[i]);
      }
    }
    upgradeElement(element) {
      const currentState = element.__CE_state;
      if (currentState !== undefined) {
        return;
      }
      const ownerDocument = element.ownerDocument;
      if (!ownerDocument.defaultView && !(ownerDocument.__CE_isImportDocument && ownerDocument.__CE_hasRegistry)) {
        return;
      }
      const definition = this.localNameToDefinition(element.localName);
      if (!definition) {
        return;
      }
      definition.constructionStack.push(element);
      const constructor = definition.constructor;
      try {
        try {
          let result = new constructor;
          if (result !== element) {
            throw new Error("The custom element constructor did not produce the element being upgraded.");
          }
        } finally {
          definition.constructionStack.pop();
        }
      } catch (e) {
        element.__CE_state = module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].failed;
        throw e;
      }
      element.__CE_state = module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom;
      element.__CE_definition = definition;
      if (definition.attributeChangedCallback) {
        const observedAttributes = definition.observedAttributes;
        for (let i = 0; i < observedAttributes.length; i++) {
          const name = observedAttributes[i];
          const value = element.getAttribute(name);
          if (value !== null) {
            this.attributeChangedCallback(element, name, null, value, null);
          }
        }
      }
      if (Utilities.isConnected(element)) {
        this.connectedCallback(element);
      }
    }
    connectedCallback(element) {
      const definition = element.__CE_definition;
      if (definition.connectedCallback) {
        definition.connectedCallback.call(element);
      }
    }
    disconnectedCallback(element) {
      const definition = element.__CE_definition;
      if (definition.disconnectedCallback) {
        definition.disconnectedCallback.call(element);
      }
    }
    attributeChangedCallback(element, name, oldValue, newValue, namespace) {
      const definition = element.__CE_definition;
      if (definition.attributeChangedCallback && definition.observedAttributes.indexOf(name) > -1) {
        definition.attributeChangedCallback.call(element, name, oldValue, newValue, namespace);
      }
    }
  }
}, "node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", ["node_modules/@webcomponents/custom-elements/src/Utilities.js", "node_modules/@webcomponents/custom-elements/src/CustomElementState.js"]);

//node_modules/@webcomponents/custom-elements/src/DocumentConstructionObserver.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return DocumentConstructionObserver;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  class DocumentConstructionObserver {
    constructor(internals, doc) {
      this._internals = internals;
      this._document = doc;
      this._observer = undefined;
      this._internals.patchAndUpgradeTree(this._document);
      if (this._document.readyState === "loading") {
        this._observer = new MutationObserver(this._handleMutations.bind(this));
        this._observer.observe(this._document, {childList:true, subtree:true});
      }
    }
    disconnect() {
      if (this._observer) {
        this._observer.disconnect();
      }
    }
    _handleMutations(mutations) {
      const readyState = this._document.readyState;
      if (readyState === "interactive" || readyState === "complete") {
        this.disconnect();
      }
      for (let i = 0; i < mutations.length; i++) {
        const addedNodes = mutations[i].addedNodes;
        for (let j = 0; j < addedNodes.length; j++) {
          const node = addedNodes[j];
          this._internals.patchAndUpgradeTree(node);
        }
      }
    }
  }
}, "node_modules/@webcomponents/custom-elements/src/DocumentConstructionObserver.js", ["node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js"]);

//node_modules/@webcomponents/custom-elements/src/Deferred.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return Deferred;
  }}});
  class Deferred {
    constructor() {
      this._value = undefined;
      this._resolve = undefined;
      this._promise = new Promise((resolve) => {
        this._resolve = resolve;
        if (this._value) {
          resolve(this._value);
        }
      });
    }
    resolve(value) {
      if (this._value) {
        throw new Error("Already resolved.");
      }
      this._value = value;
      if (this._resolve) {
        this._resolve(value);
      }
    }
    toPromise() {
      return this._promise;
    }
  }
}, "node_modules/@webcomponents/custom-elements/src/Deferred.js", []);

//node_modules/@webcomponents/custom-elements/src/CustomElementRegistry.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return CustomElementRegistry;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var module$node_modules$$webcomponents$custom_elements$src$DocumentConstructionObserver = $$require("node_modules/@webcomponents/custom-elements/src/DocumentConstructionObserver.js");
  var module$node_modules$$webcomponents$custom_elements$src$Deferred = $$require("node_modules/@webcomponents/custom-elements/src/Deferred.js");
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  class CustomElementRegistry {
    constructor(internals) {
      this._elementDefinitionIsRunning = false;
      this._internals = internals;
      this._whenDefinedDeferred = new Map;
      this._flushCallback = (fn) => fn();
      this._flushPending = false;
      this._pendingDefinitions = [];
      this._documentConstructionObserver = new module$node_modules$$webcomponents$custom_elements$src$DocumentConstructionObserver["default"](internals, document);
    }
    define(localName, constructor) {
      if (!(constructor instanceof Function)) {
        throw new TypeError("Custom element constructors must be functions.");
      }
      if (!Utilities.isValidCustomElementName(localName)) {
        throw new SyntaxError(`The element name '${localName}' is not valid.`);
      }
      if (this._internals.localNameToDefinition(localName)) {
        throw new Error(`A custom element with name '${localName}' has already been defined.`);
      }
      if (this._elementDefinitionIsRunning) {
        throw new Error("A custom element is already being defined.");
      }
      this._elementDefinitionIsRunning = true;
      let connectedCallback;
      let disconnectedCallback;
      let adoptedCallback;
      let attributeChangedCallback;
      let observedAttributes;
      try {
        const prototype = constructor.prototype;
        if (!(prototype instanceof Object)) {
          throw new TypeError("The custom element constructor's prototype is not an object.");
        }
        function getCallback(name) {
          const callbackValue = prototype[name];
          if (callbackValue !== undefined && !(callbackValue instanceof Function)) {
            throw new Error(`The '${name}' callback must be a function.`);
          }
          return callbackValue;
        }
        connectedCallback = getCallback("connectedCallback");
        disconnectedCallback = getCallback("disconnectedCallback");
        adoptedCallback = getCallback("adoptedCallback");
        attributeChangedCallback = getCallback("attributeChangedCallback");
        observedAttributes = constructor["observedAttributes"] || [];
      } catch (e) {
        return;
      } finally {
        this._elementDefinitionIsRunning = false;
      }
      const definition = {localName, constructor, connectedCallback, disconnectedCallback, adoptedCallback, attributeChangedCallback, observedAttributes, constructionStack:[]};
      this._internals.setDefinition(localName, definition);
      this._pendingDefinitions.push(definition);
      if (!this._flushPending) {
        this._flushPending = true;
        this._flushCallback(() => this._flush());
      }
    }
    upgrade(element) {
      this._internals.patchAndUpgradeTree(element);
    }
    _flush() {
      if (this._flushPending === false) {
        return;
      }
      this._flushPending = false;
      const pendingDefinitions = this._pendingDefinitions;
      const elementsWithStableDefinitions = [];
      const elementsWithPendingDefinitions = new Map;
      for (let i = 0; i < pendingDefinitions.length; i++) {
        elementsWithPendingDefinitions.set(pendingDefinitions[i].localName, []);
      }
      this._internals.patchAndUpgradeTree(document, {upgrade:(element) => {
        if (element.__CE_state !== undefined) {
          return;
        }
        const localName = element.localName;
        const pendingElements = elementsWithPendingDefinitions.get(localName);
        if (pendingElements) {
          pendingElements.push(element);
        } else {
          if (this._internals.localNameToDefinition(localName)) {
            elementsWithStableDefinitions.push(element);
          }
        }
      }});
      for (let i = 0; i < elementsWithStableDefinitions.length; i++) {
        this._internals.upgradeElement(elementsWithStableDefinitions[i]);
      }
      while (pendingDefinitions.length > 0) {
        const definition = pendingDefinitions.shift();
        const localName = definition.localName;
        const pendingUpgradableElements = elementsWithPendingDefinitions.get(definition.localName);
        for (let i = 0; i < pendingUpgradableElements.length; i++) {
          this._internals.upgradeElement(pendingUpgradableElements[i]);
        }
        const deferred = this._whenDefinedDeferred.get(localName);
        if (deferred) {
          deferred.resolve(undefined);
        }
      }
    }
    get(localName) {
      const definition = this._internals.localNameToDefinition(localName);
      if (definition) {
        return definition.constructor;
      }
      return undefined;
    }
    whenDefined(localName) {
      if (!Utilities.isValidCustomElementName(localName)) {
        return Promise.reject(new SyntaxError(`'${localName}' is not a valid custom element name.`));
      }
      const prior = this._whenDefinedDeferred.get(localName);
      if (prior) {
        return prior.toPromise();
      }
      const deferred = new module$node_modules$$webcomponents$custom_elements$src$Deferred["default"];
      this._whenDefinedDeferred.set(localName, deferred);
      const definition = this._internals.localNameToDefinition(localName);
      if (definition && !this._pendingDefinitions.some((d) => d.localName === localName)) {
        deferred.resolve(undefined);
      }
      return deferred.toPromise();
    }
    polyfillWrapFlushCallback(outer) {
      this._documentConstructionObserver.disconnect();
      const inner = this._flushCallback;
      this._flushCallback = (flush) => outer(() => inner(flush));
    }
  }
  window["CustomElementRegistry"] = CustomElementRegistry;
  CustomElementRegistry.prototype["define"] = CustomElementRegistry.prototype.define;
  CustomElementRegistry.prototype["upgrade"] = CustomElementRegistry.prototype.upgrade;
  CustomElementRegistry.prototype["get"] = CustomElementRegistry.prototype.get;
  CustomElementRegistry.prototype["whenDefined"] = CustomElementRegistry.prototype.whenDefined;
  CustomElementRegistry.prototype["polyfillWrapFlushCallback"] = CustomElementRegistry.prototype.polyfillWrapFlushCallback;
}, "node_modules/@webcomponents/custom-elements/src/CustomElementRegistry.js", ["node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/DocumentConstructionObserver.js", "node_modules/@webcomponents/custom-elements/src/Deferred.js", "node_modules/@webcomponents/custom-elements/src/Utilities.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/Native.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  const $$default = {Document_createElement:window.Document.prototype.createElement, Document_createElementNS:window.Document.prototype.createElementNS, Document_importNode:window.Document.prototype.importNode, Document_prepend:window.Document.prototype["prepend"], Document_append:window.Document.prototype["append"], DocumentFragment_prepend:window.DocumentFragment.prototype["prepend"], DocumentFragment_append:window.DocumentFragment.prototype["append"], Node_cloneNode:window.Node.prototype.cloneNode, 
  Node_appendChild:window.Node.prototype.appendChild, Node_insertBefore:window.Node.prototype.insertBefore, Node_removeChild:window.Node.prototype.removeChild, Node_replaceChild:window.Node.prototype.replaceChild, Node_textContent:Object.getOwnPropertyDescriptor(window.Node.prototype, "textContent"), Element_attachShadow:window.Element.prototype["attachShadow"], Element_innerHTML:Object.getOwnPropertyDescriptor(window.Element.prototype, "innerHTML"), Element_getAttribute:window.Element.prototype.getAttribute, 
  Element_setAttribute:window.Element.prototype.setAttribute, Element_removeAttribute:window.Element.prototype.removeAttribute, Element_getAttributeNS:window.Element.prototype.getAttributeNS, Element_setAttributeNS:window.Element.prototype.setAttributeNS, Element_removeAttributeNS:window.Element.prototype.removeAttributeNS, Element_insertAdjacentElement:window.Element.prototype["insertAdjacentElement"], Element_insertAdjacentHTML:window.Element.prototype["insertAdjacentHTML"], Element_prepend:window.Element.prototype["prepend"], 
  Element_append:window.Element.prototype["append"], Element_before:window.Element.prototype["before"], Element_after:window.Element.prototype["after"], Element_replaceWith:window.Element.prototype["replaceWith"], Element_remove:window.Element.prototype["remove"], HTMLElement:window.HTMLElement, HTMLElement_innerHTML:Object.getOwnPropertyDescriptor(window.HTMLElement.prototype, "innerHTML"), HTMLElement_insertAdjacentElement:window.HTMLElement.prototype["insertAdjacentElement"], HTMLElement_insertAdjacentHTML:window.HTMLElement.prototype["insertAdjacentHTML"]};
}, "node_modules/@webcomponents/custom-elements/src/Patch/Native.js", []);

//node_modules/@webcomponents/custom-elements/src/AlreadyConstructedMarker.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  class AlreadyConstructedMarker {
  }
  const $$default = new AlreadyConstructedMarker;
}, "node_modules/@webcomponents/custom-elements/src/AlreadyConstructedMarker.js", []);

//node_modules/@webcomponents/custom-elements/src/Patch/HTMLElement.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Native = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Native.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementState = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementState.js");
  var module$node_modules$$webcomponents$custom_elements$src$AlreadyConstructedMarker = $$require("node_modules/@webcomponents/custom-elements/src/AlreadyConstructedMarker.js");
  const $$default = function(internals) {
    window["HTMLElement"] = function() {
      function HTMLElement() {
        const constructor = this.constructor;
        const definition = internals.constructorToDefinition(constructor);
        if (!definition) {
          throw new Error("The custom element being constructed was not registered with `customElements`.");
        }
        const constructionStack = definition.constructionStack;
        if (constructionStack.length === 0) {
          const element = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_createElement.call(document, definition.localName);
          Object.setPrototypeOf(element, constructor.prototype);
          element.__CE_state = module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom;
          element.__CE_definition = definition;
          internals.patch(element);
          return element;
        }
        const lastIndex = constructionStack.length - 1;
        const element = constructionStack[lastIndex];
        if (element === module$node_modules$$webcomponents$custom_elements$src$AlreadyConstructedMarker["default"]) {
          throw new Error("The HTMLElement constructor was either called reentrantly for this constructor or called multiple times.");
        }
        constructionStack[lastIndex] = module$node_modules$$webcomponents$custom_elements$src$AlreadyConstructedMarker["default"];
        Object.setPrototypeOf(element, constructor.prototype);
        internals.patch(element);
        return element;
      }
      HTMLElement.prototype = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement.prototype;
      Object.defineProperty(HTMLElement.prototype, "constructor", {writable:true, configurable:true, enumerable:false, value:HTMLElement});
      return HTMLElement;
    }();
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/HTMLElement.js", ["node_modules/@webcomponents/custom-elements/src/Patch/Native.js", "node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/CustomElementState.js", "node_modules/@webcomponents/custom-elements/src/AlreadyConstructedMarker.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  let ParentNodeNativeMethods;
  const $$default = function(internals, destination, builtIn) {
    function appendPrependPatch(builtInMethod) {
      return function(...nodes) {
        const flattenedNodes = [];
        const connectedElements = [];
        for (var i = 0; i < nodes.length; i++) {
          const node = nodes[i];
          if (node instanceof Element && Utilities.isConnected(node)) {
            connectedElements.push(node);
          }
          if (node instanceof DocumentFragment) {
            for (let child = node.firstChild; child; child = child.nextSibling) {
              flattenedNodes.push(child);
            }
          } else {
            flattenedNodes.push(node);
          }
        }
        builtInMethod.apply(this, nodes);
        for (let i = 0; i < connectedElements.length; i++) {
          internals.disconnectTree(connectedElements[i]);
        }
        if (Utilities.isConnected(this)) {
          for (let i = 0; i < flattenedNodes.length; i++) {
            const node = flattenedNodes[i];
            if (node instanceof Element) {
              internals.connectTree(node);
            }
          }
        }
      };
    }
    if (builtIn.prepend !== undefined) {
      Utilities.setPropertyUnchecked(destination, "prepend", appendPrependPatch(builtIn.prepend));
    }
    if (builtIn.append !== undefined) {
      Utilities.setPropertyUnchecked(destination, "append", appendPrependPatch(builtIn.append));
    }
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js", ["node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/Utilities.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/Document.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Native = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Native.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ParentNode = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js");
  const $$default = function(internals) {
    Utilities.setPropertyUnchecked(Document.prototype, "createElement", function(localName) {
      if (this.__CE_hasRegistry) {
        const definition = internals.localNameToDefinition(localName);
        if (definition) {
          return new definition.constructor;
        }
      }
      const result = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_createElement.call(this, localName);
      internals.patch(result);
      return result;
    });
    Utilities.setPropertyUnchecked(Document.prototype, "importNode", function(node, deep) {
      const clone = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_importNode.call(this, node, deep);
      if (!this.__CE_hasRegistry) {
        internals.patchTree(clone);
      } else {
        internals.patchAndUpgradeTree(clone);
      }
      return clone;
    });
    const NS_HTML = "http://www.w3.org/1999/xhtml";
    Utilities.setPropertyUnchecked(Document.prototype, "createElementNS", function(namespace, localName) {
      if (this.__CE_hasRegistry && (namespace === null || namespace === NS_HTML)) {
        const definition = internals.localNameToDefinition(localName);
        if (definition) {
          return new definition.constructor;
        }
      }
      const result = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_createElementNS.call(this, namespace, localName);
      internals.patch(result);
      return result;
    });
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ParentNode["default"])(internals, Document.prototype, {prepend:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_prepend, append:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_append});
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/Document.js", ["node_modules/@webcomponents/custom-elements/src/Patch/Native.js", "node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/Utilities.js", "node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/DocumentFragment.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Native = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Native.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ParentNode = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js");
  const $$default = function(internals) {
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ParentNode["default"])(internals, DocumentFragment.prototype, {prepend:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].DocumentFragment_prepend, append:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].DocumentFragment_append});
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/DocumentFragment.js", ["node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/Patch/Native.js", "node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/Node.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Native = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Native.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  const $$default = function(internals) {
    Utilities.setPropertyUnchecked(Node.prototype, "insertBefore", function(node, refNode) {
      if (node instanceof DocumentFragment) {
        const insertedNodes = Array.prototype.slice.apply(node.childNodes);
        const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_insertBefore.call(this, node, refNode);
        if (Utilities.isConnected(this)) {
          for (let i = 0; i < insertedNodes.length; i++) {
            internals.connectTree(insertedNodes[i]);
          }
        }
        return nativeResult;
      }
      const nodeWasConnected = Utilities.isConnected(node);
      const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_insertBefore.call(this, node, refNode);
      if (nodeWasConnected) {
        internals.disconnectTree(node);
      }
      if (Utilities.isConnected(this)) {
        internals.connectTree(node);
      }
      return nativeResult;
    });
    Utilities.setPropertyUnchecked(Node.prototype, "appendChild", function(node) {
      if (node instanceof DocumentFragment) {
        const insertedNodes = Array.prototype.slice.apply(node.childNodes);
        const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_appendChild.call(this, node);
        if (Utilities.isConnected(this)) {
          for (let i = 0; i < insertedNodes.length; i++) {
            internals.connectTree(insertedNodes[i]);
          }
        }
        return nativeResult;
      }
      const nodeWasConnected = Utilities.isConnected(node);
      const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_appendChild.call(this, node);
      if (nodeWasConnected) {
        internals.disconnectTree(node);
      }
      if (Utilities.isConnected(this)) {
        internals.connectTree(node);
      }
      return nativeResult;
    });
    Utilities.setPropertyUnchecked(Node.prototype, "cloneNode", function(deep) {
      const clone = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_cloneNode.call(this, deep);
      if (!this.ownerDocument.__CE_hasRegistry) {
        internals.patchTree(clone);
      } else {
        internals.patchAndUpgradeTree(clone);
      }
      return clone;
    });
    Utilities.setPropertyUnchecked(Node.prototype, "removeChild", function(node) {
      const nodeWasConnected = Utilities.isConnected(node);
      const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_removeChild.call(this, node);
      if (nodeWasConnected) {
        internals.disconnectTree(node);
      }
      return nativeResult;
    });
    Utilities.setPropertyUnchecked(Node.prototype, "replaceChild", function(nodeToInsert, nodeToRemove) {
      if (nodeToInsert instanceof DocumentFragment) {
        const insertedNodes = Array.prototype.slice.apply(nodeToInsert.childNodes);
        const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_replaceChild.call(this, nodeToInsert, nodeToRemove);
        if (Utilities.isConnected(this)) {
          internals.disconnectTree(nodeToRemove);
          for (let i = 0; i < insertedNodes.length; i++) {
            internals.connectTree(insertedNodes[i]);
          }
        }
        return nativeResult;
      }
      const nodeToInsertWasConnected = Utilities.isConnected(nodeToInsert);
      const nativeResult = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_replaceChild.call(this, nodeToInsert, nodeToRemove);
      const thisIsConnected = Utilities.isConnected(this);
      if (thisIsConnected) {
        internals.disconnectTree(nodeToRemove);
      }
      if (nodeToInsertWasConnected) {
        internals.disconnectTree(nodeToInsert);
      }
      if (thisIsConnected) {
        internals.connectTree(nodeToInsert);
      }
      return nativeResult;
    });
    function patch_textContent(destination, baseDescriptor) {
      Object.defineProperty(destination, "textContent", {enumerable:baseDescriptor.enumerable, configurable:true, get:baseDescriptor.get, set:function(assignedValue) {
        if (this.nodeType === Node.TEXT_NODE) {
          baseDescriptor.set.call(this, assignedValue);
          return;
        }
        let removedNodes = undefined;
        if (this.firstChild) {
          const childNodes = this.childNodes;
          const childNodesLength = childNodes.length;
          if (childNodesLength > 0 && Utilities.isConnected(this)) {
            removedNodes = new Array(childNodesLength);
            for (let i = 0; i < childNodesLength; i++) {
              removedNodes[i] = childNodes[i];
            }
          }
        }
        baseDescriptor.set.call(this, assignedValue);
        if (removedNodes) {
          for (let i = 0; i < removedNodes.length; i++) {
            internals.disconnectTree(removedNodes[i]);
          }
        }
      }});
    }
    if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_textContent && module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_textContent.get) {
      patch_textContent(Node.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_textContent);
    } else {
      internals.addPatch(function(element) {
        patch_textContent(element, {enumerable:true, configurable:true, get:function() {
          const parts = [];
          for (let i = 0; i < this.childNodes.length; i++) {
            parts.push(this.childNodes[i].textContent);
          }
          return parts.join("");
        }, set:function(assignedValue) {
          while (this.firstChild) {
            module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_removeChild.call(this, this.firstChild);
          }
          module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_appendChild.call(this, document.createTextNode(assignedValue));
        }});
      });
    }
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/Node.js", ["node_modules/@webcomponents/custom-elements/src/Patch/Native.js", "node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/Utilities.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/Interface/ChildNode.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  let ChildNodeNativeMethods;
  const $$default = function(internals, destination, builtIn) {
    function beforeAfterPatch(builtInMethod) {
      return function(...nodes) {
        const flattenedNodes = [];
        const connectedElements = [];
        for (var i = 0; i < nodes.length; i++) {
          const node = nodes[i];
          if (node instanceof Element && Utilities.isConnected(node)) {
            connectedElements.push(node);
          }
          if (node instanceof DocumentFragment) {
            for (let child = node.firstChild; child; child = child.nextSibling) {
              flattenedNodes.push(child);
            }
          } else {
            flattenedNodes.push(node);
          }
        }
        builtInMethod.apply(this, nodes);
        for (let i = 0; i < connectedElements.length; i++) {
          internals.disconnectTree(connectedElements[i]);
        }
        if (Utilities.isConnected(this)) {
          for (let i = 0; i < flattenedNodes.length; i++) {
            const node = flattenedNodes[i];
            if (node instanceof Element) {
              internals.connectTree(node);
            }
          }
        }
      };
    }
    if (builtIn.before !== undefined) {
      Utilities.setPropertyUnchecked(destination, "before", beforeAfterPatch(builtIn.before));
    }
    if (builtIn.before !== undefined) {
      Utilities.setPropertyUnchecked(destination, "after", beforeAfterPatch(builtIn.after));
    }
    if (builtIn.replaceWith !== undefined) {
      Utilities.setPropertyUnchecked(destination, "replaceWith", function(...nodes) {
        const flattenedNodes = [];
        const connectedElements = [];
        for (var i = 0; i < nodes.length; i++) {
          const node = nodes[i];
          if (node instanceof Element && Utilities.isConnected(node)) {
            connectedElements.push(node);
          }
          if (node instanceof DocumentFragment) {
            for (let child = node.firstChild; child; child = child.nextSibling) {
              flattenedNodes.push(child);
            }
          } else {
            flattenedNodes.push(node);
          }
        }
        const wasConnected = Utilities.isConnected(this);
        builtIn.replaceWith.apply(this, nodes);
        for (let i = 0; i < connectedElements.length; i++) {
          internals.disconnectTree(connectedElements[i]);
        }
        if (wasConnected) {
          internals.disconnectTree(this);
          for (let i = 0; i < flattenedNodes.length; i++) {
            const node = flattenedNodes[i];
            if (node instanceof Element) {
              internals.connectTree(node);
            }
          }
        }
      });
    }
    if (builtIn.remove !== undefined) {
      Utilities.setPropertyUnchecked(destination, "remove", function() {
        const wasConnected = Utilities.isConnected(this);
        builtIn.remove.call(this);
        if (wasConnected) {
          internals.disconnectTree(this);
        }
      });
    }
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/Interface/ChildNode.js", ["node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/Utilities.js"]);

//node_modules/@webcomponents/custom-elements/src/Patch/Element.js
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Native = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Native.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementState = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementState.js");
  var Utilities = $$require("node_modules/@webcomponents/custom-elements/src/Utilities.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ParentNode = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ChildNode = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Interface/ChildNode.js");
  const $$default = function(internals) {
    if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_attachShadow) {
      Utilities.setPropertyUnchecked(Element.prototype, "attachShadow", function(init) {
        const shadowRoot = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_attachShadow.call(this, init);
        this.__CE_shadowRoot = shadowRoot;
        return shadowRoot;
      });
    }
    function patch_innerHTML(destination, baseDescriptor) {
      Object.defineProperty(destination, "innerHTML", {enumerable:baseDescriptor.enumerable, configurable:true, get:baseDescriptor.get, set:function(htmlString) {
        const isConnected = Utilities.isConnected(this);
        let removedElements = undefined;
        if (isConnected) {
          removedElements = [];
          Utilities.walkDeepDescendantElements(this, (element) => {
            if (element !== this) {
              removedElements.push(element);
            }
          });
        }
        baseDescriptor.set.call(this, htmlString);
        if (removedElements) {
          for (let i = 0; i < removedElements.length; i++) {
            const element = removedElements[i];
            if (element.__CE_state === module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
              internals.disconnectedCallback(element);
            }
          }
        }
        if (!this.ownerDocument.__CE_hasRegistry) {
          internals.patchTree(this);
        } else {
          internals.patchAndUpgradeTree(this);
        }
        return htmlString;
      }});
    }
    if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_innerHTML && module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_innerHTML.get) {
      patch_innerHTML(Element.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_innerHTML);
    } else {
      if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_innerHTML && module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_innerHTML.get) {
        patch_innerHTML(HTMLElement.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_innerHTML);
      } else {
        internals.addPatch(function(element) {
          patch_innerHTML(element, {enumerable:true, configurable:true, get:function() {
            return module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_cloneNode.call(this, true).innerHTML;
          }, set:function(assignedValue) {
            const isTemplate = this.localName === "template";
            const content = isTemplate ? this.content : this;
            const rawElement = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Document_createElementNS.call(document, this.namespaceURI, this.localName);
            rawElement.innerHTML = assignedValue;
            while (content.childNodes.length > 0) {
              module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_removeChild.call(content, content.childNodes[0]);
            }
            const container = isTemplate ? rawElement.content : rawElement;
            while (container.childNodes.length > 0) {
              module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Node_appendChild.call(content, container.childNodes[0]);
            }
          }});
        });
      }
    }
    Utilities.setPropertyUnchecked(Element.prototype, "setAttribute", function(name, newValue) {
      if (this.__CE_state !== module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
        return module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_setAttribute.call(this, name, newValue);
      }
      const oldValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttribute.call(this, name);
      module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_setAttribute.call(this, name, newValue);
      newValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttribute.call(this, name);
      internals.attributeChangedCallback(this, name, oldValue, newValue, null);
    });
    Utilities.setPropertyUnchecked(Element.prototype, "setAttributeNS", function(namespace, name, newValue) {
      if (this.__CE_state !== module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
        return module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_setAttributeNS.call(this, namespace, name, newValue);
      }
      const oldValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttributeNS.call(this, namespace, name);
      module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_setAttributeNS.call(this, namespace, name, newValue);
      newValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttributeNS.call(this, namespace, name);
      internals.attributeChangedCallback(this, name, oldValue, newValue, namespace);
    });
    Utilities.setPropertyUnchecked(Element.prototype, "removeAttribute", function(name) {
      if (this.__CE_state !== module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
        return module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_removeAttribute.call(this, name);
      }
      const oldValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttribute.call(this, name);
      module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_removeAttribute.call(this, name);
      if (oldValue !== null) {
        internals.attributeChangedCallback(this, name, oldValue, null, null);
      }
    });
    Utilities.setPropertyUnchecked(Element.prototype, "removeAttributeNS", function(namespace, name) {
      if (this.__CE_state !== module$node_modules$$webcomponents$custom_elements$src$CustomElementState["default"].custom) {
        return module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_removeAttributeNS.call(this, namespace, name);
      }
      const oldValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttributeNS.call(this, namespace, name);
      module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_removeAttributeNS.call(this, namespace, name);
      const newValue = module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_getAttributeNS.call(this, namespace, name);
      if (oldValue !== newValue) {
        internals.attributeChangedCallback(this, name, oldValue, newValue, namespace);
      }
    });
    function patch_insertAdjacentElement(destination, baseMethod) {
      Utilities.setPropertyUnchecked(destination, "insertAdjacentElement", function(position, element) {
        const wasConnected = Utilities.isConnected(element);
        const insertedElement = baseMethod.call(this, position, element);
        if (wasConnected) {
          internals.disconnectTree(element);
        }
        if (Utilities.isConnected(insertedElement)) {
          internals.connectTree(element);
        }
        return insertedElement;
      });
    }
    if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_insertAdjacentElement) {
      patch_insertAdjacentElement(HTMLElement.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_insertAdjacentElement);
    } else {
      if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_insertAdjacentElement) {
        patch_insertAdjacentElement(Element.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_insertAdjacentElement);
      } else {
        console.warn("Custom Elements: `Element#insertAdjacentElement` was not patched.");
      }
    }
    function patch_insertAdjacentHTML(destination, baseMethod) {
      function upgradeNodesInRange(start, end) {
        const nodes = [];
        for (let node = start; node !== end; node = node.nextSibling) {
          nodes.push(node);
        }
        for (let i = 0; i < nodes.length; i++) {
          internals.patchAndUpgradeTree(nodes[i]);
        }
      }
      Utilities.setPropertyUnchecked(destination, "insertAdjacentHTML", function(position, text) {
        position = position.toLowerCase();
        if (position === "beforebegin") {
          const marker = this.previousSibling;
          baseMethod.call(this, position, text);
          upgradeNodesInRange(marker || this.parentNode.firstChild, this);
        } else {
          if (position === "afterbegin") {
            const marker = this.firstChild;
            baseMethod.call(this, position, text);
            upgradeNodesInRange(this.firstChild, marker);
          } else {
            if (position === "beforeend") {
              const marker = this.lastChild;
              baseMethod.call(this, position, text);
              upgradeNodesInRange(marker || this.firstChild, null);
            } else {
              if (position === "afterend") {
                const marker = this.nextSibling;
                baseMethod.call(this, position, text);
                upgradeNodesInRange(this.nextSibling, marker);
              } else {
                throw new SyntaxError(`The value provided (${String(position)}) is ` + "not one of 'beforebegin', 'afterbegin', 'beforeend', or 'afterend'.");
              }
            }
          }
        }
      });
    }
    if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_insertAdjacentHTML) {
      patch_insertAdjacentHTML(HTMLElement.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].HTMLElement_insertAdjacentHTML);
    } else {
      if (module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_insertAdjacentHTML) {
        patch_insertAdjacentHTML(Element.prototype, module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_insertAdjacentHTML);
      } else {
        console.warn("Custom Elements: `Element#insertAdjacentHTML` was not patched.");
      }
    }
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ParentNode["default"])(internals, Element.prototype, {prepend:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_prepend, append:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_append});
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Interface$ChildNode["default"])(internals, Element.prototype, {before:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_before, after:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_after, replaceWith:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_replaceWith, remove:module$node_modules$$webcomponents$custom_elements$src$Patch$Native["default"].Element_remove});
  };
}, "node_modules/@webcomponents/custom-elements/src/Patch/Element.js", ["node_modules/@webcomponents/custom-elements/src/Patch/Native.js", "node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/CustomElementState.js", "node_modules/@webcomponents/custom-elements/src/Utilities.js", "node_modules/@webcomponents/custom-elements/src/Patch/Interface/ParentNode.js", "node_modules/@webcomponents/custom-elements/src/Patch/Interface/ChildNode.js"]);

//node_modules/@webcomponents/custom-elements/src/custom-elements.js
/*

 Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 Code distributed by Google as part of the polymer project is also
 subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js");
  var module$node_modules$$webcomponents$custom_elements$src$CustomElementRegistry = $$require("node_modules/@webcomponents/custom-elements/src/CustomElementRegistry.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$HTMLElement = $$require("node_modules/@webcomponents/custom-elements/src/Patch/HTMLElement.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Document = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Document.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$DocumentFragment = $$require("node_modules/@webcomponents/custom-elements/src/Patch/DocumentFragment.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Node = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Node.js");
  var module$node_modules$$webcomponents$custom_elements$src$Patch$Element = $$require("node_modules/@webcomponents/custom-elements/src/Patch/Element.js");
  const priorCustomElements = window["customElements"];
  if (!priorCustomElements || priorCustomElements["forcePolyfill"] || typeof priorCustomElements["define"] != "function" || typeof priorCustomElements["get"] != "function") {
    const internals = new module$node_modules$$webcomponents$custom_elements$src$CustomElementInternals["default"];
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$HTMLElement["default"])(internals);
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Document["default"])(internals);
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$DocumentFragment["default"])(internals);
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Node["default"])(internals);
    (0,module$node_modules$$webcomponents$custom_elements$src$Patch$Element["default"])(internals);
    document.__CE_hasRegistry = true;
    const customElements = new module$node_modules$$webcomponents$custom_elements$src$CustomElementRegistry["default"](internals);
    Object.defineProperty(window, "customElements", {configurable:true, enumerable:true, value:customElements});
  }
}, "node_modules/@webcomponents/custom-elements/src/custom-elements.js", ["node_modules/@webcomponents/custom-elements/src/CustomElementInternals.js", "node_modules/@webcomponents/custom-elements/src/CustomElementRegistry.js", "node_modules/@webcomponents/custom-elements/src/Patch/HTMLElement.js", "node_modules/@webcomponents/custom-elements/src/Patch/Document.js", "node_modules/@webcomponents/custom-elements/src/Patch/DocumentFragment.js", "node_modules/@webcomponents/custom-elements/src/Patch/Node.js", 
"node_modules/@webcomponents/custom-elements/src/Patch/Element.js"]);

//node_modules/@webcomponents/shadycss/src/css-parse.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {StyleNode:{enumerable:true, get:function() {
    return StyleNode;
  }}, parse:{enumerable:true, get:function() {
    return parse;
  }}, removeCustomPropAssignment:{enumerable:true, get:function() {
    return removeCustomPropAssignment;
  }}, stringify:{enumerable:true, get:function() {
    return stringify;
  }}, types:{enumerable:true, get:function() {
    return types;
  }}});
  class StyleNode {
    constructor() {
      this["start"] = 0;
      this["end"] = 0;
      this["previous"] = null;
      this["parent"] = null;
      this["rules"] = null;
      this["parsedCssText"] = "";
      this["cssText"] = "";
      this["atRule"] = false;
      this["type"] = 0;
      this["keyframesName"] = "";
      this["selector"] = "";
      this["parsedSelector"] = "";
    }
  }
  function parse(text) {
    text = clean(text);
    return parseCss(lex(text), text);
  }
  function clean(cssText) {
    return cssText.replace(RX.comments, "").replace(RX.port, "");
  }
  function lex(text) {
    let root = new StyleNode;
    root["start"] = 0;
    root["end"] = text.length;
    let n = root;
    for (let i = 0, l = text.length; i < l; i++) {
      if (text[i] === OPEN_BRACE) {
        if (!n["rules"]) {
          n["rules"] = [];
        }
        let p = n;
        let previous = p["rules"][p["rules"].length - 1] || null;
        n = new StyleNode;
        n["start"] = i + 1;
        n["parent"] = p;
        n["previous"] = previous;
        p["rules"].push(n);
      } else {
        if (text[i] === CLOSE_BRACE) {
          n["end"] = i + 1;
          n = n["parent"] || root;
        }
      }
    }
    return root;
  }
  function parseCss(node, text) {
    let t = text.substring(node["start"], node["end"] - 1);
    node["parsedCssText"] = node["cssText"] = t.trim();
    if (node["parent"]) {
      let ss = node["previous"] ? node["previous"]["end"] : node["parent"]["start"];
      t = text.substring(ss, node["start"] - 1);
      t = _expandUnicodeEscapes(t);
      t = t.replace(RX.multipleSpaces, " ");
      t = t.substring(t.lastIndexOf(";") + 1);
      let s = node["parsedSelector"] = node["selector"] = t.trim();
      node["atRule"] = s.indexOf(AT_START) === 0;
      if (node["atRule"]) {
        if (s.indexOf(MEDIA_START) === 0) {
          node["type"] = types.MEDIA_RULE;
        } else {
          if (s.match(RX.keyframesRule)) {
            node["type"] = types.KEYFRAMES_RULE;
            node["keyframesName"] = node["selector"].split(RX.multipleSpaces).pop();
          }
        }
      } else {
        if (s.indexOf(VAR_START) === 0) {
          node["type"] = types.MIXIN_RULE;
        } else {
          node["type"] = types.STYLE_RULE;
        }
      }
    }
    let r$ = node["rules"];
    if (r$) {
      for (let i = 0, l = r$.length, r; i < l && (r = r$[i]); i++) {
        parseCss(r, text);
      }
    }
    return node;
  }
  function _expandUnicodeEscapes(s) {
    return s.replace(/\\([0-9a-f]{1,6})\s/gi, function() {
      let code = arguments[1], repeat = 6 - code.length;
      while (repeat--) {
        code = "0" + code;
      }
      return "\\" + code;
    });
  }
  function stringify(node, preserveProperties, text = "") {
    let cssText = "";
    if (node["cssText"] || node["rules"]) {
      let r$ = node["rules"];
      if (r$ && !_hasMixinRules(r$)) {
        for (let i = 0, l = r$.length, r; i < l && (r = r$[i]); i++) {
          cssText = stringify(r, preserveProperties, cssText);
        }
      } else {
        cssText = preserveProperties ? node["cssText"] : removeCustomProps(node["cssText"]);
        cssText = cssText.trim();
        if (cssText) {
          cssText = "  " + cssText + "\n";
        }
      }
    }
    if (cssText) {
      if (node["selector"]) {
        text += node["selector"] + " " + OPEN_BRACE + "\n";
      }
      text += cssText;
      if (node["selector"]) {
        text += CLOSE_BRACE + "\n\n";
      }
    }
    return text;
  }
  function _hasMixinRules(rules) {
    let r = rules[0];
    return Boolean(r) && Boolean(r["selector"]) && r["selector"].indexOf(VAR_START) === 0;
  }
  function removeCustomProps(cssText) {
    cssText = removeCustomPropAssignment(cssText);
    return removeCustomPropApply(cssText);
  }
  function removeCustomPropAssignment(cssText) {
    return cssText.replace(RX.customProp, "").replace(RX.mixinProp, "");
  }
  function removeCustomPropApply(cssText) {
    return cssText.replace(RX.mixinApply, "").replace(RX.varApply, "");
  }
  const types = {STYLE_RULE:1, KEYFRAMES_RULE:7, MEDIA_RULE:4, MIXIN_RULE:1000};
  const OPEN_BRACE = "{";
  const CLOSE_BRACE = "}";
  const RX = {comments:/\/\*[^*]*\*+([^/*][^*]*\*+)*\//gim, port:/@import[^;]*;/gim, customProp:/(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?(?:[;\n]|$)/gim, mixinProp:/(?:^[^;\-\s}]+)?--[^;{}]*?:[^{};]*?{[^}]*?}(?:[;\n]|$)?/gim, mixinApply:/@apply\s*\(?[^);]*\)?\s*(?:[;\n]|$)?/gim, varApply:/[^;:]*?:[^;]*?var\([^;]*\)(?:[;\n]|$)?/gim, keyframesRule:/^@[^\s]*keyframes/, multipleSpaces:/\s+/g};
  const VAR_START = "--";
  const MEDIA_START = "@media";
  const AT_START = "@";
}, "node_modules/@webcomponents/shadycss/src/css-parse.js", []);

//node_modules/@webcomponents/shadycss/src/style-settings.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {nativeCssVariables:{enumerable:true, get:function() {
    return nativeCssVariables;
  }}, nativeShadow:{enumerable:true, get:function() {
    return nativeShadow;
  }}});
  const nativeShadow = !(window["ShadyDOM"] && window["ShadyDOM"]["inUse"]);
  let nativeCssVariables_;
  function calcCssVariables(settings) {
    if (settings && settings["shimcssproperties"]) {
      nativeCssVariables_ = false;
    } else {
      nativeCssVariables_ = nativeShadow || Boolean(!navigator.userAgent.match(/AppleWebKit\/601|Edge\/15/) && window.CSS && CSS.supports && CSS.supports("box-shadow", "0 0 0 var(--foo)"));
    }
  }
  if (window.ShadyCSS && window.ShadyCSS.nativeCss !== undefined) {
    nativeCssVariables_ = window.ShadyCSS.nativeCss;
  } else {
    if (window.ShadyCSS) {
      calcCssVariables(window.ShadyCSS);
      window.ShadyCSS = undefined;
    } else {
      calcCssVariables(window["WebComponents"] && window["WebComponents"]["flags"]);
    }
  }
  const nativeCssVariables = nativeCssVariables_;
}, "node_modules/@webcomponents/shadycss/src/style-settings.js", []);

//node_modules/@webcomponents/shadycss/src/common-regex.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {ANIMATION_MATCH:{enumerable:true, get:function() {
    return ANIMATION_MATCH;
  }}, BRACKETED:{enumerable:true, get:function() {
    return BRACKETED;
  }}, HOST_PREFIX:{enumerable:true, get:function() {
    return HOST_PREFIX;
  }}, HOST_SUFFIX:{enumerable:true, get:function() {
    return HOST_SUFFIX;
  }}, IS_VAR:{enumerable:true, get:function() {
    return IS_VAR;
  }}, MEDIA_MATCH:{enumerable:true, get:function() {
    return MEDIA_MATCH;
  }}, MIXIN_MATCH:{enumerable:true, get:function() {
    return MIXIN_MATCH;
  }}, VAR_ASSIGN:{enumerable:true, get:function() {
    return VAR_ASSIGN;
  }}, VAR_CONSUMED:{enumerable:true, get:function() {
    return VAR_CONSUMED;
  }}});
  const VAR_ASSIGN = /(?:^|[;\s{]\s*)(--[\w-]*?)\s*:\s*(?:((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};{])+)|\{([^}]*)\}(?:(?=[;\s}])|$))/gi;
  const MIXIN_MATCH = /(?:^|\W+)@apply\s*\(?([^);\n]*)\)?/gi;
  const VAR_CONSUMED = /(--[\w-]+)\s*([:,;)]|$)/gi;
  const ANIMATION_MATCH = /(animation\s*:)|(animation-name\s*:)/;
  const MEDIA_MATCH = /@media\s(.*)/;
  const IS_VAR = /^--/;
  const BRACKETED = /\{[^}]*\}/g;
  const HOST_PREFIX = "(?:^|[^.#[:])";
  const HOST_SUFFIX = "($|[.:[\\s\x3e+~])";
}, "node_modules/@webcomponents/shadycss/src/common-regex.js", []);

//node_modules/@webcomponents/shadycss/src/unscoped-style-handler.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {isUnscopedStyle:{enumerable:true, get:function() {
    return isUnscopedStyle;
  }}, processUnscopedStyle:{enumerable:true, get:function() {
    return processUnscopedStyle;
  }}, scopingAttribute:{enumerable:true, get:function() {
    return scopingAttribute;
  }}});
  const styleTextSet = new Set;
  const scopingAttribute = "shady-unscoped";
  function processUnscopedStyle(style) {
    const text = style.textContent;
    if (!styleTextSet.has(text)) {
      styleTextSet.add(text);
      const newStyle = style.cloneNode(true);
      document.head.appendChild(newStyle);
    }
  }
  function isUnscopedStyle(style) {
    return style.hasAttribute(scopingAttribute);
  }
}, "node_modules/@webcomponents/shadycss/src/unscoped-style-handler.js", []);

//node_modules/@webcomponents/shadycss/src/style-util.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {applyCss:{enumerable:true, get:function() {
    return applyCss;
  }}, applyStyle:{enumerable:true, get:function() {
    return applyStyle;
  }}, applyStylePlaceHolder:{enumerable:true, get:function() {
    return applyStylePlaceHolder;
  }}, createScopeStyle:{enumerable:true, get:function() {
    return createScopeStyle;
  }}, elementHasBuiltCss:{enumerable:true, get:function() {
    return elementHasBuiltCss;
  }}, findMatchingParen:{enumerable:true, get:function() {
    return findMatchingParen;
  }}, forEachRule:{enumerable:true, get:function() {
    return forEachRule;
  }}, gatherStyleText:{enumerable:true, get:function() {
    return gatherStyleText;
  }}, getBuildComment:{enumerable:true, get:function() {
    return getBuildComment;
  }}, getCssBuild:{enumerable:true, get:function() {
    return getCssBuild;
  }}, getIsExtends:{enumerable:true, get:function() {
    return getIsExtends;
  }}, isKeyframesSelector:{enumerable:true, get:function() {
    return isKeyframesSelector;
  }}, isTargetedBuild:{enumerable:true, get:function() {
    return isTargetedBuild;
  }}, processVariableAndFallback:{enumerable:true, get:function() {
    return processVariableAndFallback;
  }}, rulesForStyle:{enumerable:true, get:function() {
    return rulesForStyle;
  }}, setElementClassRaw:{enumerable:true, get:function() {
    return setElementClassRaw;
  }}, splitSelectorList:{enumerable:true, get:function() {
    return splitSelectorList;
  }}, toCssText:{enumerable:true, get:function() {
    return toCssText;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  var module$node_modules$$webcomponents$shadycss$src$css_parse = $$require("node_modules/@webcomponents/shadycss/src/css-parse.js");
  var module$node_modules$$webcomponents$shadycss$src$common_regex = $$require("node_modules/@webcomponents/shadycss/src/common-regex.js");
  var module$node_modules$$webcomponents$shadycss$src$unscoped_style_handler = $$require("node_modules/@webcomponents/shadycss/src/unscoped-style-handler.js");
  function toCssText(rules, callback) {
    if (!rules) {
      return "";
    }
    if (typeof rules === "string") {
      rules = (0,module$node_modules$$webcomponents$shadycss$src$css_parse.parse)(rules);
    }
    if (callback) {
      forEachRule(rules, callback);
    }
    return (0,module$node_modules$$webcomponents$shadycss$src$css_parse.stringify)(rules, module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables);
  }
  function rulesForStyle(style) {
    if (!style["__cssRules"] && style.textContent) {
      style["__cssRules"] = (0,module$node_modules$$webcomponents$shadycss$src$css_parse.parse)(style.textContent);
    }
    return style["__cssRules"] || null;
  }
  function isKeyframesSelector(rule) {
    return Boolean(rule["parent"]) && rule["parent"]["type"] === module$node_modules$$webcomponents$shadycss$src$css_parse.types.KEYFRAMES_RULE;
  }
  function forEachRule(node, styleRuleCallback, keyframesRuleCallback, onlyActiveRules) {
    if (!node) {
      return;
    }
    let skipRules = false;
    let type = node["type"];
    if (onlyActiveRules) {
      if (type === module$node_modules$$webcomponents$shadycss$src$css_parse.types.MEDIA_RULE) {
        let matchMedia = node["selector"].match(module$node_modules$$webcomponents$shadycss$src$common_regex.MEDIA_MATCH);
        if (matchMedia) {
          if (!window.matchMedia(matchMedia[1]).matches) {
            skipRules = true;
          }
        }
      }
    }
    if (type === module$node_modules$$webcomponents$shadycss$src$css_parse.types.STYLE_RULE) {
      styleRuleCallback(node);
    } else {
      if (keyframesRuleCallback && type === module$node_modules$$webcomponents$shadycss$src$css_parse.types.KEYFRAMES_RULE) {
        keyframesRuleCallback(node);
      } else {
        if (type === module$node_modules$$webcomponents$shadycss$src$css_parse.types.MIXIN_RULE) {
          skipRules = true;
        }
      }
    }
    let r$ = node["rules"];
    if (r$ && !skipRules) {
      for (let i = 0, l = r$.length, r; i < l && (r = r$[i]); i++) {
        forEachRule(r, styleRuleCallback, keyframesRuleCallback, onlyActiveRules);
      }
    }
  }
  function applyCss(cssText, moniker, target, contextNode) {
    let style = createScopeStyle(cssText, moniker);
    applyStyle(style, target, contextNode);
    return style;
  }
  function createScopeStyle(cssText, moniker) {
    let style = document.createElement("style");
    if (moniker) {
      style.setAttribute("scope", moniker);
    }
    style.textContent = cssText;
    return style;
  }
  let lastHeadApplyNode = null;
  function applyStylePlaceHolder(moniker) {
    let placeHolder = document.createComment(" Shady DOM styles for " + moniker + " ");
    let after = lastHeadApplyNode ? lastHeadApplyNode["nextSibling"] : null;
    let scope = document.head;
    scope.insertBefore(placeHolder, after || scope.firstChild);
    lastHeadApplyNode = placeHolder;
    return placeHolder;
  }
  function applyStyle(style, target, contextNode) {
    target = target || document.head;
    let after = contextNode && contextNode.nextSibling || target.firstChild;
    target.insertBefore(style, after);
    if (!lastHeadApplyNode) {
      lastHeadApplyNode = style;
    } else {
      let position = style.compareDocumentPosition(lastHeadApplyNode);
      if (position === Node.DOCUMENT_POSITION_PRECEDING) {
        lastHeadApplyNode = style;
      }
    }
  }
  function isTargetedBuild(buildType) {
    return module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow ? buildType === "shadow" : buildType === "shady";
  }
  function findMatchingParen(text, start) {
    let level = 0;
    for (let i = start, l = text.length; i < l; i++) {
      if (text[i] === "(") {
        level++;
      } else {
        if (text[i] === ")") {
          if (--level === 0) {
            return i;
          }
        }
      }
    }
    return -1;
  }
  function processVariableAndFallback(str, callback) {
    let start = str.indexOf("var(");
    if (start === -1) {
      return callback(str, "", "", "");
    }
    let end = findMatchingParen(str, start + 3);
    let inner = str.substring(start + 4, end);
    let prefix = str.substring(0, start);
    let suffix = processVariableAndFallback(str.substring(end + 1), callback);
    let comma = inner.indexOf(",");
    if (comma === -1) {
      return callback(prefix, inner.trim(), "", suffix);
    }
    let value = inner.substring(0, comma).trim();
    let fallback = inner.substring(comma + 1).trim();
    return callback(prefix, value, fallback, suffix);
  }
  function setElementClassRaw(element, value) {
    if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
      element.setAttribute("class", value);
    } else {
      window["ShadyDOM"]["nativeMethods"]["setAttribute"].call(element, "class", value);
    }
  }
  function getIsExtends(element) {
    let localName = element["localName"];
    let is = "", typeExtension = "";
    if (localName) {
      if (localName.indexOf("-") > -1) {
        is = localName;
      } else {
        typeExtension = localName;
        is = element.getAttribute && element.getAttribute("is") || "";
      }
    } else {
      is = element.is;
      typeExtension = element["extends"];
    }
    return {is, typeExtension};
  }
  function gatherStyleText(element) {
    const styleTextParts = [];
    const styles = element.querySelectorAll("style");
    for (let i = 0; i < styles.length; i++) {
      const style = styles[i];
      if ((0,module$node_modules$$webcomponents$shadycss$src$unscoped_style_handler.isUnscopedStyle)(style)) {
        if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
          (0,module$node_modules$$webcomponents$shadycss$src$unscoped_style_handler.processUnscopedStyle)(style);
          style.parentNode.removeChild(style);
        }
      } else {
        styleTextParts.push(style.textContent);
        style.parentNode.removeChild(style);
      }
    }
    return styleTextParts.join("").trim();
  }
  function splitSelectorList(selector) {
    const parts = [];
    let part = "";
    for (let i = 0; i >= 0 && i < selector.length; i++) {
      if (selector[i] === "(") {
        const end = findMatchingParen(selector, i);
        part += selector.slice(i, end + 1);
        i = end;
      } else {
        if (selector[i] === ",") {
          parts.push(part);
          part = "";
        } else {
          part += selector[i];
        }
      }
    }
    if (part) {
      parts.push(part);
    }
    return parts;
  }
  const CSS_BUILD_ATTR = "css-build";
  function getCssBuild(element) {
    if (element.__cssBuild === undefined) {
      const attrValue = element.getAttribute(CSS_BUILD_ATTR);
      if (attrValue) {
        element.__cssBuild = attrValue;
      } else {
        const buildComment = getBuildComment(element);
        if (buildComment !== "") {
          removeBuildComment(element);
        }
        element.__cssBuild = buildComment;
      }
    }
    return element.__cssBuild || "";
  }
  function elementHasBuiltCss(element) {
    return getCssBuild(element) !== "";
  }
  function getBuildComment(element) {
    const buildComment = element.localName === "template" ? element.content.firstChild : element.firstChild;
    if (buildComment instanceof Comment) {
      const commentParts = buildComment.textContent.trim().split(":");
      if (commentParts[0] === CSS_BUILD_ATTR) {
        return commentParts[1];
      }
    }
    return "";
  }
  function removeBuildComment(element) {
    const buildComment = element.localName === "template" ? element.content.firstChild : element.firstChild;
    buildComment.parentNode.removeChild(buildComment);
  }
}, "node_modules/@webcomponents/shadycss/src/style-util.js", ["node_modules/@webcomponents/shadycss/src/style-settings.js", "node_modules/@webcomponents/shadycss/src/css-parse.js", "node_modules/@webcomponents/shadycss/src/common-regex.js", "node_modules/@webcomponents/shadycss/src/unscoped-style-handler.js"]);

//node_modules/@webcomponents/shadycss/src/style-transformer.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$css_parse = $$require("node_modules/@webcomponents/shadycss/src/css-parse.js");
  var StyleUtil = $$require("node_modules/@webcomponents/shadycss/src/style-util.js");
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  const SCOPE_NAME = "style-scope";
  class StyleTransformer {
    get SCOPE_NAME() {
      return SCOPE_NAME;
    }
    dom(node, scope, shouldRemoveScope) {
      const fn = (node) => {
        this.element(node, scope || "", shouldRemoveScope);
      };
      this._transformDom(node, fn);
    }
    domAddScope(node, scope) {
      const fn = (node) => {
        this.element(node, scope || "");
      };
      this._transformDom(node, fn);
    }
    _transformDom(startNode, transformer) {
      if (startNode.nodeType === Node.ELEMENT_NODE) {
        transformer(startNode);
      }
      let c$ = startNode.localName === "template" ? (startNode.content || startNode._content || startNode).childNodes : startNode.children || startNode.childNodes;
      if (c$) {
        for (let i = 0; i < c$.length; i++) {
          this._transformDom(c$[i], transformer);
        }
      }
    }
    element(element, scope, shouldRemoveScope) {
      if (scope) {
        if (element.classList) {
          if (shouldRemoveScope) {
            element.classList.remove(SCOPE_NAME);
            element.classList.remove(scope);
          } else {
            element.classList.add(SCOPE_NAME);
            element.classList.add(scope);
          }
        } else {
          if (element.getAttribute) {
            let c = element.getAttribute(CLASS);
            if (shouldRemoveScope) {
              if (c) {
                let newValue = c.replace(SCOPE_NAME, "").replace(scope, "");
                StyleUtil.setElementClassRaw(element, newValue);
              }
            } else {
              let newValue = (c ? c + " " : "") + SCOPE_NAME + " " + scope;
              StyleUtil.setElementClassRaw(element, newValue);
            }
          }
        }
      }
    }
    domReplaceScope(node, oldScope, newScope) {
      const fn = (node) => {
        this.element(node, oldScope, true);
        this.element(node, newScope);
      };
      this._transformDom(node, fn);
    }
    domRemoveScope(node, oldScope) {
      const fn = (node) => {
        this.element(node, oldScope || "", true);
      };
      this._transformDom(node, fn);
    }
    elementStyles(element, styleRules, callback, cssBuild = "") {
      let cssText = "";
      if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow || cssBuild === "shady") {
        cssText = StyleUtil.toCssText(styleRules, callback);
      } else {
        let {is, typeExtension} = StyleUtil.getIsExtends(element);
        cssText = this.css(styleRules, is, typeExtension, callback) + "\n\n";
      }
      return cssText.trim();
    }
    css(rules, scope, ext, callback) {
      let hostScope = this._calcHostScope(scope, ext);
      scope = this._calcElementScope(scope);
      let self = this;
      return StyleUtil.toCssText(rules, function(rule) {
        if (!rule.isScoped) {
          self.rule(rule, scope, hostScope);
          rule.isScoped = true;
        }
        if (callback) {
          callback(rule, scope, hostScope);
        }
      });
    }
    _calcElementScope(scope) {
      if (scope) {
        return CSS_CLASS_PREFIX + scope;
      } else {
        return "";
      }
    }
    _calcHostScope(scope, ext) {
      return ext ? `[is\x3d${scope}]` : scope;
    }
    rule(rule, scope, hostScope) {
      this._transformRule(rule, this._transformComplexSelector, scope, hostScope);
    }
    _transformRule(rule, transformer, scope, hostScope) {
      rule["selector"] = rule.transformedSelector = this._transformRuleCss(rule, transformer, scope, hostScope);
    }
    _transformRuleCss(rule, transformer, scope, hostScope) {
      let p$ = StyleUtil.splitSelectorList(rule["selector"]);
      if (!StyleUtil.isKeyframesSelector(rule)) {
        for (let i = 0, l = p$.length, p; i < l && (p = p$[i]); i++) {
          p$[i] = transformer.call(this, p, scope, hostScope);
        }
      }
      return p$.filter((part) => Boolean(part)).join(COMPLEX_SELECTOR_SEP);
    }
    _twiddleNthPlus(selector) {
      return selector.replace(NTH, (m, type, inside) => {
        if (inside.indexOf("+") > -1) {
          inside = inside.replace(/\+/g, "___");
        } else {
          if (inside.indexOf("___") > -1) {
            inside = inside.replace(/___/g, "+");
          }
        }
        return `:${type}(${inside})`;
      });
    }
    _preserveMatchesPseudo(selector) {
      const matches = [];
      let match;
      while (match = selector.match(MATCHES)) {
        const start = match.index;
        const end = StyleUtil.findMatchingParen(selector, start);
        if (end === -1) {
          throw new Error(`${match.input} selector missing ')'`);
        }
        const part = selector.slice(start, end + 1);
        selector = selector.replace(part, MATCHES_REPLACEMENT);
        matches.push(part);
      }
      return {selector, matches};
    }
    _replaceMatchesPseudo(selector, matches) {
      const parts = selector.split(MATCHES_REPLACEMENT);
      return matches.reduce((acc, cur, idx) => acc + cur + parts[idx + 1], parts[0]);
    }
    _transformComplexSelector(selector, scope, hostScope) {
      let stop = false;
      selector = selector.trim();
      let isNth = NTH.test(selector);
      if (isNth) {
        selector = selector.replace(NTH, (m, type, inner) => `:${type}(${inner.replace(/\s/g, "")})`);
        selector = this._twiddleNthPlus(selector);
      }
      const isMatches = MATCHES.test(selector);
      let matches;
      if (isMatches) {
        ({selector, matches} = this._preserveMatchesPseudo(selector));
      }
      selector = selector.replace(SLOTTED_START, `${HOST} \$1`);
      selector = selector.replace(SIMPLE_SELECTOR_SEP, (m, c, s) => {
        if (!stop) {
          let info = this._transformCompoundSelector(s, c, scope, hostScope);
          stop = stop || info.stop;
          c = info.combinator;
          s = info.value;
        }
        return c + s;
      });
      if (isMatches) {
        selector = this._replaceMatchesPseudo(selector, matches);
      }
      if (isNth) {
        selector = this._twiddleNthPlus(selector);
      }
      return selector;
    }
    _transformCompoundSelector(selector, combinator, scope, hostScope) {
      let slottedIndex = selector.indexOf(SLOTTED);
      if (selector.indexOf(HOST) >= 0) {
        selector = this._transformHostSelector(selector, hostScope);
      } else {
        if (slottedIndex !== 0) {
          selector = scope ? this._transformSimpleSelector(selector, scope) : selector;
        }
      }
      let slotted = false;
      if (slottedIndex >= 0) {
        combinator = "";
        slotted = true;
      }
      let stop;
      if (slotted) {
        stop = true;
        if (slotted) {
          selector = selector.replace(SLOTTED_PAREN, (m, paren) => ` \x3e ${paren}`);
        }
      }
      selector = selector.replace(DIR_PAREN, (m, before, dir) => `[dir\x3d"${dir}"] ${before}, ${before}[dir\x3d"${dir}"]`);
      return {value:selector, combinator, stop};
    }
    _transformSimpleSelector(selector, scope) {
      let p$ = selector.split(PSEUDO_PREFIX);
      p$[0] += scope;
      return p$.join(PSEUDO_PREFIX);
    }
    _transformHostSelector(selector, hostScope) {
      let m = selector.match(HOST_PAREN);
      let paren = m && m[2].trim() || "";
      if (paren) {
        if (!paren[0].match(SIMPLE_SELECTOR_PREFIX)) {
          let typeSelector = paren.split(SIMPLE_SELECTOR_PREFIX)[0];
          if (typeSelector === hostScope) {
            return paren;
          } else {
            return SELECTOR_NO_MATCH;
          }
        } else {
          return selector.replace(HOST_PAREN, function(m, host, paren) {
            return hostScope + paren;
          });
        }
      } else {
        return selector.replace(HOST, hostScope);
      }
    }
    documentRule(rule) {
      rule["selector"] = rule["parsedSelector"];
      this.normalizeRootSelector(rule);
      this._transformRule(rule, this._transformDocumentSelector);
    }
    normalizeRootSelector(rule) {
      if (rule["selector"] === ROOT) {
        rule["selector"] = "html";
      }
    }
    _transformDocumentSelector(selector) {
      if (selector.match(HOST)) {
        return "";
      } else {
        if (selector.match(SLOTTED)) {
          return this._transformComplexSelector(selector, SCOPE_DOC_SELECTOR);
        } else {
          return this._transformSimpleSelector(selector.trim(), SCOPE_DOC_SELECTOR);
        }
      }
    }
  }
  let NTH = /:(nth[-\w]+)\(([^)]+)\)/;
  let SCOPE_DOC_SELECTOR = `:not(.${SCOPE_NAME})`;
  let COMPLEX_SELECTOR_SEP = ",";
  let SIMPLE_SELECTOR_SEP = /(^|[\s>+~]+)((?:\[.+?\]|[^\s>+~=[])+)/g;
  let SIMPLE_SELECTOR_PREFIX = /[[.:#*]/;
  let HOST = ":host";
  let ROOT = ":root";
  let SLOTTED = "::slotted";
  let SLOTTED_START = new RegExp(`^(${SLOTTED})`);
  let HOST_PAREN = /(:host)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))/;
  let SLOTTED_PAREN = /(?:::slotted)(?:\(((?:\([^)(]*\)|[^)(]*)+?)\))/;
  let DIR_PAREN = /(.*):dir\((?:(ltr|rtl))\)/;
  let CSS_CLASS_PREFIX = ".";
  let PSEUDO_PREFIX = ":";
  let CLASS = "class";
  let SELECTOR_NO_MATCH = "should_not_match";
  const MATCHES = /:(?:matches|any|-(?:webkit|moz)-any)/;
  const MATCHES_REPLACEMENT = "\ue000";
  const $$default = new StyleTransformer;
}, "node_modules/@webcomponents/shadycss/src/style-transformer.js", ["node_modules/@webcomponents/shadycss/src/css-parse.js", "node_modules/@webcomponents/shadycss/src/style-util.js", "node_modules/@webcomponents/shadycss/src/style-settings.js"]);

//node_modules/@webcomponents/shadycss/src/style-info.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return StyleInfo;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$css_parse = $$require("node_modules/@webcomponents/shadycss/src/css-parse.js");
  const infoKey = "__styleInfo";
  class StyleInfo {
    static get(node) {
      if (node) {
        return node[infoKey];
      } else {
        return null;
      }
    }
    static set(node, styleInfo) {
      node[infoKey] = styleInfo;
      return styleInfo;
    }
    constructor(ast, placeholder, ownStylePropertyNames, elementName, typeExtension, cssBuild) {
      this.styleRules = ast || null;
      this.placeholder = placeholder || null;
      this.ownStylePropertyNames = ownStylePropertyNames || [];
      this.overrideStyleProperties = null;
      this.elementName = elementName || "";
      this.cssBuild = cssBuild || "";
      this.typeExtension = typeExtension || "";
      this.styleProperties = null;
      this.scopeSelector = null;
      this.customStyle = null;
    }
    _getStyleRules() {
      return this.styleRules;
    }
  }
  StyleInfo.prototype["_getStyleRules"] = StyleInfo.prototype._getStyleRules;
}, "node_modules/@webcomponents/shadycss/src/style-info.js", ["node_modules/@webcomponents/shadycss/src/css-parse.js"]);

//node_modules/@webcomponents/shadycss/src/style-properties.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$css_parse = $$require("node_modules/@webcomponents/shadycss/src/css-parse.js");
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  var module$node_modules$$webcomponents$shadycss$src$style_transformer = $$require("node_modules/@webcomponents/shadycss/src/style-transformer.js");
  var StyleUtil = $$require("node_modules/@webcomponents/shadycss/src/style-util.js");
  var RX = $$require("node_modules/@webcomponents/shadycss/src/common-regex.js");
  var module$node_modules$$webcomponents$shadycss$src$style_info = $$require("node_modules/@webcomponents/shadycss/src/style-info.js");
  const matchesSelector = function(selector) {
    const method = this.matches || this.matchesSelector || this.mozMatchesSelector || this.msMatchesSelector || this.oMatchesSelector || this.webkitMatchesSelector;
    return method && method.call(this, selector);
  };
  const IS_IE = navigator.userAgent.match("Trident");
  const XSCOPE_NAME = "x-scope";
  class StyleProperties {
    get XSCOPE_NAME() {
      return XSCOPE_NAME;
    }
    decorateStyles(rules) {
      let self = this, props = {}, keyframes = [], ruleIndex = 0;
      StyleUtil.forEachRule(rules, function(rule) {
        self.decorateRule(rule);
        rule.index = ruleIndex++;
        self.collectPropertiesInCssText(rule.propertyInfo.cssText, props);
      }, function onKeyframesRule(rule) {
        keyframes.push(rule);
      });
      rules._keyframes = keyframes;
      let names = [];
      for (let i in props) {
        names.push(i);
      }
      return names;
    }
    decorateRule(rule) {
      if (rule.propertyInfo) {
        return rule.propertyInfo;
      }
      let info = {}, properties = {};
      let hasProperties = this.collectProperties(rule, properties);
      if (hasProperties) {
        info.properties = properties;
        rule["rules"] = null;
      }
      info.cssText = this.collectCssText(rule);
      rule.propertyInfo = info;
      return info;
    }
    collectProperties(rule, properties) {
      let info = rule.propertyInfo;
      if (info) {
        if (info.properties) {
          Object.assign(properties, info.properties);
          return true;
        }
      } else {
        let m, rx = RX.VAR_ASSIGN;
        let cssText = rule["parsedCssText"];
        let value;
        let any;
        while (m = rx.exec(cssText)) {
          value = (m[2] || m[3]).trim();
          if (value !== "inherit" || value !== "unset") {
            properties[m[1].trim()] = value;
          }
          any = true;
        }
        return any;
      }
    }
    collectCssText(rule) {
      return this.collectConsumingCssText(rule["parsedCssText"]);
    }
    collectConsumingCssText(cssText) {
      return cssText.replace(RX.BRACKETED, "").replace(RX.VAR_ASSIGN, "");
    }
    collectPropertiesInCssText(cssText, props) {
      let m;
      while (m = RX.VAR_CONSUMED.exec(cssText)) {
        let name = m[1];
        if (m[2] !== ":") {
          props[name] = true;
        }
      }
    }
    reify(props) {
      let names = Object.getOwnPropertyNames(props);
      for (let i = 0, n; i < names.length; i++) {
        n = names[i];
        props[n] = this.valueForProperty(props[n], props);
      }
    }
    valueForProperty(property, props) {
      if (property) {
        if (property.indexOf(";") >= 0) {
          property = this.valueForProperties(property, props);
        } else {
          let self = this;
          let fn = function(prefix, value, fallback, suffix) {
            if (!value) {
              return prefix + suffix;
            }
            let propertyValue = self.valueForProperty(props[value], props);
            if (!propertyValue || propertyValue === "initial") {
              propertyValue = self.valueForProperty(props[fallback] || fallback, props) || fallback;
            } else {
              if (propertyValue === "apply-shim-inherit") {
                propertyValue = "inherit";
              }
            }
            return prefix + (propertyValue || "") + suffix;
          };
          property = StyleUtil.processVariableAndFallback(property, fn);
        }
      }
      return property && property.trim() || "";
    }
    valueForProperties(property, props) {
      let parts = property.split(";");
      for (let i = 0, p, m; i < parts.length; i++) {
        if (p = parts[i]) {
          RX.MIXIN_MATCH.lastIndex = 0;
          m = RX.MIXIN_MATCH.exec(p);
          if (m) {
            p = this.valueForProperty(props[m[1]], props);
          } else {
            let colon = p.indexOf(":");
            if (colon !== -1) {
              let pp = p.substring(colon);
              pp = pp.trim();
              pp = this.valueForProperty(pp, props) || pp;
              p = p.substring(0, colon) + pp;
            }
          }
          parts[i] = p && p.lastIndexOf(";") === p.length - 1 ? p.slice(0, -1) : p || "";
        }
      }
      return parts.join(";");
    }
    applyProperties(rule, props) {
      let output = "";
      if (!rule.propertyInfo) {
        this.decorateRule(rule);
      }
      if (rule.propertyInfo.cssText) {
        output = this.valueForProperties(rule.propertyInfo.cssText, props);
      }
      rule["cssText"] = output;
    }
    applyKeyframeTransforms(rule, keyframeTransforms) {
      let input = rule["cssText"];
      let output = rule["cssText"];
      if (rule.hasAnimations == null) {
        rule.hasAnimations = RX.ANIMATION_MATCH.test(input);
      }
      if (rule.hasAnimations) {
        let transform;
        if (rule.keyframeNamesToTransform == null) {
          rule.keyframeNamesToTransform = [];
          for (let keyframe in keyframeTransforms) {
            transform = keyframeTransforms[keyframe];
            output = transform(input);
            if (input !== output) {
              input = output;
              rule.keyframeNamesToTransform.push(keyframe);
            }
          }
        } else {
          for (let i = 0; i < rule.keyframeNamesToTransform.length; ++i) {
            transform = keyframeTransforms[rule.keyframeNamesToTransform[i]];
            input = transform(input);
          }
          output = input;
        }
      }
      rule["cssText"] = output;
    }
    propertyDataFromStyles(rules, element) {
      let props = {};
      let o = [];
      StyleUtil.forEachRule(rules, (rule) => {
        if (!rule.propertyInfo) {
          this.decorateRule(rule);
        }
        let selectorToMatch = rule.transformedSelector || rule["parsedSelector"];
        if (element && rule.propertyInfo.properties && selectorToMatch) {
          if (matchesSelector.call(element, selectorToMatch)) {
            this.collectProperties(rule, props);
            addToBitMask(rule.index, o);
          }
        }
      }, null, true);
      return {properties:props, key:o};
    }
    whenHostOrRootRule(scope, rule, cssBuild, callback) {
      if (!rule.propertyInfo) {
        this.decorateRule(rule);
      }
      if (!rule.propertyInfo.properties) {
        return;
      }
      let {is, typeExtension} = StyleUtil.getIsExtends(scope);
      let hostScope = is ? module$node_modules$$webcomponents$shadycss$src$style_transformer["default"]._calcHostScope(is, typeExtension) : "html";
      let parsedSelector = rule["parsedSelector"];
      let isRoot = parsedSelector === ":host \x3e *" || parsedSelector === "html";
      let isHost = parsedSelector.indexOf(":host") === 0 && !isRoot;
      if (cssBuild === "shady") {
        isRoot = parsedSelector === hostScope + " \x3e *." + hostScope || parsedSelector.indexOf("html") !== -1;
        isHost = !isRoot && parsedSelector.indexOf(hostScope) === 0;
      }
      if (!isRoot && !isHost) {
        return;
      }
      let selectorToMatch = hostScope;
      if (isHost) {
        if (!rule.transformedSelector) {
          rule.transformedSelector = module$node_modules$$webcomponents$shadycss$src$style_transformer["default"]._transformRuleCss(rule, module$node_modules$$webcomponents$shadycss$src$style_transformer["default"]._transformComplexSelector, module$node_modules$$webcomponents$shadycss$src$style_transformer["default"]._calcElementScope(is), hostScope);
        }
        selectorToMatch = rule.transformedSelector || hostScope;
      }
      callback({selector:selectorToMatch, isHost:isHost, isRoot:isRoot});
    }
    hostAndRootPropertiesForScope(scope, rules, cssBuild) {
      let hostProps = {}, rootProps = {};
      StyleUtil.forEachRule(rules, (rule) => {
        this.whenHostOrRootRule(scope, rule, cssBuild, (info) => {
          let element = scope._element || scope;
          if (matchesSelector.call(element, info.selector)) {
            if (info.isHost) {
              this.collectProperties(rule, hostProps);
            } else {
              this.collectProperties(rule, rootProps);
            }
          }
        });
      }, null, true);
      return {rootProps:rootProps, hostProps:hostProps};
    }
    transformStyles(element, properties, scopeSelector) {
      let self = this;
      let {is, typeExtension} = StyleUtil.getIsExtends(element);
      let hostSelector = module$node_modules$$webcomponents$shadycss$src$style_transformer["default"]._calcHostScope(is, typeExtension);
      let rxHostSelector = element["extends"] ? "\\" + hostSelector.slice(0, -1) + "\\]" : hostSelector;
      let hostRx = new RegExp(RX.HOST_PREFIX + rxHostSelector + RX.HOST_SUFFIX);
      let {styleRules:rules, cssBuild} = module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(element);
      let keyframeTransforms = this._elementKeyframeTransforms(element, rules, scopeSelector);
      return module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].elementStyles(element, rules, function(rule) {
        self.applyProperties(rule, properties);
        if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow && !StyleUtil.isKeyframesSelector(rule) && rule["cssText"]) {
          self.applyKeyframeTransforms(rule, keyframeTransforms);
          self._scopeSelector(rule, hostRx, hostSelector, scopeSelector);
        }
      }, cssBuild);
    }
    _elementKeyframeTransforms(element, rules, scopeSelector) {
      let keyframesRules = rules._keyframes;
      let keyframeTransforms = {};
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow && keyframesRules) {
        for (let i = 0, keyframesRule = keyframesRules[i]; i < keyframesRules.length; keyframesRule = keyframesRules[++i]) {
          this._scopeKeyframes(keyframesRule, scopeSelector);
          keyframeTransforms[keyframesRule["keyframesName"]] = this._keyframesRuleTransformer(keyframesRule);
        }
      }
      return keyframeTransforms;
    }
    _keyframesRuleTransformer(keyframesRule) {
      return function(cssText) {
        return cssText.replace(keyframesRule.keyframesNameRx, keyframesRule.transformedKeyframesName);
      };
    }
    _scopeKeyframes(rule, scopeId) {
      rule.keyframesNameRx = new RegExp(`\\b${rule["keyframesName"]}(?!\\B|-)`, "g");
      rule.transformedKeyframesName = rule["keyframesName"] + "-" + scopeId;
      rule.transformedSelector = rule.transformedSelector || rule["selector"];
      rule["selector"] = rule.transformedSelector.replace(rule["keyframesName"], rule.transformedKeyframesName);
    }
    _scopeSelector(rule, hostRx, hostSelector, scopeId) {
      rule.transformedSelector = rule.transformedSelector || rule["selector"];
      let selector = rule.transformedSelector;
      let scope = "." + scopeId;
      let parts = StyleUtil.splitSelectorList(selector);
      for (let i = 0, l = parts.length, p; i < l && (p = parts[i]); i++) {
        parts[i] = p.match(hostRx) ? p.replace(hostSelector, scope) : scope + " " + p;
      }
      rule["selector"] = parts.join(",");
    }
    applyElementScopeSelector(element, selector, old) {
      let c = element.getAttribute("class") || "";
      let v = c;
      if (old) {
        v = c.replace(new RegExp("\\s*" + XSCOPE_NAME + "\\s*" + old + "\\s*", "g"), " ");
      }
      v += (v ? " " : "") + XSCOPE_NAME + " " + selector;
      if (c !== v) {
        StyleUtil.setElementClassRaw(element, v);
      }
    }
    applyElementStyle(element, properties, selector, style) {
      let cssText = style ? style.textContent || "" : this.transformStyles(element, properties, selector);
      let styleInfo = module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(element);
      let s = styleInfo.customStyle;
      if (s && !module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow && s !== style) {
        s["_useCount"]--;
        if (s["_useCount"] <= 0 && s.parentNode) {
          s.parentNode.removeChild(s);
        }
      }
      if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
        if (styleInfo.customStyle) {
          styleInfo.customStyle.textContent = cssText;
          style = styleInfo.customStyle;
        } else {
          if (cssText) {
            style = StyleUtil.applyCss(cssText, selector, element.shadowRoot, styleInfo.placeholder);
          }
        }
      } else {
        if (!style) {
          if (cssText) {
            style = StyleUtil.applyCss(cssText, selector, null, styleInfo.placeholder);
          }
        } else {
          if (!style.parentNode) {
            if (IS_IE && cssText.indexOf("@media") > -1) {
              style.textContent = cssText;
            }
            StyleUtil.applyStyle(style, null, styleInfo.placeholder);
          }
        }
      }
      if (style) {
        style["_useCount"] = style["_useCount"] || 0;
        if (styleInfo.customStyle != style) {
          style["_useCount"]++;
        }
        styleInfo.customStyle = style;
      }
      return style;
    }
    applyCustomStyle(style, properties) {
      let rules = StyleUtil.rulesForStyle(style);
      let self = this;
      style.textContent = StyleUtil.toCssText(rules, function(rule) {
        let css = rule["cssText"] = rule["parsedCssText"];
        if (rule.propertyInfo && rule.propertyInfo.cssText) {
          css = (0,module$node_modules$$webcomponents$shadycss$src$css_parse.removeCustomPropAssignment)(css);
          rule["cssText"] = self.valueForProperties(css, properties);
        }
      });
    }
  }
  function addToBitMask(n, bits) {
    let o = parseInt(n / 32, 10);
    let v = 1 << n % 32;
    bits[o] = (bits[o] || 0) | v;
  }
  const $$default = new StyleProperties;
}, "node_modules/@webcomponents/shadycss/src/style-properties.js", ["node_modules/@webcomponents/shadycss/src/css-parse.js", "node_modules/@webcomponents/shadycss/src/style-settings.js", "node_modules/@webcomponents/shadycss/src/style-transformer.js", "node_modules/@webcomponents/shadycss/src/style-util.js", "node_modules/@webcomponents/shadycss/src/common-regex.js", "node_modules/@webcomponents/shadycss/src/style-info.js"]);

//node_modules/@webcomponents/shadycss/src/style-placeholder.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {ensureStylePlaceholder:{enumerable:true, get:function() {
    return ensureStylePlaceholder;
  }}, getStylePlaceholder:{enumerable:true, get:function() {
    return getStylePlaceholder;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$style_util = $$require("node_modules/@webcomponents/shadycss/src/style-util.js");
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  const placeholderMap = {};
  function getStylePlaceholder(elementName) {
    return placeholderMap[elementName] || null;
  }
  function ensureStylePlaceholder(elementName) {
    if (!placeholderMap[elementName]) {
      placeholderMap[elementName] = (0,module$node_modules$$webcomponents$shadycss$src$style_util.applyStylePlaceHolder)(elementName);
    }
  }
  const ce = window["customElements"];
  if (ce && !module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
    const origDefine = ce["define"];
    const wrappedDefine = (name, clazz, options) => {
      ensureStylePlaceholder(name);
      origDefine.call(ce, name, clazz, options);
    };
    ce["define"] = wrappedDefine;
  }
}, "node_modules/@webcomponents/shadycss/src/style-placeholder.js", ["node_modules/@webcomponents/shadycss/src/style-util.js", "node_modules/@webcomponents/shadycss/src/style-settings.js"]);

//node_modules/@webcomponents/shadycss/src/style-cache.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return StyleCache;
  }}});
  class StyleCache {
    constructor(typeMax = 100) {
      this.cache = {};
      this.typeMax = typeMax;
    }
    _validate(cacheEntry, properties, ownPropertyNames) {
      for (let idx = 0; idx < ownPropertyNames.length; idx++) {
        let pn = ownPropertyNames[idx];
        if (cacheEntry.properties[pn] !== properties[pn]) {
          return false;
        }
      }
      return true;
    }
    store(tagname, properties, styleElement, scopeSelector) {
      let list = this.cache[tagname] || [];
      list.push({properties, styleElement, scopeSelector});
      if (list.length > this.typeMax) {
        list.shift();
      }
      this.cache[tagname] = list;
    }
    fetch(tagname, properties, ownPropertyNames) {
      let list = this.cache[tagname];
      if (!list) {
        return;
      }
      for (let idx = list.length - 1; idx >= 0; idx--) {
        let entry = list[idx];
        if (this._validate(entry, properties, ownPropertyNames)) {
          return entry;
        }
      }
    }
  }
}, "node_modules/@webcomponents/shadycss/src/style-cache.js", []);

//node_modules/@webcomponents/shadycss/src/document-watcher.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {ensureCorrectScope:{enumerable:true, get:function() {
    return ensureCorrectScope;
  }}, ensureCorrectSubtreeScoping:{enumerable:true, get:function() {
    return ensureCorrectSubtreeScoping;
  }}, flush:{enumerable:true, get:function() {
    return flush;
  }}, getCurrentScope:{enumerable:true, get:function() {
    return getCurrentScope;
  }}, getOwnerScope:{enumerable:true, get:function() {
    return getOwnerScope;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  var module$node_modules$$webcomponents$shadycss$src$style_transformer = $$require("node_modules/@webcomponents/shadycss/src/style-transformer.js");
  var module$node_modules$$webcomponents$shadycss$src$style_util = $$require("node_modules/@webcomponents/shadycss/src/style-util.js");
  let flush = function() {
  };
  function getClasses(element) {
    let classes = [];
    if (element.classList) {
      classes = Array.from(element.classList);
    } else {
      if (element instanceof window["SVGElement"] && element.hasAttribute("class")) {
        classes = element.getAttribute("class").split(/\s+/);
      }
    }
    return classes;
  }
  function getCurrentScope(element) {
    let classes = getClasses(element);
    let idx = classes.indexOf(module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].SCOPE_NAME);
    if (idx > -1) {
      return classes[idx + 1];
    }
    return "";
  }
  function getOwnerScope(node) {
    const ownerRoot = node.getRootNode();
    if (ownerRoot === node || ownerRoot === node.ownerDocument) {
      return "";
    }
    const host = ownerRoot.host;
    if (!host) {
      return "";
    }
    return (0,module$node_modules$$webcomponents$shadycss$src$style_util.getIsExtends)(host).is;
  }
  function ensureCorrectScope(element) {
    const currentScope = getCurrentScope(element);
    const ownerRoot = element.getRootNode();
    if (ownerRoot === element) {
      return;
    }
    if (currentScope && ownerRoot === element.ownerDocument) {
      module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].domRemoveScope(element, currentScope);
    } else {
      if (ownerRoot instanceof ShadowRoot) {
        const ownerScope = getOwnerScope(element);
        if (ownerScope !== currentScope) {
          module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].domReplaceScope(element, currentScope, ownerScope);
        }
      }
    }
  }
  function ensureCorrectSubtreeScoping(element) {
    const unscopedNodes = window["ShadyDOM"]["nativeMethods"]["querySelectorAll"].call(element, `:not(.${module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].SCOPE_NAME})`);
    for (let j = 0; j < unscopedNodes.length; j++) {
      const unscopedNode = unscopedNodes[j];
      const scopeForPreviouslyUnscopedNode = getOwnerScope(unscopedNode);
      if (scopeForPreviouslyUnscopedNode) {
        module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].element(unscopedNode, scopeForPreviouslyUnscopedNode);
      }
    }
  }
  function isElementWithBuiltCss(el) {
    if (el.localName === "style" || el.localName === "template") {
      return (0,module$node_modules$$webcomponents$shadycss$src$style_util.elementHasBuiltCss)(el);
    }
    return false;
  }
  function handler(mxns) {
    for (let x = 0; x < mxns.length; x++) {
      let mxn = mxns[x];
      if (mxn.target === document.documentElement || mxn.target === document.head) {
        continue;
      }
      for (let i = 0; i < mxn.addedNodes.length; i++) {
        let n = mxn.addedNodes[i];
        if (n.nodeType !== Node.ELEMENT_NODE) {
          continue;
        }
        n = n;
        let root = n.getRootNode();
        let currentScope = getCurrentScope(n);
        if (currentScope && root === n.ownerDocument && !isElementWithBuiltCss(n)) {
          module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].domRemoveScope(n, currentScope);
        } else {
          if (root instanceof ShadowRoot) {
            const newScope = getOwnerScope(n);
            if (newScope !== currentScope) {
              module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].domReplaceScope(n, currentScope, newScope);
            }
            ensureCorrectSubtreeScoping(n);
          }
        }
      }
    }
  }
  if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow && !(window["ShadyDOM"] && window["ShadyDOM"]["handlesDynamicScoping"])) {
    let observer = new MutationObserver(handler);
    let start = (node) => {
      observer.observe(node, {childList:true, subtree:true});
    };
    let nativeCustomElements = window["customElements"] && !window["customElements"]["polyfillWrapFlushCallback"];
    if (nativeCustomElements) {
      start(document);
    } else {
      let delayedStart = () => {
        start(document.body);
      };
      if (window["HTMLImports"]) {
        window["HTMLImports"]["whenReady"](delayedStart);
      } else {
        requestAnimationFrame(function() {
          if (document.readyState === "loading") {
            let listener = function() {
              delayedStart();
              document.removeEventListener("readystatechange", listener);
            };
            document.addEventListener("readystatechange", listener);
          } else {
            delayedStart();
          }
        });
      }
    }
    flush = function() {
      handler(observer.takeRecords());
    };
  }
}, "node_modules/@webcomponents/shadycss/src/document-watcher.js", ["node_modules/@webcomponents/shadycss/src/style-settings.js", "node_modules/@webcomponents/shadycss/src/style-transformer.js", "node_modules/@webcomponents/shadycss/src/style-util.js"]);

//node_modules/@webcomponents/shadycss/src/template-map.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return $$default;
  }}});
  const templateMap = {};
  const $$default = templateMap;
}, "node_modules/@webcomponents/shadycss/src/template-map.js", []);

//node_modules/@webcomponents/shadycss/src/apply-shim-utils.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {elementsAreInvalid:{enumerable:true, get:function() {
    return elementsAreInvalid;
  }}, invalidate:{enumerable:true, get:function() {
    return invalidate;
  }}, invalidateTemplate:{enumerable:true, get:function() {
    return invalidateTemplate;
  }}, isValid:{enumerable:true, get:function() {
    return isValid;
  }}, isValidating:{enumerable:true, get:function() {
    return isValidating;
  }}, startValidating:{enumerable:true, get:function() {
    return startValidating;
  }}, startValidatingTemplate:{enumerable:true, get:function() {
    return startValidatingTemplate;
  }}, templateIsValid:{enumerable:true, get:function() {
    return templateIsValid;
  }}, templateIsValidating:{enumerable:true, get:function() {
    return templateIsValidating;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$template_map = $$require("node_modules/@webcomponents/shadycss/src/template-map.js");
  var module$node_modules$$webcomponents$shadycss$src$css_parse = $$require("node_modules/@webcomponents/shadycss/src/css-parse.js");
  const CURRENT_VERSION = "_applyShimCurrentVersion";
  const NEXT_VERSION = "_applyShimNextVersion";
  const VALIDATING_VERSION = "_applyShimValidatingVersion";
  const promise = Promise.resolve();
  function invalidate(elementName) {
    let template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][elementName];
    if (template) {
      invalidateTemplate(template);
    }
  }
  function invalidateTemplate(template) {
    template[CURRENT_VERSION] = template[CURRENT_VERSION] || 0;
    template[VALIDATING_VERSION] = template[VALIDATING_VERSION] || 0;
    template[NEXT_VERSION] = (template[NEXT_VERSION] || 0) + 1;
  }
  function isValid(elementName) {
    let template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][elementName];
    if (template) {
      return templateIsValid(template);
    }
    return true;
  }
  function templateIsValid(template) {
    return template[CURRENT_VERSION] === template[NEXT_VERSION];
  }
  function isValidating(elementName) {
    let template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][elementName];
    if (template) {
      return templateIsValidating(template);
    }
    return false;
  }
  function templateIsValidating(template) {
    return !templateIsValid(template) && template[VALIDATING_VERSION] === template[NEXT_VERSION];
  }
  function startValidating(elementName) {
    let template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][elementName];
    startValidatingTemplate(template);
  }
  function startValidatingTemplate(template) {
    template[VALIDATING_VERSION] = template[NEXT_VERSION];
    if (!template._validating) {
      template._validating = true;
      promise.then(function() {
        template[CURRENT_VERSION] = template[NEXT_VERSION];
        template._validating = false;
      });
    }
  }
  function elementsAreInvalid() {
    for (let elementName in module$node_modules$$webcomponents$shadycss$src$template_map["default"]) {
      let template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][elementName];
      if (!templateIsValid(template)) {
        return true;
      }
    }
    return false;
  }
}, "node_modules/@webcomponents/shadycss/src/apply-shim-utils.js", ["node_modules/@webcomponents/shadycss/src/template-map.js", "node_modules/@webcomponents/shadycss/src/css-parse.js"]);

//node_modules/@webcomponents/shadycss/src/common-utils.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {detectMixin:{enumerable:true, get:function() {
    return detectMixin;
  }}, getComputedStyleValue:{enumerable:true, get:function() {
    return getComputedStyleValue;
  }}, updateNativeProperties:{enumerable:true, get:function() {
    return updateNativeProperties;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$common_regex = $$require("node_modules/@webcomponents/shadycss/src/common-regex.js");
  function updateNativeProperties(element, properties) {
    for (let p in properties) {
      if (p === null) {
        element.style.removeProperty(p);
      } else {
        element.style.setProperty(p, properties[p]);
      }
    }
  }
  function getComputedStyleValue(element, property) {
    const value = window.getComputedStyle(element).getPropertyValue(property);
    if (!value) {
      return "";
    } else {
      return value.trim();
    }
  }
  function detectMixin(cssText) {
    const has = module$node_modules$$webcomponents$shadycss$src$common_regex.MIXIN_MATCH.test(cssText) || module$node_modules$$webcomponents$shadycss$src$common_regex.VAR_ASSIGN.test(cssText);
    module$node_modules$$webcomponents$shadycss$src$common_regex.MIXIN_MATCH.lastIndex = 0;
    module$node_modules$$webcomponents$shadycss$src$common_regex.VAR_ASSIGN.lastIndex = 0;
    return has;
  }
}, "node_modules/@webcomponents/shadycss/src/common-utils.js", ["node_modules/@webcomponents/shadycss/src/common-regex.js"]);

//node_modules/@webcomponents/shadycss/src/document-wait.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return documentWait;
  }}});
  let readyPromise = null;
  let whenReady = window["HTMLImports"] && window["HTMLImports"]["whenReady"] || null;
  let resolveFn;
  function documentWait(callback) {
    requestAnimationFrame(function() {
      if (whenReady) {
        whenReady(callback);
      } else {
        if (!readyPromise) {
          readyPromise = new Promise((resolve) => {
            resolveFn = resolve;
          });
          if (document.readyState === "complete") {
            resolveFn();
          } else {
            document.addEventListener("readystatechange", () => {
              if (document.readyState === "complete") {
                resolveFn();
              }
            });
          }
        }
        readyPromise.then(function() {
          callback && callback();
        });
      }
    });
  }
}, "node_modules/@webcomponents/shadycss/src/document-wait.js", []);

//node_modules/@webcomponents/shadycss/src/custom-style-interface.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {CustomStyleInterfaceInterface:{enumerable:true, get:function() {
    return CustomStyleInterfaceInterface;
  }}, CustomStyleProvider:{enumerable:true, get:function() {
    return CustomStyleProvider;
  }}, "default":{enumerable:true, get:function() {
    return CustomStyleInterface;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$document_wait = $$require("node_modules/@webcomponents/shadycss/src/document-wait.js");
  let CustomStyleProvider;
  const SEEN_MARKER = "__seenByShadyCSS";
  const CACHED_STYLE = "__shadyCSSCachedStyle";
  let transformFn = null;
  let validateFn = null;
  class CustomStyleInterface {
    constructor() {
      this["customStyles"] = [];
      this["enqueued"] = false;
      (0,module$node_modules$$webcomponents$shadycss$src$document_wait["default"])(() => {
        if (window["ShadyCSS"]["flushCustomStyles"]) {
          window["ShadyCSS"]["flushCustomStyles"]();
        }
      });
    }
    enqueueDocumentValidation() {
      if (this["enqueued"] || !validateFn) {
        return;
      }
      this["enqueued"] = true;
      (0,module$node_modules$$webcomponents$shadycss$src$document_wait["default"])(validateFn);
    }
    addCustomStyle(style) {
      if (!style[SEEN_MARKER]) {
        style[SEEN_MARKER] = true;
        this["customStyles"].push(style);
        this.enqueueDocumentValidation();
      }
    }
    getStyleForCustomStyle(customStyle) {
      if (customStyle[CACHED_STYLE]) {
        return customStyle[CACHED_STYLE];
      }
      let style;
      if (customStyle["getStyle"]) {
        style = customStyle["getStyle"]();
      } else {
        style = customStyle;
      }
      return style;
    }
    processStyles() {
      const cs = this["customStyles"];
      for (let i = 0; i < cs.length; i++) {
        const customStyle = cs[i];
        if (customStyle[CACHED_STYLE]) {
          continue;
        }
        const style = this.getStyleForCustomStyle(customStyle);
        if (style) {
          const styleToTransform = style["__appliedElement"] || style;
          if (transformFn) {
            transformFn(styleToTransform);
          }
          customStyle[CACHED_STYLE] = styleToTransform;
        }
      }
      return cs;
    }
  }
  CustomStyleInterface.prototype["addCustomStyle"] = CustomStyleInterface.prototype.addCustomStyle;
  CustomStyleInterface.prototype["getStyleForCustomStyle"] = CustomStyleInterface.prototype.getStyleForCustomStyle;
  CustomStyleInterface.prototype["processStyles"] = CustomStyleInterface.prototype.processStyles;
  Object.defineProperties(CustomStyleInterface.prototype, {"transformCallback":{get() {
    return transformFn;
  }, set(fn) {
    transformFn = fn;
  }}, "validateCallback":{get() {
    return validateFn;
  }, set(fn) {
    let needsEnqueue = false;
    if (!validateFn) {
      needsEnqueue = true;
    }
    validateFn = fn;
    if (needsEnqueue) {
      this.enqueueDocumentValidation();
    }
  }}});
  let CustomStyleInterfaceInterface;
}, "node_modules/@webcomponents/shadycss/src/custom-style-interface.js", ["node_modules/@webcomponents/shadycss/src/document-wait.js"]);

//node_modules/@webcomponents/shadycss/src/scoping-shim.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  Object.defineProperties($$exports, {"default":{enumerable:true, get:function() {
    return ScopingShim;
  }}});
  var module$node_modules$$webcomponents$shadycss$src$css_parse = $$require("node_modules/@webcomponents/shadycss/src/css-parse.js");
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  var module$node_modules$$webcomponents$shadycss$src$style_transformer = $$require("node_modules/@webcomponents/shadycss/src/style-transformer.js");
  var StyleUtil = $$require("node_modules/@webcomponents/shadycss/src/style-util.js");
  var module$node_modules$$webcomponents$shadycss$src$style_properties = $$require("node_modules/@webcomponents/shadycss/src/style-properties.js");
  var module$node_modules$$webcomponents$shadycss$src$style_placeholder = $$require("node_modules/@webcomponents/shadycss/src/style-placeholder.js");
  var module$node_modules$$webcomponents$shadycss$src$style_info = $$require("node_modules/@webcomponents/shadycss/src/style-info.js");
  var module$node_modules$$webcomponents$shadycss$src$style_cache = $$require("node_modules/@webcomponents/shadycss/src/style-cache.js");
  var module$node_modules$$webcomponents$shadycss$src$document_watcher = $$require("node_modules/@webcomponents/shadycss/src/document-watcher.js");
  var module$node_modules$$webcomponents$shadycss$src$template_map = $$require("node_modules/@webcomponents/shadycss/src/template-map.js");
  var ApplyShimUtils = $$require("node_modules/@webcomponents/shadycss/src/apply-shim-utils.js");
  var module$node_modules$$webcomponents$shadycss$src$common_utils = $$require("node_modules/@webcomponents/shadycss/src/common-utils.js");
  var module$node_modules$$webcomponents$shadycss$src$custom_style_interface = $$require("node_modules/@webcomponents/shadycss/src/custom-style-interface.js");
  const styleCache = new module$node_modules$$webcomponents$shadycss$src$style_cache["default"];
  class ScopingShim {
    constructor() {
      this._scopeCounter = {};
      this._documentOwner = document.documentElement;
      let ast = new module$node_modules$$webcomponents$shadycss$src$css_parse.StyleNode;
      ast["rules"] = [];
      this._documentOwnerStyleInfo = module$node_modules$$webcomponents$shadycss$src$style_info["default"].set(this._documentOwner, new module$node_modules$$webcomponents$shadycss$src$style_info["default"](ast));
      this._elementsHaveApplied = false;
      this._applyShim = null;
      this._customStyleInterface = null;
    }
    flush() {
      (0,module$node_modules$$webcomponents$shadycss$src$document_watcher.flush)();
    }
    _generateScopeSelector(name) {
      let id = this._scopeCounter[name] = (this._scopeCounter[name] || 0) + 1;
      return `${name}-${id}`;
    }
    getStyleAst(style) {
      return StyleUtil.rulesForStyle(style);
    }
    styleAstToString(ast) {
      return StyleUtil.toCssText(ast);
    }
    _gatherStyles(template) {
      return StyleUtil.gatherStyleText(template.content);
    }
    prepareTemplate(template, elementName, typeExtension) {
      this.prepareTemplateDom(template, elementName);
      this.prepareTemplateStyles(template, elementName, typeExtension);
    }
    prepareTemplateStyles(template, elementName, typeExtension) {
      if (template._prepared) {
        return;
      }
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
        (0,module$node_modules$$webcomponents$shadycss$src$style_placeholder.ensureStylePlaceholder)(elementName);
      }
      template._prepared = true;
      template.name = elementName;
      template["extends"] = typeExtension;
      module$node_modules$$webcomponents$shadycss$src$template_map["default"][elementName] = template;
      let cssBuild = StyleUtil.getCssBuild(template);
      let cssText = this._gatherStyles(template);
      let info = {is:elementName, "extends":typeExtension};
      this._ensure();
      let hasMixins = !StyleUtil.elementHasBuiltCss(template) && (0,module$node_modules$$webcomponents$shadycss$src$common_utils.detectMixin)(cssText);
      let ast = (0,module$node_modules$$webcomponents$shadycss$src$css_parse.parse)(cssText);
      if (hasMixins && module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables && this._applyShim) {
        this._applyShim["transformRules"](ast, elementName);
      }
      template["_styleAst"] = ast;
      let ownPropertyNames = [];
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        ownPropertyNames = module$node_modules$$webcomponents$shadycss$src$style_properties["default"].decorateStyles(template["_styleAst"]);
      }
      if (!ownPropertyNames.length || module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        let root = module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow ? template.content : null;
        let placeholder = (0,module$node_modules$$webcomponents$shadycss$src$style_placeholder.getStylePlaceholder)(elementName);
        let style = this._generateStaticStyle(info, template["_styleAst"], root, placeholder, cssBuild);
        template._style = style;
      }
      template._ownPropertyNames = ownPropertyNames;
    }
    prepareTemplateDom(template, elementName) {
      const cssBuild = StyleUtil.getCssBuild(template);
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow && cssBuild !== "shady" && !template._domPrepared) {
        template._domPrepared = true;
        module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].domAddScope(template.content, elementName);
      }
    }
    _generateStaticStyle(info, rules, shadowroot, placeholder, cssBuild) {
      let cssText = module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].elementStyles(info, rules, null, cssBuild);
      if (cssText.length) {
        return StyleUtil.applyCss(cssText, info.is, shadowroot, placeholder);
      }
    }
    _prepareHost(host) {
      let {is, typeExtension} = StyleUtil.getIsExtends(host);
      let placeholder = (0,module$node_modules$$webcomponents$shadycss$src$style_placeholder.getStylePlaceholder)(is);
      let template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][is];
      let ast;
      let ownStylePropertyNames;
      let cssBuild;
      if (template) {
        ast = template["_styleAst"];
        ownStylePropertyNames = template._ownPropertyNames;
        cssBuild = StyleUtil.getCssBuild(template);
      }
      const styleInfo = new module$node_modules$$webcomponents$shadycss$src$style_info["default"](ast, placeholder, ownStylePropertyNames, is, typeExtension, cssBuild);
      if (template) {
        module$node_modules$$webcomponents$shadycss$src$style_info["default"].set(host, styleInfo);
      }
      return styleInfo;
    }
    _ensureApplyShim() {
      if (this._applyShim) {
        return;
      } else {
        if (window.ShadyCSS && window.ShadyCSS.ApplyShim) {
          this._applyShim = window.ShadyCSS.ApplyShim;
          this._applyShim["invalidCallback"] = ApplyShimUtils.invalidate;
        }
      }
    }
    _ensureCustomStyleInterface() {
      if (this._customStyleInterface) {
        return;
      } else {
        if (window.ShadyCSS && window.ShadyCSS.CustomStyleInterface) {
          this._customStyleInterface = window.ShadyCSS.CustomStyleInterface;
          this._customStyleInterface["transformCallback"] = (style) => {
            this.transformCustomStyleForDocument(style);
          };
          this._customStyleInterface["validateCallback"] = () => {
            requestAnimationFrame(() => {
              if (this._customStyleInterface["enqueued"] || this._elementsHaveApplied) {
                this.flushCustomStyles();
              }
            });
          };
        }
      }
    }
    _ensure() {
      this._ensureApplyShim();
      this._ensureCustomStyleInterface();
    }
    flushCustomStyles() {
      this._ensure();
      if (!this._customStyleInterface) {
        return;
      }
      let customStyles = this._customStyleInterface["processStyles"]();
      if (!this._customStyleInterface["enqueued"]) {
        return;
      }
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        this._updateProperties(this._documentOwner, this._documentOwnerStyleInfo);
        this._applyCustomStyles(customStyles);
      } else {
        this._revalidateCustomStyleApplyShim(customStyles);
      }
      this._customStyleInterface["enqueued"] = false;
      if (this._elementsHaveApplied && !module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        this.styleDocument();
      }
    }
    styleElement(host, overrideProps) {
      let styleInfo = module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(host);
      if (!styleInfo) {
        styleInfo = this._prepareHost(host);
      }
      if (!this._isRootOwner(host)) {
        this._elementsHaveApplied = true;
      }
      if (overrideProps) {
        styleInfo.overrideStyleProperties = styleInfo.overrideStyleProperties || {};
        Object.assign(styleInfo.overrideStyleProperties, overrideProps);
      }
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        this.styleElementShimVariables(host, styleInfo);
      } else {
        this.styleElementNativeVariables(host, styleInfo);
      }
    }
    styleElementShimVariables(host, styleInfo) {
      this.flush();
      this._updateProperties(host, styleInfo);
      if (styleInfo.ownStylePropertyNames && styleInfo.ownStylePropertyNames.length) {
        this._applyStyleProperties(host, styleInfo);
      }
    }
    styleElementNativeVariables(host, styleInfo) {
      const {is} = StyleUtil.getIsExtends(host);
      if (styleInfo.overrideStyleProperties) {
        (0,module$node_modules$$webcomponents$shadycss$src$common_utils.updateNativeProperties)(host, styleInfo.overrideStyleProperties);
      }
      const template = module$node_modules$$webcomponents$shadycss$src$template_map["default"][is];
      if (!template && !this._isRootOwner(host)) {
        return;
      }
      if (template && StyleUtil.elementHasBuiltCss(template)) {
        return;
      }
      if (template && template._style && !ApplyShimUtils.templateIsValid(template)) {
        if (!ApplyShimUtils.templateIsValidating(template)) {
          this._ensure();
          this._applyShim && this._applyShim["transformRules"](template["_styleAst"], is);
          template._style.textContent = module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].elementStyles(host, styleInfo.styleRules);
          ApplyShimUtils.startValidatingTemplate(template);
        }
        if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
          let root = host.shadowRoot;
          if (root) {
            let style = root.querySelector("style");
            if (style) {
              style.textContent = module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].elementStyles(host, styleInfo.styleRules);
            }
          }
        }
        styleInfo.styleRules = template["_styleAst"];
      }
    }
    _styleOwnerForNode(node) {
      let root = node.getRootNode();
      let host = root.host;
      if (host) {
        if (module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(host)) {
          return host;
        } else {
          return this._styleOwnerForNode(host);
        }
      }
      return this._documentOwner;
    }
    _isRootOwner(node) {
      return node === this._documentOwner;
    }
    _applyStyleProperties(host, styleInfo) {
      let is = StyleUtil.getIsExtends(host).is;
      let cacheEntry = styleCache.fetch(is, styleInfo.styleProperties, styleInfo.ownStylePropertyNames);
      let cachedScopeSelector = cacheEntry && cacheEntry.scopeSelector;
      let cachedStyle = cacheEntry ? cacheEntry.styleElement : null;
      let oldScopeSelector = styleInfo.scopeSelector;
      styleInfo.scopeSelector = cachedScopeSelector || this._generateScopeSelector(is);
      let style = module$node_modules$$webcomponents$shadycss$src$style_properties["default"].applyElementStyle(host, styleInfo.styleProperties, styleInfo.scopeSelector, cachedStyle);
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
        module$node_modules$$webcomponents$shadycss$src$style_properties["default"].applyElementScopeSelector(host, styleInfo.scopeSelector, oldScopeSelector);
      }
      if (!cacheEntry) {
        styleCache.store(is, styleInfo.styleProperties, style, styleInfo.scopeSelector);
      }
      return style;
    }
    _updateProperties(host, styleInfo) {
      let owner = this._styleOwnerForNode(host);
      let ownerStyleInfo = module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(owner);
      let ownerProperties = ownerStyleInfo.styleProperties;
      let props = Object.create(ownerProperties || null);
      let hostAndRootProps = module$node_modules$$webcomponents$shadycss$src$style_properties["default"].hostAndRootPropertiesForScope(host, styleInfo.styleRules, styleInfo.cssBuild);
      let propertyData = module$node_modules$$webcomponents$shadycss$src$style_properties["default"].propertyDataFromStyles(ownerStyleInfo.styleRules, host);
      let propertiesMatchingHost = propertyData.properties;
      Object.assign(props, hostAndRootProps.hostProps, propertiesMatchingHost, hostAndRootProps.rootProps);
      this._mixinOverrideStyles(props, styleInfo.overrideStyleProperties);
      module$node_modules$$webcomponents$shadycss$src$style_properties["default"].reify(props);
      styleInfo.styleProperties = props;
    }
    _mixinOverrideStyles(props, overrides) {
      for (let p in overrides) {
        let v = overrides[p];
        if (v || v === 0) {
          props[p] = v;
        }
      }
    }
    styleDocument(properties) {
      this.styleSubtree(this._documentOwner, properties);
    }
    styleSubtree(host, properties) {
      let root = host.shadowRoot;
      if (root || this._isRootOwner(host)) {
        this.styleElement(host, properties);
      }
      let shadowChildren = root && (root.children || root.childNodes);
      if (shadowChildren) {
        for (let i = 0; i < shadowChildren.length; i++) {
          let c = shadowChildren[i];
          this.styleSubtree(c);
        }
      } else {
        let children = host.children || host.childNodes;
        if (children) {
          for (let i = 0; i < children.length; i++) {
            let c = children[i];
            this.styleSubtree(c);
          }
        }
      }
    }
    _revalidateCustomStyleApplyShim(customStyles) {
      for (let i = 0; i < customStyles.length; i++) {
        let c = customStyles[i];
        let s = this._customStyleInterface["getStyleForCustomStyle"](c);
        if (s) {
          this._revalidateApplyShim(s);
        }
      }
    }
    _applyCustomStyles(customStyles) {
      for (let i = 0; i < customStyles.length; i++) {
        let c = customStyles[i];
        let s = this._customStyleInterface["getStyleForCustomStyle"](c);
        if (s) {
          module$node_modules$$webcomponents$shadycss$src$style_properties["default"].applyCustomStyle(s, this._documentOwnerStyleInfo.styleProperties);
        }
      }
    }
    transformCustomStyleForDocument(style) {
      let ast = StyleUtil.rulesForStyle(style);
      const cssBuild = StyleUtil.getCssBuild(style);
      if (cssBuild !== this._documentOwnerStyleInfo.cssBuild) {
        this._documentOwnerStyleInfo.cssBuild = cssBuild;
      }
      StyleUtil.forEachRule(ast, (rule) => {
        if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow) {
          module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].normalizeRootSelector(rule);
        } else {
          module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].documentRule(rule);
        }
        if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables && cssBuild === "") {
          this._ensure();
          this._applyShim && this._applyShim["transformRule"](rule);
        }
      });
      if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        style.textContent = StyleUtil.toCssText(ast);
      } else {
        this._documentOwnerStyleInfo.styleRules["rules"].push(ast);
      }
    }
    _revalidateApplyShim(style) {
      if (module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables && this._applyShim) {
        let ast = StyleUtil.rulesForStyle(style);
        this._ensure();
        this._applyShim["transformRules"](ast);
        style.textContent = StyleUtil.toCssText(ast);
      }
    }
    getComputedStyleValue(element, property) {
      let value;
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        let styleInfo = module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(element) || module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(this._styleOwnerForNode(element));
        value = styleInfo.styleProperties[property];
      }
      value = value || window.getComputedStyle(element).getPropertyValue(property);
      return value ? value.trim() : "";
    }
    setElementClass(element, classString) {
      let root = element.getRootNode();
      let classes = classString ? classString.split(/\s/) : [];
      let scopeName = root.host && root.host.localName;
      if (!scopeName) {
        var classAttr = element.getAttribute("class");
        if (classAttr) {
          let k$ = classAttr.split(/\s/);
          for (let i = 0; i < k$.length; i++) {
            if (k$[i] === module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].SCOPE_NAME) {
              scopeName = k$[i + 1];
              break;
            }
          }
        }
      }
      if (scopeName) {
        classes.push(module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].SCOPE_NAME, scopeName);
      }
      if (!module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables) {
        let styleInfo = module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(element);
        if (styleInfo && styleInfo.scopeSelector) {
          classes.push(module$node_modules$$webcomponents$shadycss$src$style_properties["default"].XSCOPE_NAME, styleInfo.scopeSelector);
        }
      }
      StyleUtil.setElementClassRaw(element, classes.join(" "));
    }
    _styleInfoForNode(node) {
      return module$node_modules$$webcomponents$shadycss$src$style_info["default"].get(node);
    }
    scopeNode(node, scope) {
      module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].element(node, scope);
    }
    unscopeNode(node, scope) {
      module$node_modules$$webcomponents$shadycss$src$style_transformer["default"].element(node, scope, true);
    }
    scopeForNode(node) {
      return (0,module$node_modules$$webcomponents$shadycss$src$document_watcher.getOwnerScope)(node);
    }
    currentScopeForNode(node) {
      return (0,module$node_modules$$webcomponents$shadycss$src$document_watcher.getCurrentScope)(node);
    }
  }
  ScopingShim.prototype["flush"] = ScopingShim.prototype.flush;
  ScopingShim.prototype["prepareTemplate"] = ScopingShim.prototype.prepareTemplate;
  ScopingShim.prototype["styleElement"] = ScopingShim.prototype.styleElement;
  ScopingShim.prototype["styleDocument"] = ScopingShim.prototype.styleDocument;
  ScopingShim.prototype["styleSubtree"] = ScopingShim.prototype.styleSubtree;
  ScopingShim.prototype["getComputedStyleValue"] = ScopingShim.prototype.getComputedStyleValue;
  ScopingShim.prototype["setElementClass"] = ScopingShim.prototype.setElementClass;
  ScopingShim.prototype["_styleInfoForNode"] = ScopingShim.prototype._styleInfoForNode;
  ScopingShim.prototype["transformCustomStyleForDocument"] = ScopingShim.prototype.transformCustomStyleForDocument;
  ScopingShim.prototype["getStyleAst"] = ScopingShim.prototype.getStyleAst;
  ScopingShim.prototype["styleAstToString"] = ScopingShim.prototype.styleAstToString;
  ScopingShim.prototype["flushCustomStyles"] = ScopingShim.prototype.flushCustomStyles;
  ScopingShim.prototype["scopeNode"] = ScopingShim.prototype.scopeNode;
  ScopingShim.prototype["unscopeNode"] = ScopingShim.prototype.unscopeNode;
  ScopingShim.prototype["scopeForNode"] = ScopingShim.prototype.scopeForNode;
  ScopingShim.prototype["currentScopeForNode"] = ScopingShim.prototype.currentScopeForNode;
  Object.defineProperties(ScopingShim.prototype, {"nativeShadow":{get() {
    return module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow;
  }}, "nativeCss":{get() {
    return module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables;
  }}});
}, "node_modules/@webcomponents/shadycss/src/scoping-shim.js", ["node_modules/@webcomponents/shadycss/src/css-parse.js", "node_modules/@webcomponents/shadycss/src/style-settings.js", "node_modules/@webcomponents/shadycss/src/style-transformer.js", "node_modules/@webcomponents/shadycss/src/style-util.js", "node_modules/@webcomponents/shadycss/src/style-properties.js", "node_modules/@webcomponents/shadycss/src/style-placeholder.js", "node_modules/@webcomponents/shadycss/src/style-info.js", "node_modules/@webcomponents/shadycss/src/style-cache.js", 
"node_modules/@webcomponents/shadycss/src/document-watcher.js", "node_modules/@webcomponents/shadycss/src/template-map.js", "node_modules/@webcomponents/shadycss/src/apply-shim-utils.js", "node_modules/@webcomponents/shadycss/src/common-utils.js", "node_modules/@webcomponents/shadycss/src/custom-style-interface.js"]);

//node_modules/@webcomponents/shadycss/entrypoints/scoping-shim.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  var module$node_modules$$webcomponents$shadycss$src$scoping_shim = $$require("node_modules/@webcomponents/shadycss/src/scoping-shim.js");
  var module$node_modules$$webcomponents$shadycss$src$style_settings = $$require("node_modules/@webcomponents/shadycss/src/style-settings.js");
  const scopingShim = new module$node_modules$$webcomponents$shadycss$src$scoping_shim["default"];
  let ApplyShim, CustomStyleInterface;
  if (window["ShadyCSS"]) {
    ApplyShim = window["ShadyCSS"]["ApplyShim"];
    CustomStyleInterface = window["ShadyCSS"]["CustomStyleInterface"];
  }
  window.ShadyCSS = {ScopingShim:scopingShim, prepareTemplate(template, elementName, elementExtends) {
    scopingShim.flushCustomStyles();
    scopingShim.prepareTemplate(template, elementName, elementExtends);
  }, prepareTemplateDom(template, elementName) {
    scopingShim.prepareTemplateDom(template, elementName);
  }, prepareTemplateStyles(template, elementName, elementExtends) {
    scopingShim.flushCustomStyles();
    scopingShim.prepareTemplateStyles(template, elementName, elementExtends);
  }, styleSubtree(element, properties) {
    scopingShim.flushCustomStyles();
    scopingShim.styleSubtree(element, properties);
  }, styleElement(element) {
    scopingShim.flushCustomStyles();
    scopingShim.styleElement(element);
  }, styleDocument(properties) {
    scopingShim.flushCustomStyles();
    scopingShim.styleDocument(properties);
  }, flushCustomStyles() {
    scopingShim.flushCustomStyles();
  }, getComputedStyleValue(element, property) {
    return scopingShim.getComputedStyleValue(element, property);
  }, nativeCss:module$node_modules$$webcomponents$shadycss$src$style_settings.nativeCssVariables, nativeShadow:module$node_modules$$webcomponents$shadycss$src$style_settings.nativeShadow};
  if (ApplyShim) {
    window.ShadyCSS.ApplyShim = ApplyShim;
  }
  if (CustomStyleInterface) {
    window.ShadyCSS.CustomStyleInterface = CustomStyleInterface;
  }
}, "node_modules/@webcomponents/shadycss/entrypoints/scoping-shim.js", ["node_modules/@webcomponents/shadycss/src/scoping-shim.js", "node_modules/@webcomponents/shadycss/src/style-settings.js"]);

//src/post-polyfill.js
/**
 * @license
 * Copyright (c) 2014 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

'use strict';

let customElements = window['customElements'];
let HTMLImports = window['HTMLImports'];
let Template = window['HTMLTemplateElement'];

// global for (1) existence means `WebComponentsReady` will file,
// (2) WebComponents.ready == true means event has fired.
window.WebComponents = window.WebComponents || {};

if (customElements && customElements['polyfillWrapFlushCallback']) {
  // Here we ensure that the public `HTMLImports.whenReady`
  // always comes *after* custom elements have upgraded.
  let flushCallback;
  let runAndClearCallback = function runAndClearCallback() {
    if (flushCallback) {
      // make sure to run the HTMLTemplateElement polyfill before custom elements upgrade
      if (Template.bootstrap) {
        Template.bootstrap(window.document);
      }
      let cb = flushCallback;
      flushCallback = null;
      cb();
      return true;
    }
  }
  let origWhenReady = HTMLImports['whenReady'];
  customElements['polyfillWrapFlushCallback'](function(cb) {
    flushCallback = cb;
    origWhenReady(runAndClearCallback);
  });

  HTMLImports['whenReady'] = function(cb) {
    origWhenReady(function() {
      // custom element code may add dynamic imports
      // to match processing of native custom elements before
      // domContentLoaded, we wait for these imports to resolve first.
      if (runAndClearCallback()) {
        HTMLImports['whenReady'](cb);
      } else {
        cb();
      }
    });
  }

}

HTMLImports['whenReady'](function() {
  requestAnimationFrame(function() {
    window.WebComponents.ready = true;
    document.dispatchEvent(new CustomEvent('WebComponentsReady', {bubbles: true}));
  });
});
//src/unresolved.js
/**
 * @license
 * Copyright (c) 2014 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

'use strict';
// It's desireable to provide a default stylesheet
// that's convenient for styling unresolved elements, but
// it's cumbersome to have to include this manually in every page.
// It would make sense to put inside some HTMLImport but
// the HTMLImports polyfill does not allow loading of stylesheets
// that block rendering. Therefore this injection is tolerated here.
//
// NOTE: position: relative fixes IE's failure to inherit opacity
// when a child is not statically positioned.
let style = document.createElement('style');
style.textContent = ''
    + 'body {'
    + 'transition: opacity ease-in 0.2s;'
    + ' } \n'
    + 'body[unresolved] {'
    + 'opacity: 0; display: block; overflow: hidden; position: relative;'
    + ' } \n'
    ;
let head = document.querySelector('head');
head.insertBefore(style, head.firstChild);
//entrypoints/webcomponents-hi-sd-ce-pf-index.js
/*

Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
$jscomp.registerAndLoadModule(function($$require, $$exports, $$module) {
  "use strict";
  var module$node_modules$$webcomponents$webcomponents_platform$webcomponents_platform = $$require("node_modules/@webcomponents/webcomponents-platform/webcomponents-platform.js");
  var module$node_modules$$webcomponents$template$template = $$require("node_modules/@webcomponents/template/template.js");
  var module$src$promise = $$require("src/promise.js");
  var module$node_modules$$webcomponents$html_imports$src$html_imports = $$require("node_modules/@webcomponents/html-imports/src/html-imports.js");
  var module$src$pre_polyfill = $$require("src/pre-polyfill.js");
  var module$node_modules$$webcomponents$shadydom$src$shadydom = $$require("node_modules/@webcomponents/shadydom/src/shadydom.js");
  var module$node_modules$$webcomponents$custom_elements$src$custom_elements = $$require("node_modules/@webcomponents/custom-elements/src/custom-elements.js");
  var module$node_modules$$webcomponents$shadycss$entrypoints$scoping_shim = $$require("node_modules/@webcomponents/shadycss/entrypoints/scoping-shim.js");
  var module$src$post_polyfill = $$require("src/post-polyfill.js");
  var module$src$unresolved = $$require("src/unresolved.js");
}, "entrypoints/webcomponents-hi-sd-ce-pf-index.js", ["node_modules/@webcomponents/webcomponents-platform/webcomponents-platform.js", "node_modules/@webcomponents/template/template.js", "src/promise.js", "node_modules/@webcomponents/html-imports/src/html-imports.js", "src/pre-polyfill.js", "node_modules/@webcomponents/shadydom/src/shadydom.js", "node_modules/@webcomponents/custom-elements/src/custom-elements.js", "node_modules/@webcomponents/shadycss/entrypoints/scoping-shim.js", "src/post-polyfill.js", 
"src/unresolved.js"]);

